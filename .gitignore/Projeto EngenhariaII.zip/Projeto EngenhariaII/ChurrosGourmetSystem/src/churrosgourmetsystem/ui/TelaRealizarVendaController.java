/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlChurros;
import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.controladoras.CtrlItensDiversos;
import churrosgourmetsystem.db.controladoras.CtrlPedidos;
import churrosgourmetsystem.db.controladoras.CtrlVenda;
import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.db.entidades.Pedidos;
import churrosgourmetsystem.db.entidades.PedidosChurros;
import churrosgourmetsystem.db.entidades.PedidosItens;
import churrosgourmetsystem.db.entidades.Venda;
import churrosgourmetsystem.db.entidades.VendaProduto;
import churrosgourmetsystem.util.Banco;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author hiroshi
 */
public class TelaRealizarVendaController implements Initializable {

    @FXML
    private TableColumn<?, ?> colCodigo;
    @FXML
    private TableColumn<?, ?> colProduto;
    @FXML
    private TableColumn<?, ?> colValor;
    @FXML
    private JFXComboBox<String> cbPagamento;
    @FXML
    private JFXTextField txtvaloritens;
    @FXML
    private JFXTextField txtqtditens;
    @FXML
    private JFXTextField txtvalorchurros;
    @FXML
    private JFXTextField txtqtdchurros;
    @FXML
    private TableView<VendaProduto> tabela;
    CtrlItensDiversos ctrl_itens = new CtrlItensDiversos();
    CtrlFuncionario ctrl_func = new CtrlFuncionario();
    CtrlChurros ctrl_churros = new CtrlChurros();
    List<ItensDiversos> list_itens;
    List<Funcionario> list_func;
    List<Churros> list_churros;
    @FXML
    private JFXComboBox<Churros> cbChurros;
    @FXML
    private JFXComboBox<Funcionario> cbFuncionario;
    @FXML
    private JFXComboBox<ItensDiversos> cbItnesDiversos;
    VendaProduto dados;
    @FXML
    private TableColumn<?, ?> colQuantidade;
    ArrayList<VendaProduto> list_venda;
    int auxInt;
    Boolean achou;
    int codigo, qtde;
    String nome;
    double valor;
    int pos;
    @FXML
    private JFXTextField txtTotal;
    int soma;
    @FXML
    private JFXTextField txtDesconto;
    CtrlPedidos ctrl_pedidos = new CtrlPedidos();
    CtrlVenda ctrl_venda = new CtrlVenda();
    int codP;
    int codV;
    @FXML
    private JFXButton btVenda;
    @FXML
    private JFXButton btCancelar;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        InicializaCombobox();
        InicializarTabela();
        txtvalorchurros.setEditable(false);
        txtvaloritens.setEditable(false);
        txtDesconto.setText(""+0.00);
       
    }

    @FXML
    private void clkaddItens(ActionEvent event) {
        achou = false;
        if(txtqtditens.getText().equals("") || Integer.parseInt(txtqtditens.getText()) <=0)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Insira uma quantidade valida!! ", ButtonType.OK);
            txtqtditens.setText("");
            a.showAndWait();
        }
        else
        {
            codigo = cbItnesDiversos.getSelectionModel().getSelectedItem().getCodigo();
            nome = cbItnesDiversos.getSelectionModel().getSelectedItem().getNome();
            valor = cbItnesDiversos.getSelectionModel().getSelectedItem().getValor();
            qtde = Integer.parseInt(txtqtditens.getText());
            AtualizaTablewView(codigo, nome, valor, qtde);  
        }
        txtqtditens.setText("");
    }

    @FXML
    private void clkaddchurros(ActionEvent event) {
        if(txtqtdchurros.getText().equals("") || Integer.parseInt(txtqtdchurros.getText()) <=0)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Insira uma quantidade valida!! ", ButtonType.OK);
            txtqtdchurros.setText("");
            a.showAndWait();
        }
        else
        {
            codigo = cbChurros.getItems().get(pos).getCod().intValue();
            nome = cbChurros.getItems().get(pos).getDesc();
            valor = cbChurros.getItems().get(pos).getPreco();
            qtde = Integer.parseInt(txtqtdchurros.getText());
            AtualizaTablewView(codigo, nome, valor, qtde);
        }
        txtqtdchurros.setText("");
    }


    public void InicializaCombobox() {  
        list_itens = ctrl_venda.buscar("");
        cbItnesDiversos.setItems(FXCollections.observableArrayList(list_itens));
        list_func = ctrl_venda.buscarFun("");
        cbFuncionario.setItems(FXCollections.observableArrayList(list_func));
        list_churros = ctrl_venda.buscarChu("");
        cbChurros.setItems(FXCollections.observableArrayList(list_churros));
        cbPagamento.getItems().add("Dinheiro");
        cbPagamento.getItems().add("Cartao");
    }


    @FXML
    private void InserindoValorChurros(ActionEvent event) {
        pos = cbChurros.getSelectionModel().getSelectedIndex();
        txtvalorchurros.setText(list_churros.get(pos).getPreco().doubleValue()+"");
    }

    @FXML
    private void InserindoValorItens(ActionEvent event) {
        
        txtvaloritens.setText(cbItnesDiversos.getSelectionModel().getSelectedItem().getValor()+"");
    }
    
    public void InicializarTabela()
    {
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colProduto.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colValor.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
    }
    
    public void AtualizaTablewView(int codigo,String nome,double valor,int qtde)
    {
        if(tabela.getItems().size() != 0)
        {
            for(int i = 0; i < tabela.getItems().size();i++)
            {
                if(tabela.getItems().get(i).getNome()== nome)
                {
                    auxInt = tabela.getItems().get(i).getQuantidade();
                    tabela.getItems().get(i).setQuantidade(auxInt + qtde);
                    tabela.refresh();
                    achou = true;
                }
            }
            if(!achou)
                tabela.getItems().add(new VendaProduto(codigo, nome, valor, qtde));
        }
        else
            tabela.getItems().add(new VendaProduto(codigo, nome, valor, qtde));
        getTotal();
        txtTotal.setText(""+soma);
        achou = false;
    }
    
    public void getTotal()
    {   
        soma = 0;
        for (int i = 0; i < tabela.getItems().size(); i++) 
            soma += tabela.getItems().get(i).getQuantidade() * tabela.getItems().get(i).getValor();
    }
    
    public Boolean ValidaCampos()
    {
        int posFunc = cbFuncionario.getSelectionModel().getSelectedIndex();
        int posPayment = cbPagamento.getSelectionModel().getSelectedIndex();
        
        if(posFunc == -1 || posPayment == -1 || tabela.getItems().size() == 0)
            return false;
        return true;
    }

    @FXML
    private void clkExcluir(ActionEvent event) {
        pos = tabela.getSelectionModel().getSelectedIndex();
        
        if(pos != -1)
        {
            tabela.getItems().remove(pos);
            getTotal();
            txtTotal.setText(""+soma);
        }  
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Escolha uma linha a ser excluida!! ", ButtonType.OK);
            txtqtdchurros.setText("");
        }
    }

    @FXML
    private void clkConfirmar(ActionEvent event) {
        Pedidos p;
        Venda v;
        LocalDate data_atual;
        double desconto;
        if(!ValidaCampos())
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Preencha todos os campos!!! ", ButtonType.OK);
            a.show();
        }
        else
        {
            data_atual = LocalDate.now();
            codP = Banco.con.getMaxPK("pedidos", "cod_ped") + 1;
            codV = Banco.con.getMaxPK("vendas", "cod_venda")+1;
            p = new Pedidos(codP, Double.parseDouble(txtDesconto.getText()), Double.parseDouble(txtTotal.getText()), cbFuncionario.getSelectionModel().getSelectedItem().getCod(), 0, data_atual);
            v = new Venda(codV,data_atual,codP,cbPagamento.getSelectionModel().getSelectedItem());
            try
            {
                ctrl_venda.SalvarP(p);
                ctrl_venda.SalvarV(v);
                GravarPedChuOrItens();
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Venda Concluida!! ", ButtonType.OK);
                a.show();
                tabela.getItems().clear();
                tabela.refresh();
                LimparTela();
            }catch(Exception e){System.out.println(""+e);}
        }
    }
    
    private void GravarPedChuOrItens()
    {
        List<ItensDiversos> auxI;
        List<Churros> auxC;
        PedidosItens pI;
        PedidosChurros pC;
        for(int i = 0; i < tabela.getItems().size(); i++)
        {
            auxI = ctrl_venda.buscar(tabela.getItems().get(i).getNome());
            auxC = ctrl_venda.getChurros(tabela.getItems().get(i).getNome());
            if(auxI.size() != 0)
            {
                pI = new PedidosItens(codP,auxI.get(0).getCodigo(),tabela.getItems().get(i).getQuantidade(),tabela.getItems().get(i).getValor());
                ctrl_venda.InserirPedidos(pI);
                auxI = null;
            }
            if (auxC.size() != 0) {
                pC = new PedidosChurros(auxC.get(0).getCod(),codP, tabela.getItems().get(i).getQuantidade(), tabela.getItems().get(i).getValor());
                ctrl_venda.InserirPedidos(pC);
                auxC = null;
            }
        }
    }
    
    public void LimparTela()
    {
        txtTotal.setText("");
        txtqtdchurros.setText("");
        txtqtditens.setText("");
        txtvalorchurros.setText("");
        txtvaloritens.setText("");
    }
    public void aplicarEstilo()
    {
        btVenda.setStyle("-fx-background-color: " + Tema.getCor());
        btCancelar.setStyle("-fx-background-color: " + Tema.getCor());
    }

    @FXML
    private void clkCancelar(ActionEvent event) {
        LimparTela();
    }
}
