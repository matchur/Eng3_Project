/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlIngredientes;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class TelaPesquisaIngredienteController implements Initializable {

    private CtrlIngredientes CTRL = new CtrlIngredientes();
    @FXML
    private JFXButton bt_selecionar;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private BorderPane paneDados;
    @FXML
    private TableColumn<Ingredientes, Integer> cod;
    @FXML
    private TableColumn<Ingredientes, String> desc;
    @FXML
    private TableColumn<Ingredientes, Integer> est;
    @FXML
    private TableColumn<Ingredientes, String> obs;
    @FXML
    private TableColumn<Ingredientes, String> tipo;
    @FXML
    private TableColumn<Ingredientes, Double> pesoliq;
    @FXML
    private TableView<Ingredientes> tab_principal;
    
    private ObservableList<Ingredientes> dados;
    @FXML
    private JFXTextField tf_pesq;
    
    private static int flag = 0;
    private static Ingredientes classe;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        aplicarEstilo();
        
        cod.setCellValueFactory(new PropertyValueFactory<Ingredientes, Integer>("cod"));
        desc.setCellValueFactory(new PropertyValueFactory<Ingredientes, String>("desc"));
        est.setCellValueFactory(new PropertyValueFactory<Ingredientes, Integer>("qtdes"));
        obs.setCellValueFactory(new PropertyValueFactory<Ingredientes, String>("obs"));
        tipo.setCellValueFactory(new PropertyValueFactory<Ingredientes, String>("tipo"));
        pesoliq.setCellValueFactory(new PropertyValueFactory<Ingredientes, Double>("qtdun"));
        
        tab_principal.setItems(dados);
        
    }    


    @FXML
    private void clk_select(ActionEvent event) 
    {
        try{
        classe = tab_principal.getSelectionModel().getSelectedItem();
        flag = 1;

            Parent root = FXMLLoader.load(getClass().getResource("TelaIngredientes.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela Ingredientes!\nTente Selecionar algum item antes", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_voltar(ActionEvent event) 
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaIngredientes.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
    }

    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        TelaPesquisaIngredienteController.flag = flag;
    }

    public static Ingredientes getClasse() {
        return classe;
    }

    public static void setClasse(Ingredientes classe) {
        TelaPesquisaIngredienteController.classe = classe;
    }

    @FXML
    private void clk_procurar(MouseEvent event) {
        dados = FXCollections.observableArrayList(CTRL.buscar(tf_pesq.getText()));
        tab_principal.setItems(dados);
    }
    
    public void aplicarEstilo()
    {
        //bt_buscar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_selecionar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
}
