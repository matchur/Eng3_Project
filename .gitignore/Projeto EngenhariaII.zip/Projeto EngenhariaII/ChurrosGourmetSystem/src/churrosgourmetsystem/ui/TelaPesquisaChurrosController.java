/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlChurros;
import churrosgourmetsystem.db.controladoras.CtrlIngredientes;
import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Tabela;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPesquisaChurrosController implements Initializable {

    @FXML
    private JFXTextField tf_area;
    @FXML
    private TableView <Churros> tab_churros;
    @FXML
    private TableView <Tabela> tab_ing;
    @FXML
    private BorderPane paneDados;
    @FXML
    private TableColumn<Churros, Integer> c_cod;
    @FXML
    private TableColumn<Churros, String> c_desc;
    @FXML
    private TableColumn<Churros, Double> c_prec;
    @FXML
    private TableColumn<Churros, String> c_obs;
    @FXML
    private TableColumn<Tabela, String> c_ing;
    @FXML
    private TableColumn<Tabela, Double> c_qtd;
    
    
    
    private ObservableList<Tabela> dadosIng;
    private ObservableList<Churros> dadosChurros;
    
    private CtrlChurros CTRLC = new CtrlChurros();
    private CtrlIngredientes CTRLI = new CtrlIngredientes();
    
    private static int flag = 0;
    private static Churros churros;
    private static ObservableList<Tabela> ingredientes;
    @FXML
    private JFXButton btSelecionar;
    @FXML
    private JFXButton btVoltar;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        aplicarEstilo();
        c_cod.setCellValueFactory(new PropertyValueFactory<Churros, Integer>("cod"));
        c_desc.setCellValueFactory(new PropertyValueFactory<Churros, String>("desc"));
        c_prec.setCellValueFactory(new PropertyValueFactory<Churros, Double>("preco"));
        c_obs.setCellValueFactory(new PropertyValueFactory<Churros, String>("observacao"));
        
        c_ing.setCellValueFactory(new PropertyValueFactory<Tabela, String>("desc"));
        c_qtd.setCellValueFactory(new PropertyValueFactory<Tabela, Double>("qtd")); 
 
    }    
    
    
    @FXML
    private void clk_pesquisa(MouseEvent event)
    {
        dadosChurros = FXCollections.observableArrayList(CTRLC.buscar(tf_area.getText()));
        tab_churros.setItems(dadosChurros);
    }

    @FXML
    private void clk_select(ActionEvent event) 
    {
       
        try{
             churros = tab_churros.getSelectionModel().getSelectedItem();
             ingredientes = dadosIng;
             flag = 1;
            Parent root = FXMLLoader.load(getClass().getResource("TelaChurros.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela Churros!\nTente Selecionar algum item antes", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_voltar(ActionEvent event)
    {
        
         try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaChurros.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela principal!", ButtonType.OK);
                a.showAndWait();
            }
        
    }

    @FXML
    private void clk_mostraIngredientes(MouseEvent event) 
    {
        
        Churros selecionado = tab_churros.getSelectionModel().getSelectedItem();
        dadosIng = FXCollections.observableArrayList(CTRLI.buscarI(selecionado.getDesc()));
        tab_ing.setItems(dadosIng);
    }
   
    
    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        TelaPesquisaChurrosController.flag = flag;
    }

    public static Churros getChurros() {
        return churros;
    }

    public static ObservableList<Tabela> getIngredientes() {
        return ingredientes;
    }
    
    public void aplicarEstilo()
    {
        //bt_buscar.setStyle("-fx-background-color: " + Tema.getCor());
        btSelecionar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
}
