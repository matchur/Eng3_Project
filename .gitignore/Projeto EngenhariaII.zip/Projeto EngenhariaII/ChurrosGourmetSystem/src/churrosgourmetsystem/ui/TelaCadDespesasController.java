/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlTiposDespesas;
import churrosgourmetsystem.util.MaskFieldUtil;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaCadDespesasController implements Initializable {

    @FXML
    private JFXButton btNovo;
    @FXML
    private JFXButton btSalvar;
    @FXML
    private JFXButton btAlterar;
    @FXML
    private JFXButton btExcluir;
    @FXML
    private JFXButton btCancelar;
    @FXML
    private JFXButton btBuscar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXTextField txtDesc;
    @FXML
    private JFXTextField txtValor;
    @FXML
    private JFXTextField txtObs;
    private int acesso;
    private int alter = 0;
    @FXML
    private BorderPane paneDados;
    @FXML
    private JFXTextField txtParcelas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        setDisableAll(true);
        acesso = TelaPrincipalController.getAcesso();
        if(acesso == 1) //Admin
            habilitarBotoes(true, false, false, false, false, true, true);
        else //Usuario comum
            habilitarBotoes(false, false, false, false, false, true, true);
        
        if(TelaBuscarDespesasController.getFlag() == 1) //Acabou de retornar da tela de pesquisa
        {
            //exibirFuncionario(TelaBuscarFuncionarioController.getFunRet());
            exibirDespesa(TelaBuscarDespesasController.getDespRect());
            if(acesso == 1) //Admin
                habilitarBotoes(false, false, true, true, true, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, true, true, true);
            TelaBuscarDespesasController.setFlag(0);
        }
    }    
    
    private void exibirDespesa(CtrlTiposDespesas cr)
    {
        txtDesc.setText(cr.getDesp().getDescricao());
        txtObs.setText(cr.getDesp().getObs());
        txtValor.setText(""+cr.getDesp().getValor());
        txtParcelas.setText(""+cr.getDesp().getParcelas());
    }

    @FXML
    private void evtNovo(ActionEvent event) {
        alter = 0;
        setDisableAll(false);
        habilitarBotoes(false, true, false, false, true, true, true);
        
        txtDesc.requestFocus();
    }

    @FXML
    private void evtSalvar(ActionEvent event) {
        CtrlTiposDespesas crDesp;
        double valor;
        if(validarCamposObrigatorios())
        {
            try{
                valor = Double.parseDouble(txtValor.getText());
            }catch(Exception er){
                valor = -1;
            }
            if(valor >= 0)
            {
                int parcelas = Integer.parseInt(txtParcelas.getText());
                crDesp = new CtrlTiposDespesas(0, valor, txtDesc.getText(), txtObs.getText(), TelaLoginController.getCodFunc(), parcelas, 0);
                if(alter == 1)
                    alterarDsp(crDesp);
                else
                    gravarDsp(crDesp);
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Valor inválido!",ButtonType.OK);
                a.showAndWait();
            }
        }
    }
    
    public void alterarDsp(CtrlTiposDespesas crDesp)
    {
        if(crDesp.alterar(TelaBuscarDespesasController.getDespRect().getDesp().getCod() ,crDesp.getDesp()))
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Despesa alterada com sucesso!", ButtonType.OK);
            a.showAndWait();
            
            limparComponentes();

            if(acesso == 1) //Admin
                habilitarBotoes(true, false, false, false, false, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, false, true, true);
            
            setDisableAll(true);
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao alterar! Insira os dados corretamente!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void gravarDsp(CtrlTiposDespesas crDesp)
    {
        if(crDesp.salvar())
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Despesa gravada com sucesso!", ButtonType.OK);
            a.showAndWait();
            
            setDisableAll(true);
            if(acesso == 1) //Admin
                habilitarBotoes(true, false, false, false, false, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, false, true, true);
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao gravar! Insira os dados corretamente!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtAlterar(ActionEvent event) {
        alter = 1;
        setDisableAll(false);
        habilitarBotoes(false, true, false, true, true, true, true);
    }

    @FXML
    private void evtExcluir(ActionEvent event) {
        CtrlTiposDespesas cr = new CtrlTiposDespesas();
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Deseja excluir esta Despesa?", ButtonType.YES, ButtonType.NO);
        a.showAndWait();
        char aux;
        if(a.getResult() == ButtonType.YES)
        {
            aux = cr.excluir(TelaBuscarDespesasController.getDespRect().getDesp());
            if (aux == 1)
            {
                limparComponentes();
                a = new Alert(Alert.AlertType.INFORMATION, "Despesa excluido com sucesso!", ButtonType.OK);
                a.showAndWait();
                
                if(acesso == 1) //Admin
                    habilitarBotoes(true, false, false, false, false, true, true);
                else //Usuario comum
                    habilitarBotoes(false, false, false, false, false, true, true);
            }
            else if(aux == 0)
            {
                a = new Alert(Alert.AlertType.ERROR, "Erro ao excluir despesa!", ButtonType.OK);
                a.showAndWait();
            }
        }
    }

    @FXML
    private void evtCancelar(ActionEvent event) {
        setDisableAll(true);
        if(acesso == 1) //Admin
            habilitarBotoes(true, false, false, false, false, true, true);
        else //Usuario comum
            habilitarBotoes(false, false, false, false, false, true, true);
    }

    @FXML
    private void evtBuscar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscarDespesas.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de busca de despesas!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        limparComponentes();
        try{
        Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
        paneDados.getChildren().clear();
        paneDados.getChildren().add(root);

        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void aplicarEstilo()
    {
        btNovo.setStyle("-fx-background-color: " + Tema.getCor());
        btSalvar.setStyle("-fx-background-color: " + Tema.getCor());
        btAlterar.setStyle("-fx-background-color: " + Tema.getCor());
        btExcluir.setStyle("-fx-background-color: " + Tema.getCor());
        btCancelar.setStyle("-fx-background-color: " + Tema.getCor());
        btBuscar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
    private void setDisableAll(boolean value)
    {
        if(value == true)
            limparComponentes();
        
        txtDesc.setDisable(value);
        txtValor.setDisable(value);
        txtObs.setDisable(value);
        txtParcelas.setDisable(value);
    }
    
    private void habilitarBotoes(boolean v1, boolean v2, boolean v3, boolean v4, boolean v5, boolean v6, boolean v7)
    {
        btNovo.setDisable(!v1);
        btSalvar.setDisable(!v2);
        btAlterar.setDisable(!v3);
        btExcluir.setDisable(!v4);
        btCancelar.setDisable(!v5);
        btBuscar.setDisable(!v6);
        btVoltar.setDisable(!v7);
    }
    
    private void limparComponentes()
    {
        txtDesc.setText("");
        txtObs.setText("");
        txtValor.setText("");
        txtParcelas.setText("");
    }
    
    private boolean validarCamposObrigatorios()
    {
        if(!txtDesc.getText().equals("") && !txtValor.getText().equals(""))
            return true;
        else
            return false;
    }

    @FXML
    private void evtMaskPar(KeyEvent event) {
        MaskFieldUtil.numericField(txtParcelas);
    }
    
    
}
