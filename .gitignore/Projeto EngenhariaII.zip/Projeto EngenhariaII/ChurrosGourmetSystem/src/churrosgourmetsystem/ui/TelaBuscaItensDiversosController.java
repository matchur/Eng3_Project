/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.controladoras.CtrlItensDiversos;
import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author hiroshi
 */
public class TelaBuscaItensDiversosController implements Initializable {

    @FXML
    private TableView<ItensDiversos> tableview;
    @FXML
    private JFXTextField tbPesq;
    @FXML
    private JFXComboBox<String> cbPesquisa;
    ArrayList<ItensDiversos> list;
    CtrlItensDiversos ctrlitens;
    @FXML
    private TableColumn<?, ?> colCod;
    @FXML
    private TableColumn<?, ?> colNome;
    @FXML
    private TableColumn<?, ?> colValor;
    @FXML
    private TableColumn<?, ?> colTipo;
    @FXML
    private TableColumn<?, ?> colFornecedor;

    
    public static ItensDiversos item;
    @FXML
    private BorderPane panedados;
    @FXML
    private Button btConfirmar;
    @FXML
    private Button btVoltar;
    @FXML
    private Button btPesquisar;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        cbPesquisa.getItems().add("Nome");
        cbPesquisa.getItems().add("Tipo");
        item = null;
        colCod.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colValor.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colFornecedor.setCellValueFactory(new PropertyValueFactory<>("fornecedor"));
        
        ctrlitens = new CtrlItensDiversos();
        list = ctrlitens.buscar("");
        
        tableview.setItems(FXCollections.observableArrayList(list));
    }    

    @FXML
    private void btnConfirmar(ActionEvent event) { //Certo
        int pos = tableview.getSelectionModel().getSelectedIndex();
        if(pos != -1)
        {
            item = tableview.getSelectionModel().getSelectedItem();
             try
             {
                 Parent root = FXMLLoader.load(getClass().getResource("TelaItensDiversos.fxml"));
                 panedados.getChildren().clear();
                 panedados.getChildren().add(root);    
             }catch(Exception er)
             {
                 Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
                 a.showAndWait();
             } 
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Selecione uma linha!", ButtonType.OK);
            a.showAndWait();   
        }

    }

    @FXML
    private void btnVoltar(ActionEvent event) {
      try
        {
            Parent root = FXMLLoader.load(getClass().getResource("TelaItensDiversos.fxml"));
            panedados.getChildren().clear();
            panedados.getChildren().add(root);    
        }
        catch(Exception er)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        } 
    }

    @FXML
    private void btnPesquisar(ActionEvent event) {
        int pos = cbPesquisa.getSelectionModel().getSelectedIndex();
        ctrlitens = new CtrlItensDiversos();
        if(pos == 0)
            list = ctrlitens.buscarItemNT("nome like",tbPesq.getText());
        else
            list = ctrlitens.buscarItemNT("tipo like",tbPesq.getText());
        
        tableview.setItems(FXCollections.observableArrayList(list));
    }
    
    public void aplicarEstilo()
    {
        btConfirmar.setStyle("-fx-background-color: " + Tema.getCor());
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
}
