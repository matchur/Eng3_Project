/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.controladoras.CtrlParametrizacao;
import churrosgourmetsystem.util.Banco;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaLoginController implements Initializable {

    @FXML
    private ImageView imageView;
    @FXML
    private JFXTextField txtEmail;
    @FXML
    private JFXPasswordField txtSenha;
    @FXML
    private JFXButton btLogin;
    @FXML
    private JFXButton btSair;
    @FXML
    private HBox paneDados;
    
    private static int flag = 0;
    private static int acesso; //1-ADM; 2-NORMAL
    private static int codFunc;

    

    public static void setFlag(int flag) {
        TelaLoginController.flag = flag;
    }
    @FXML
    private AnchorPane ancPane;
    @FXML
    private Label lblNome;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Banco.conectar();
        lblNome.setText(CtrlParametrizacao.getNome());
        imageView.setImage(CtrlParametrizacao.getImg());
        
        aplicarEstilo();
    }    

    @FXML
    private void evtLogin(ActionEvent event) {
        String senha = "";
        CtrlFuncionario crFunc;
        Object[] object;
        try
        {
            flag = 1;
            crFunc = new CtrlFuncionario();
            
            object = crFunc.buscaLogin(txtEmail.getText(), acesso, senha);
            acesso = (int) object[0];
            senha = (String) object[1];
            codFunc = (int) object[2];
            
            if(senha.equals(txtSenha.getText()) && !txtSenha.getText().equals(""))
            {
                Stage stage = (Stage)paneDados.getScene().getWindow();
                stage.setWidth(800);
                stage.setHeight(678);
                stage.setResizable(false);
                Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipal.fxml"));
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Login ou senha inválidos!", ButtonType.OK);
                a.showAndWait();
            }
            
        }catch(Exception er){ System.out.println("Erro: " + er.getMessage());}
    }

    @FXML
    private void evtSair(ActionEvent event) {
        Platform.exit();
    }
    
    public static int getFlag() {
        return flag;
    }
    
    public static int getAcesso() {
        return acesso;
    }

    public static void setAcesso(int acesso) {
        TelaLoginController.acesso = acesso;
    }
    
    public void aplicarEstilo()
    {
        btLogin.setStyle("-fx-background-color: " + Tema.getCor());
        btSair.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
    public static int getCodFunc() {
        return codFunc;
    }

    public static void setCodFunc(int codFunc) {
        TelaLoginController.codFunc = codFunc;
    }
}
