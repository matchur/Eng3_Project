/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXMasonryPane;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPrincipalEstoqueController implements Initializable {

    @FXML
    private BorderPane paneCad;
    @FXML
    private JFXMasonryPane jManPane1;
    @FXML
    private JFXMasonryPane jManPane2;
    @FXML
    private Label lblDicas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
    } 
    
    public void aplicarEstilo()
    {
        jManPane1.setStyle("-fx-background-color: " + Tema.getCor());
        jManPane2.setStyle("-fx-background-color: " + Tema.getCor());
    }

    @FXML
    private void evtEstoque(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaEntradaEstoque.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de entrada de estoque! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtEstoqueDicas(MouseEvent event) {
    }

    @FXML
    private void evtAcerto(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaAcertarEstoque.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de acerto de estoque! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtAcertoEstoque(MouseEvent event) { //Dicas
        
    }
    
}
