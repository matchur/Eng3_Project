/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXMasonryPane;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPrincipalVendasController implements Initializable {

    @FXML
    private AnchorPane ancPane;
    @FXML
    private BorderPane paneDados;
    @FXML
    private JFXMasonryPane jMpaneLancarDesp;
    @FXML
    private JFXMasonryPane jMPDespesas;
    @FXML
    private JFXMasonryPane jMPCaixa;
    @FXML
    private Label lblDicas;
    @FXML
    private JFXMasonryPane jMPPagamento;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
    }    

    @FXML
    private void evtVendas(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaRealizarVenda.fxml"));/**/
            paneDados.getChildren().clear();
            paneDados.setPrefSize(510, 360);
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de caixa! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtVendasDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Realizar venda para o cliente que deseja levar o produto.");
    }

    @FXML
    private void evtPedidos(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPedidosMesa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir Tela Pedidos!", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void evtPedidosDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Realizar pedidos para os clientes que desejam comer no local.");
    }

    @FXML
    private void evtLancarPedidos(MouseEvent event) { //MEEEEESA
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaMesa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir de Mesas"
                        + "!", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void evtLancarPedidosDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Lançar os pedidos na mesa.");
    }
    
    public void aplicarEstilo()
    {
        jMPDespesas.setStyle("-fx-background-color: " + Tema.getCor());
        jMPCaixa.setStyle("-fx-background-color: " + Tema.getCor());
        jMpaneLancarDesp.setStyle("-fx-background-color: " + Tema.getCor());
        jMPPagamento.setStyle("-fx-background-color: " + Tema.getCor());
    }

    @FXML
    private void evtPagamento(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPagamentoMesa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir Tela de Pagamento!", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void evtPagamentoDicas(MouseEvent event) {
    }
    
}
