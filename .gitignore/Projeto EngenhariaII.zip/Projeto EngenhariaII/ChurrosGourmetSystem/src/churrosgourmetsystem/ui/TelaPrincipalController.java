package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlParametrizacao;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPrincipalController implements Initializable {

    @FXML
    private JFXButton btPnlControl;
    @FXML
    private JFXButton btCadastro;
    @FXML
    private HBox hbDados;
    @FXML
    private JFXButton brVenda;
    @FXML
    private JFXButton btRelatorio;
    
    private static int acesso;
    @FXML
    private JFXButton btSair;
    @FXML
    private BorderPane bdPane;
    @FXML
    private VBox vboxPane;
    @FXML
    private VBox vboxPane1;
    @FXML
    private VBox vboxPane2;
    @FXML
    private AnchorPane ancPane;
    @FXML
    private Label lblNomeSistema;
    @FXML
    private Label lblDados;
    @FXML
    private ImageView imageview;
    @FXML
    private JFXButton btEstoque;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        btRelatorio.setVisible(false);
        this.acesso = TelaLoginController.getAcesso();
        lblNomeSistema.setText(CtrlParametrizacao.getNome());
        lblDados.setText(CtrlParametrizacao.getStr());
        imageview.setImage(CtrlParametrizacao.getImg());
    }    

    @FXML
    private void evtPainelControle(ActionEvent event) {
        //hbDados.getChildren().clear();
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalPnControle.fxml"));
            hbDados.getChildren().clear();
            hbDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de painel de controle!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCadastro(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
            hbDados.getChildren().clear();
            hbDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtVenda(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalVendas.fxml"));
            hbDados.getChildren().clear();
            hbDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de vendas!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtRelatorio(ActionEvent event) {
        hbDados.getChildren().clear();
    }
    
    public static int getAcesso() {
        return acesso;
    }

    public static void setAcesso(int acesso) {
        TelaPrincipalController.acesso = acesso;
    }

    @FXML
    private void evtSair(ActionEvent event) {
        try{
            double vl = 230;
            if(CtrlParametrizacao.getImg().getHeight() > CtrlParametrizacao.getImg().getWidth()){
                vl = CtrlParametrizacao.getImg().getHeight() / 230;
                vl = CtrlParametrizacao.getImg().getWidth() / vl;
            }
            
            Stage stage = (Stage)ancPane.getScene().getWindow();
            stage.setWidth(vl + 320);
            stage.setHeight(260);
            stage.setResizable(false);
            Parent root = FXMLLoader.load(getClass().getResource("TelaLogin.fxml"));
            ancPane.getChildren().clear();
            ancPane.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao voltar a tela de login!", ButtonType.OK);
            a.showAndWait();
        }
        //Platform.exit();
    }
    
    public void aplicarEstilo()
    {
        brVenda.setStyle("-fx-background-color: " + Tema.getCor());
        btCadastro.setStyle("-fx-background-color: " + Tema.getCor());
        btPnlControl.setStyle("-fx-background-color: " + Tema.getCor());
        btRelatorio.setStyle("-fx-background-color: " + Tema.getCor());
        btSair.setStyle("-fx-background-color: " + Tema.getCor());
        vboxPane1.setStyle("-fx-background-color: " + Tema.getCor());
        vboxPane2.setStyle("-fx-background-color: " + Tema.getCor());
        btEstoque.setStyle("-fx-background-color: " + Tema.getCor());
    }

    @FXML
    private void evtEstoque(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalEstoque.fxml"));
            hbDados.getChildren().clear();
            hbDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de estoque!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
}
