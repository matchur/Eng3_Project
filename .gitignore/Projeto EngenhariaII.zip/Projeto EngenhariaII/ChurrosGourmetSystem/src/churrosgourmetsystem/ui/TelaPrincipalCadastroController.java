package churrosgourmetsystem.ui;

import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXMasonryPane;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPrincipalCadastroController implements Initializable {

    @FXML
    private BorderPane paneCad;
    @FXML
    private JFXMasonryPane jManPane1;
    @FXML
    private JFXMasonryPane jManPane2;
    @FXML
    private JFXMasonryPane jManPane3;
    @FXML
    private JFXMasonryPane jManPane4;
    @FXML
    private JFXMasonryPane jManPane5;
    @FXML
    private Label lblDicas;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
    }    

    @FXML
    private void evtCadFuncionarios(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaCadFuncionario.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCadIngredientes(MouseEvent event) {
        
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaIngredientes.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCadItensDiversos(MouseEvent event) {
        try
        {
            Parent root = FXMLLoader.load(getClass().getResource("TelaItensDiversos.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);    
        }catch(Exception er)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCadChurros(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaChurros.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCadDespesas(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaCadDespesas.fxml"));
            paneCad.getChildren().clear();
            paneCad.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void aplicarEstilo()
    {
        jManPane1.setStyle("-fx-background-color: " + Tema.getCor());
        jManPane2.setStyle("-fx-background-color: " + Tema.getCor());
        jManPane3.setStyle("-fx-background-color: " + Tema.getCor());
        jManPane4.setStyle("-fx-background-color: " + Tema.getCor());
        jManPane5.setStyle("-fx-background-color: " + Tema.getCor());
    }

    @FXML
    private void evtFuncDicas(MouseEvent event) {
        lblDicas.setText("Dicas: O cadastro de funcionários possui as operações básicas \nde gerenciamento, tais como inserção, exclusão, alteração e busca.");
    }

    @FXML
    private void evtIngredDicas(MouseEvent event) {
        lblDicas.setText("Dicas: O cadastro de Ingredientes possui as operações básicas \nde gerenciamento, tais como inserção, exclusão, alteração e busca.");
    }

    @FXML
    private void evtItensDicas(MouseEvent event) {
        lblDicas.setText("Dicas: O cadastro de Itens diversos possui as operações básicas \nde gerenciamento, tais como inserção, exclusão, alteração e busca.");
    }

    @FXML
    private void evtChurrosDicas(MouseEvent event) {
        lblDicas.setText("Dicas: O cadastro de Churros possui as operações básicas \nde gerenciamento, tais como inserção, exclusão, alteração e busca.");
    }

    @FXML
    private void evtTpDespDicas(MouseEvent event) {
        lblDicas.setText("Dicas: O cadastro de tipos de despesas possui as operações básicas \nde gerenciamento, tais como inserção, exclusão, alteração e busca.");
    }
}
