/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXMasonryPane;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPrincipalPnControleController implements Initializable {

    @FXML
    private JFXMasonryPane jManPane1;
    
    @FXML
    private BorderPane paneDados;
    @FXML
    private Label lblDicas;
    @FXML
    private JFXMasonryPane jMPDespesas;
    @FXML
    private JFXMasonryPane jMPCaixa;
    @FXML
    private JFXMasonryPane jMpaneLancarDesp;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        
    }    

    @FXML
    private void evtParametrizacao(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaParametrizacao.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro! ", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void aplicarEstilo()
    {
        jManPane1.setStyle("-fx-background-color: " + Tema.getCor());
        jMPDespesas.setStyle("-fx-background-color: " + Tema.getCor());
        jMPCaixa.setStyle("-fx-background-color: " + Tema.getCor());
        jMpaneLancarDesp.setStyle("-fx-background-color: " + Tema.getCor());
    }


    @FXML
    private void evtParamDicas(MouseEvent event) {
         lblDicas.setText("Dicas: A parametrização server para cadastrar os dados da \nempresa, tais como nome fantasia, endereço, fone, etc..");
    }

    
    @FXML
    private void evtPagarDespesas(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPgmContas.fxml"));
            paneDados.getChildren().clear();
            paneDados.setPrefSize(510, 360);
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de pagamento de despesas! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtDespesasDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Tela responsável por fazer o pagamento de contas e\ndespesas, tais como: contas de água, luz e etc.");
    }

    @FXML
    private void evtCaixa(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaCaixa.fxml"));
            paneDados.getChildren().clear();
            paneDados.setPrefSize(510, 360);
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de caixa! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCaixaDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Opção para abrir e fechar o caixa");
    }

    @FXML
    private void evtLancarDesp(MouseEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaLancarDesp.fxml"));
            paneDados.getChildren().clear();
            paneDados.setPrefSize(510, 360);
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de lançamento de despesas! ", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtLancDespDicas(MouseEvent event) {
        lblDicas.setText("Dicas: Opção para lançar despesas");
    }
    
}
