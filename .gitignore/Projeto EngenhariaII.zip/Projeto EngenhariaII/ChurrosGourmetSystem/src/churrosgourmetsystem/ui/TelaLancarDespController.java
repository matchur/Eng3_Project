/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlTiposDespesas;
import churrosgourmetsystem.db.entidades.TiposDespesas;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaLancarDespController implements Initializable {

    @FXML
    private JFXButton btConfirmar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXButton btPesquisar;
    @FXML
    private VBox vbTab;
    @FXML
    private TableView<TiposDespesas> tableview;
    @FXML
    private TableColumn<String, String> colCod;
    @FXML
    private TableColumn<String, String> colNome;
    @FXML
    private TableColumn<String, String> colNome1;
    @FXML
    private TableColumn<String, String> colPar;
    @FXML
    private TableColumn<String, String> colRg;
    private ArrayList<TiposDespesas> listDesp;
    private CtrlTiposDespesas crDesp;
    @FXML
    private AnchorPane ancPane;
    @FXML
    private JFXTextField txtCod;
    @FXML
    private JFXTextField txtDesc;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        aplicarEstilo();
        txtCod.setDisable(true);
        txtDesc.setDisable(true);
        
        colCod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colNome1.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colRg.setCellValueFactory(new PropertyValueFactory<>("codFunc"));
        colPar.setCellValueFactory(new PropertyValueFactory<>("parcelas"));
        
        crDesp = new CtrlTiposDespesas();
        listDesp = crDesp.buscar("");
        
        tableview.setItems(FXCollections.observableArrayList(listDesp));
    }    

    @FXML
    private void evtConfirmar(ActionEvent event) {
       if(crDesp.alterarFlag(Integer.parseInt(txtCod.getText())))
       {
           Alert a = new Alert(Alert.AlertType.INFORMATION, "Despesa lançada com sucesso!", ButtonType.OK);
           a.showAndWait();
           
           txtCod.setText("");
            txtDesc.setText("");
            txtPesquisa.setText("");

            crDesp = new CtrlTiposDespesas();
            listDesp = crDesp.buscar("");

            tableview.setItems(FXCollections.observableArrayList(listDesp));
       }
       else
       {
           Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao lançar despesa!", ButtonType.OK);
           a.showAndWait();
       }
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        txtCod.setText("");
        txtDesc.setText("");
        txtPesquisa.setText("");
        
        crDesp = new CtrlTiposDespesas();
        listDesp = crDesp.buscar("");
        
        tableview.setItems(FXCollections.observableArrayList(listDesp));
    }

    @FXML
    private void evtPesquisar(ActionEvent event) {
        listDesp = crDesp.buscarN("descricao ilike ", txtPesquisa.getText());
        tableview.setItems(FXCollections.observableArrayList(listDesp));
    }
    
    public void aplicarEstilo()
    {
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btConfirmar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbTab.setStyle("-fx-background-color: " + Tema.getCor());
        
    }

    @FXML
    private void evtCliquei(MouseEvent event) {
        txtCod.setText(tableview.getSelectionModel().getSelectedItem().getCod()+"");
        txtDesc.setText(tableview.getSelectionModel().getSelectedItem().getDescricao());
    }
    
}
