package churrosgourmetsystem.ui;


import churrosgourmetsystem.db.controladoras.CtrlChurros;
import churrosgourmetsystem.db.controladoras.CtrlIngredientes;
import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.entidades.Tabela;
import churrosgourmetsystem.util.Tema;



import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javax.swing.JOptionPane;

public class TelaChurrosController implements Initializable {

    @FXML
    private ComboBox<String> cb_ing;
    @FXML
    private JFXTextField tf_desc;
    @FXML
    private JFXTextField tf_preco;
    @FXML
    private JFXTextField tf_obs;
    @FXML
    private Label lb_cod;
    
    @FXML
    private JFXButton bt_add;
    @FXML
    private JFXButton bt_novo;
    @FXML
    private JFXButton bt_salvar;
    @FXML
    private JFXButton bt_pesquisar;
    @FXML
    private JFXButton bt_cancelar;
    @FXML
    private Label lb_aten1;
    @FXML
    private Label lb_aten2;
    @FXML
    private TableView<Tabela> tab_ing;
    @FXML
    private JFXTextField tf_medida;
    @FXML
    private JFXButton bt_excluir;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private BorderPane paneDados;
    
    private ObservableList<Tabela> dados = FXCollections.observableArrayList();
    private ArrayList <Tabela> tabela = new ArrayList<>();
    
    private CtrlIngredientes CTRL_ing = new CtrlIngredientes();
    
    private CtrlChurros CTRL_churros = new CtrlChurros();
    
    private Churros classe;
    
    @FXML
    private Label lb_aten3;
    @FXML
    private TableColumn<Tabela, String> c_desc;
    @FXML
    private TableColumn<Tabela, Double> c_qtd;
    @FXML
    private JFXButton bt_retirar;
    @FXML
    private VBox vbCod;
    @FXML
    private VBox vbIngredientes;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
            aplicarEstilo();
        
        if(TelaPesquisaChurrosController.getFlag() != 0)
        {
            setFieldsCadastro(TelaPesquisaChurrosController.getChurros());
           cb_ing.getItems().addAll(CTRL_ing.getIngredientesDesc());
           dados.addAll(TelaPesquisaChurrosController.getIngredientes());
           tabela.addAll(dados);
        }
        else
        {
            setDisable(true);  
        }
            
           tab_ing.setItems(dados);
           cb_ing.setValue("");

    }

    private void setFieldsCadastro(Churros classe)
    {
        boolean x = false;
        lb_cod.setText(classe.getCod().toString());
        tf_desc.setText(classe.getDesc());
        tf_preco.setText(classe.getPreco().toString());
        tf_obs.setText(classe.getObservacao());
        cb_ing.setDisable(x);
        bt_add.setDisable(x);
        bt_retirar.setDisable(x);
        bt_excluir.setDisable(x);
        bt_salvar.setDisable(x);
        bt_cancelar.setDisable(x);
    }    
    
    private void setDisable(boolean x)
    {
        //desabilitando todos os campos
        tf_desc.setDisable(x);
        tf_preco.setDisable(x);
        tf_obs.setDisable(x);
        cb_ing.setDisable(x);
        bt_add.setDisable(x);
        bt_retirar.setDisable(x);
        bt_excluir.setDisable(x);
        bt_salvar.setDisable(x);
        bt_cancelar.setDisable(x);
        lb_aten1.setText("");
        lb_aten2.setText("");
        
    }
    
    private void clear()
    {
        tf_desc.setText("");
        tf_preco.setText("");
        tf_obs.setText("");
        lb_cod.setText("Código");
        dados.clear();
        tabela.clear();
    }

    @FXML
    private void clkNovo(ActionEvent event)
    {
        setDisable(false);
        clear();
        cb_ing.getItems().addAll(CTRL_ing.getIngredientesDesc());
        
        c_qtd.setCellValueFactory(new PropertyValueFactory<Tabela, Double>("qtd"));
        c_desc.setCellValueFactory(new PropertyValueFactory<Tabela, String>("desc"));
    }

    @FXML
    private void clkCancelar(ActionEvent event) 
    {
        TelaPesquisaChurrosController.setFlag(0);
        clear();
        setDisable(true);
    }

    @FXML
    private void clkSalvar(ActionEvent event) throws SQLException
    {
        Double preco;
        
        lb_aten1.setText("");
        lb_aten2.setText("");
        lb_aten3.setText("");
        
        if(tf_desc.getText().length() > 0)
        {
            
            if(tf_preco.getText().length() > 0 && tryParseDouble(tf_preco.getText()))
            {
                if(lb_cod.getText().equals("Código"))
                {
                    classe = new Churros(0,tf_desc.getText(),Double.parseDouble(tf_preco.getText()),tf_obs.getText(),0);
                    CTRL_churros.salvar(classe, tabela);
                }
                else
                {
                    classe = new Churros(Integer.parseInt(lb_cod.getText()),tf_desc.getText(),Double.parseDouble(tf_preco.getText()),tf_obs.getText(),0);
                    CTRL_churros.update(classe, tabela);
                }
                 Alert a = new Alert(Alert.AlertType.INFORMATION, "Churros cadastrado com sucesso!", ButtonType.OK);
                 a.showAndWait();
                clear();
            }
                else       
                lb_aten2.setText("*");
        }
        else
            lb_aten1.setText("*");
        
        
        //colocar mensagem de que salvou...
        
    }
    
    @FXML
    private void clk_adicionar(ActionEvent event) 
    {
        tf_medida.setStyle("");
        if(cb_ing.getValue() == "")
             lb_aten3.setText("*");
        else
            {
                if(tf_medida.getText().length() > 0 && tryParseDouble(tf_medida.getText()))
                    {
                        if(!procuraItem(cb_ing.getValue(),tabela))
                        {
                            dados.addAll(new Tabela(cb_ing.getValue(),Double.parseDouble(tf_medida.getText())));
                            tabela.add(new Tabela(cb_ing.getValue(),Double.parseDouble(tf_medida.getText())));
                           
                        }
                        else
                        {
                            modificaItem(cb_ing.getValue(),Double.parseDouble(tf_medida.getText()),tabela,dados);
                            tab_ing.refresh();
                        }
                            cb_ing.setValue("");
                            tf_medida.setText("");
                    }
                    else
                        tf_medida.setStyle("-fx-background-color: #ff6060;");
            }
   }   
    
    private boolean procuraItem(String value,ArrayList<Tabela> tabela)
    {
        for(Tabela list:tabela)
        {
            if(list.getDesc().equals(value))//caso ache o item dentro da array
            {
                return true;
            }
        }
        return false;        
    }
    
    private void modificaItem(String value,double qtd,ArrayList<Tabela> tabela,ObservableList<Tabela> dados)
    {
        int i = 0;
        for(Tabela list:tabela)
        {
            
            if(list.getDesc().equals(value))//caso ache o item dentro da array
            {        
                tabela.get(i).setQtd(qtd);
                dados.get(i).setQtd(qtd);
                break;
            }
            i++;
        }
        Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela principal!", ButtonType.OK);
        a.showAndWait();
        
    }
     
    @FXML
    private void clk_excluir(ActionEvent event) {
        int n = JOptionPane.showConfirmDialog(null,"Deseja excluir o item "+lb_cod.getText()+"?","Confirmacao",JOptionPane.YES_NO_OPTION);
         if(n == JOptionPane.YES_OPTION)
         {
            try {
                CTRL_churros.excluir(Integer.parseInt(lb_cod.getText()));
            } catch (SQLException ex) {
                System.out.println("Erro: " + ex.getMessage());
            }
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Produto excluido com sucesso"+lb_cod.getText()+"?", ButtonType.OK);
            a.showAndWait();
         }
         clear();
    }

    @FXML
    private void clk_voltar(ActionEvent event) 
    {
        clear();
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela principal!", ButtonType.OK);
                a.showAndWait();
            }
    }
    
    private boolean tryParseDouble(String value) {  
     try {  
         Double.parseDouble(value);  
         return true;  
      } catch (NumberFormatException e) {  
         return false;  
      }  
    }
    
    private boolean tryParseInt(String value) {  
     try {  
         Integer.parseInt(value);  
         return true;  
      } catch (NumberFormatException e) {  
         return false;  
      }  
        }

    @FXML
    private void clk_retirar(ActionEvent event) 
    {
        int i = 0;
        Tabela selectedItem = tab_ing.getSelectionModel().getSelectedItem();
        tab_ing.getItems().remove(selectedItem);
        
      
        for(Tabela list:tabela)
        {
            if(list.getDesc().equals(selectedItem.getDesc()))//caso ache o item dentro da array
            {
               tabela.remove(i);
               dados.remove(i);
               break;
            }
            i++;
        }
    }
    
    @FXML
    private void clkPesquisar(ActionEvent event) 
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPesquisaChurros.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela principal!", ButtonType.OK);
                a.showAndWait();
            }
    }
    
    public void aplicarEstilo()
    {
        bt_novo.setStyle("-fx-background-color: " + Tema.getCor());
        bt_salvar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_pesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_cancelar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_excluir.setStyle("-fx-background-color: " + Tema.getCor());
        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
        
        bt_add.setStyle("-fx-background-color: " + Tema.getCor());
        bt_retirar.setStyle("-fx-background-color: " + Tema.getCor());
        vbCod.setStyle("-fx-background-color: " + Tema.getCor());
        vbIngredientes.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
}
