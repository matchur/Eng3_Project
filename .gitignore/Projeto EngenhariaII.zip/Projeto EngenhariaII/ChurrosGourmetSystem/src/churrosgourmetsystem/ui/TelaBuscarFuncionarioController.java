/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaBuscarFuncionarioController implements Initializable {

    @FXML
    private BorderPane paneDados;
    @FXML
    private JFXButton btConfirmar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXButton btPesquisar;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXComboBox<String> cbCampos;
    @FXML
    private TableView<Funcionario> tableview;
    @FXML
    private TableColumn<String, String> colCod;
    @FXML
    private TableColumn<String, String> colNome;
    @FXML
    private TableColumn<String, String> colRg;
    @FXML
    private TableColumn<String, String> colCpf;
    @FXML
    private TableColumn<String, String> colEmail;
    @FXML
    private TableColumn<String, String> colCel;
    @FXML
    private TableColumn<String, String> colNiv;
    ArrayList<Funcionario> listFunc;
    CtrlFuncionario crFunc;
    private static int flag = 0;
    private static CtrlFuncionario funcRet = null;
    @FXML
    private VBox vbTab;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        cbCampos.getItems().add("Nome");
        cbCampos.getItems().add("RG");
        cbCampos.getItems().add("CPF");
        
        colCod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colRg.setCellValueFactory(new PropertyValueFactory<>("rg"));
        colCpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colCel.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        colNiv.setCellValueFactory(new PropertyValueFactory<>("nivel"));
        
        crFunc = new CtrlFuncionario();
        listFunc = crFunc.buscar("");
        
        
        tableview.setItems(FXCollections.observableArrayList(listFunc));
    }    

    @FXML
    private void evtConfirmar(ActionEvent event) {
        try{
            flag = 1;
            funcRet = new CtrlFuncionario(tableview.getSelectionModel().getSelectedItem());
            
            Parent root = FXMLLoader.load(getClass().getResource("TelaCadFuncionario.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        try{
            flag = 0;
            Parent root = FXMLLoader.load(getClass().getResource("TelaCadFuncionario.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtPesquisar(ActionEvent event) {
        if(cbCampos.getSelectionModel().getSelectedIndex() == 0) //Nome
        {
            listFunc = crFunc.buscarN("nome_func ilike ", txtPesquisa.getText());
            tableview.setItems(FXCollections.observableArrayList(listFunc));
        }
        else if (cbCampos.getSelectionModel().getSelectedIndex() == 1) //RG
        {
            listFunc = crFunc.buscarN("rg_func ilike ", txtPesquisa.getText());
            tableview.setItems(FXCollections.observableArrayList(listFunc));
        }
        else if (cbCampos.getSelectionModel().getSelectedIndex() == 2) //CPF
        {
            listFunc = crFunc.buscarN("cpf_func ilike ", txtPesquisa.getText());
            tableview.setItems(FXCollections.observableArrayList(listFunc));
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Selecione algum campo de pesquisa!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        TelaBuscarFuncionarioController.flag = flag;
    }

    public static CtrlFuncionario getFuncRet() {
        return funcRet;
    }

    public static void setFuncRet(CtrlFuncionario funcRet) {
        TelaBuscarFuncionarioController.funcRet = funcRet;
    }
    
    public void aplicarEstilo()
    {
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btConfirmar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbTab.setStyle("-fx-background-color: " + Tema.getCor());
        
    }
}
