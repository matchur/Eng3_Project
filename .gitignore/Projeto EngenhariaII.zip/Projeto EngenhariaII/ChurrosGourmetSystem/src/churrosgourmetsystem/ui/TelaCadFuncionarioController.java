package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.controladoras.CtrlParametrizacao;
import churrosgourmetsystem.util.MaskFieldUtil;
import churrosgourmetsystem.util.Tema;
import churrosgourmetsystem.util.ValidadorCPF;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaCadFuncionarioController implements Initializable {

    @FXML
    private BorderPane paneDados;
    @FXML
    private JFXButton btNovo;
    @FXML
    private JFXButton btSalvar;
    @FXML
    private JFXButton btAlterar;
    @FXML
    private JFXButton btCancelar;
    @FXML
    private JFXButton btBuscar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXTextField txtNome;
    @FXML
    private JFXTextField txtRG;
    @FXML
    private JFXTextField txtCPF;
    @FXML
    private JFXTextField txtEmail;
    @FXML
    private JFXTextField txtTelefone;
    @FXML
    private JFXTextField txtEndereco;
    @FXML
    private JFXTextField txtNumero;
    @FXML
    private JFXTextField txtBairro;
    @FXML
    private JFXTextField txtCidade;
    @FXML
    private JFXPasswordField txtSenha;
    @FXML
    private JFXComboBox<String> cbAcesso;
    @FXML
    private JFXDatePicker dtNasc;
    private static int acesso;
    @FXML
    private JFXButton btExcluir;
    @FXML
    private JFXTextField txtSalario;
    private int pc = 0;
    private int alter = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        setDisableAll(true);
        if(TelaLoginController.getFlag() == 0) //Não há cadastro.
        {
            pc = 1;
            acesso = 1;
            cbAcesso.getItems().add("Administrador");
            btVoltar.setText("Sair");
            
            habilitarBotoes(true, false, false, false, false, false, true);
        }  
        else //Há algum usuário cadastrado
        {
            pc = 0;
            acesso = TelaPrincipalController.getAcesso();
            cbAcesso.getItems().add("Administrador");
            cbAcesso.getItems().add("Normal");
            btVoltar.setText("Voltar");
            
            if(acesso == 1) //Admin
                habilitarBotoes(true, false, false, false, false, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, false, true, true);
        }
        
        if(TelaBuscarFuncionarioController.getFlag() == 1) //Acabou de retornar da tela de pesquisa
        {
            //exibirFuncionario(TelaBuscarFuncionarioController.getFunRet());
            exibirFuncionario(TelaBuscarFuncionarioController.getFuncRet());
            if(acesso == 1) //Admin
                habilitarBotoes(false, false, true, true, true, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, true, true, true);
            TelaBuscarFuncionarioController.setFlag(0);
        }
    }    

    @FXML
    private void evtNovo(ActionEvent event) {
        alter = 0;
        setDisableAll(false);
        if(pc == 1)
            habilitarBotoes(false, true, false, false, true, false, true);
        else
            habilitarBotoes(false, true, false, false, true, true, true);
        
        txtNome.requestFocus();
    }

    @FXML
    private void evtSalvar(ActionEvent event) {
        CtrlFuncionario crFunc;
        int num;
        double sal;
        boolean flagCPF;
        
        if(validaCamposObrigatorios() && validaNumeros())
        {
            if(txtCPF.getText().contains("/")) //Validar CNPJ
                flagCPF = ValidadorCPF.isValidCNPJ(txtCPF.getText());
            else //Validar CPF
                flagCPF = ValidadorCPF.isValidCPF(txtCPF.getText());
            
            if(flagCPF == true) //Se o validador de CPF/CNPJ for verdade.
            {
                try{
                    num = Integer.parseInt(txtNumero.getText());
                }catch(Exception er){
                    num = 0;
                }
                
                try{
                    sal = Double.parseDouble(txtSalario.getText());
                }catch(Exception er){
                    sal = -1;
                }

                if(sal >= 0)
                {
                    crFunc = new CtrlFuncionario(0, txtNome.getText(), txtCPF.getText(), txtRG.getText(), dtNasc.getValue(),
                        txtEmail.getText(), txtTelefone.getText(), txtEndereco.getText(), txtBairro.getText(), txtCidade.getText(),
                        num, txtSenha.getText(), sal, cbAcesso.getSelectionModel().getSelectedIndex() + 1);

                    if(alter == 1) //Alterando user.
                        alterarUsr(crFunc, TelaBuscarFuncionarioController.getFuncRet().getFunc().getNivel());
                    else
                        gravarUsr(crFunc);
                }
                else
                {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Salário inválido!",ButtonType.OK);
                    a.showAndWait();
                }
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro: CPF/CNPJ inválido!",ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Insira os campos obrigatórios corretamente!",ButtonType.OK);
            a.showAndWait();
        }
    }

    private void gravarUsr(CtrlFuncionario crFunc)
    {
        int fl = crFunc.salvar();
        if(fl == 1)
        {
            if(pc == 1)
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Funcionário gravado com sucesso! Por favor relogue como este usuário!", ButtonType.OK);
                a.showAndWait();
                //Platform.exit();
                try{
                    double vl = 230;
                    if(CtrlParametrizacao.getImg().getHeight() > CtrlParametrizacao.getImg().getWidth()){
                        vl = CtrlParametrizacao.getImg().getHeight() / 230;
                        vl = CtrlParametrizacao.getImg().getWidth() / vl;
                    }

                    Stage stage = (Stage)paneDados.getScene().getWindow();
                    stage.setWidth(vl + 320);
                    stage.setHeight(260);
                    stage.setResizable(false);
                    Parent root = FXMLLoader.load(getClass().getResource("TelaLogin.fxml"));
                    paneDados.getChildren().clear();
                    paneDados.getChildren().add(root);

                }catch(Exception er){
                    a = new Alert(Alert.AlertType.ERROR, "Erro ao voltar a tela de login!", ButtonType.OK);
                    a.showAndWait();
                }
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Funcionário gravado com sucesso!", ButtonType.OK);
                a.showAndWait();
                limparComponentes();
                setDisableAll(true);

                if(acesso == 1) //Admin
                    habilitarBotoes(true, false, false, false, false, true, true);
                else //Usuario comum
                    habilitarBotoes(false, false, false, false, false, true, true);
            }
        }
        else if(fl == -1)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao gravar! Este login já está sendo utilizado! Por favor digite outro!", ButtonType.OK);
            a.showAndWait();
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao gravar! Dados inseridos incorretamente!", ButtonType.OK);
            a.showAndWait();
        }
            
    }
    
    public void alterarUsr(CtrlFuncionario crFunc, int lvl)
    {
        crFunc.setCodFunc(TelaBuscarFuncionarioController.getFuncRet().getFunc().getCod());
        char result = crFunc.alterar(lvl); 
        if(result == 1)
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Funcionário alterado com sucesso!", ButtonType.OK);
            a.showAndWait();
            limparComponentes();

            if(acesso == 1) //Admin
                habilitarBotoes(true, false, false, false, false, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, false, true, true);
            
            setDisableAll(true);
        }
        else if(result == 0)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao alterar! Verifique os campos novamente!", ButtonType.OK);
            a.showAndWait();
        }
        else if(result == 2)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao alterar! O sistema deve conter no minímo um administrador!", ButtonType.OK);
            a.showAndWait();
        }
        else if(result == 3)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao gravar! Este login já está sendo utilizado! Por favor digite outro!", ButtonType.OK);
            a.showAndWait();
        }
            
    }
    
    @FXML
    private void evtAlterar(ActionEvent event) {
        alter = 1;
        setDisableAll(false);
        habilitarBotoes(false, true, false, true, true, true, true);
    }

    @FXML
    private void evtCancelar(ActionEvent event) {
        setDisableAll(true);
        if(pc == 1) //Se for primeiro cadastro
            habilitarBotoes(true, false, false, false, false, false, true);
        else
        {
            if(acesso == 1) //Admin
                habilitarBotoes(true, false, false, false, false, true, true);
            else //Usuario comum
                habilitarBotoes(false, false, false, false, false, true, true);
        }
    }

    @FXML
    private void evtBuscar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscarFuncionario.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        limparComponentes();
        if(btVoltar.getText().equals("Voltar"))
        {
            try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
            Platform.exit();
    }
    
    private void setDisableAll(boolean value)
    {
        if(value == true)
            limparComponentes();
        
        txtNome.setDisable(value);
        txtRG.setDisable(value);
        txtCPF.setDisable(value);
        dtNasc.setDisable(value);
        
        txtEmail.setDisable(value);
        txtTelefone.setDisable(value);
        
        txtEndereco.setDisable(value);
        txtBairro.setDisable(value);
        txtNumero.setDisable(value);
        txtCidade.setDisable(value);
        
        txtSenha.setDisable(value);
        cbAcesso.setDisable(value);
        txtSalario.setDisable(value);
        
    }
    
    private void limparComponentes()
    {
        txtNome.setText("");
        txtRG.setText("");
        txtCPF.setText("");
        dtNasc.setValue(LocalDate.now());
        
        txtEmail.setText("");
        txtTelefone.setText("");
        
        txtEndereco.setText("");
        txtBairro.setText("");
        txtCidade.setText("");
        txtNumero.setText("");
        
        txtSenha.setText("");
        txtSalario.setText("");
        cbAcesso.getSelectionModel().select(-1);
    }
    
    private void habilitarBotoes(boolean v1, boolean v2, boolean v3, boolean v4, boolean v5, boolean v6, boolean v7)
    {
        btNovo.setDisable(!v1);
        btSalvar.setDisable(!v2);
        btAlterar.setDisable(!v3);
        btExcluir.setDisable(!v4);
        btCancelar.setDisable(!v5);
        btBuscar.setDisable(!v6);
        btVoltar.setDisable(!v7);
    }

    @FXML
    private void evtExcluir(ActionEvent event) {
        CtrlFuncionario crFunc = new CtrlFuncionario();
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Deseja excluir este funcionário?", ButtonType.YES, ButtonType.NO);
        a.showAndWait();
        char aux;
        if(a.getResult() == ButtonType.YES)
        {
            aux = crFunc.excluir(TelaBuscarFuncionarioController.getFuncRet().getFunc());
            if (aux == 1)
            {
                limparComponentes();
                a = new Alert(Alert.AlertType.INFORMATION, "Usuário excluido com sucesso!", ButtonType.OK);
                a.showAndWait();
                
                if(acesso == 1) //Admin
                    habilitarBotoes(true, false, false, false, false, true, true);
                else //Usuario comum
                    habilitarBotoes(false, false, false, false, false, true, true);
            }
            else if(aux == 0)
            {
                a = new Alert(Alert.AlertType.ERROR, "Erro ao excluir usuário!", ButtonType.OK);
                a.showAndWait();
            }
            else if(aux == 2)
            {
                a = new Alert(Alert.AlertType.ERROR, "Erro ao excluir usuário! O sistema deve conter no minímo um administrador!", ButtonType.OK);
                a.showAndWait();
            }
        }
        
    }
    
    private boolean validaCamposObrigatorios()
    {
        if( !txtNome.getText().equals("") &&
            !txtRG.getText().equals("") &&
            !txtCPF.getText().equals("") &&
            !txtEmail.getText().equals("") &&
            !txtSenha.getText().equals("") &&
            !txtSalario.getText().equals("") &&
            cbAcesso.getSelectionModel().getSelectedIndex() != -1)
            return true;
        else 
            return false;
    }
    
    private boolean validaNumeros()
    {
        try
        {
            double sal = Double.parseDouble(txtSalario.getText());
            int num;
            if(!txtNumero.getText().equals(""))
                num = Integer.parseInt(txtNumero.getText());
            
            return true;
        }catch(Exception er){return false;}
    }
    
    private void exibirFuncionario(CtrlFuncionario f)
    {   
        txtNome.setText(f.getFunc().getNome());
        txtRG.setText(f.getFunc().getRg());
        txtCPF.setText(f.getFunc().getCpf());
        dtNasc.setValue(f.getFunc().getDtNasc());
        
        txtEmail.setText(f.getFunc().getEmail());
        txtTelefone.setText(f.getFunc().getTelefone());
        
        txtEndereco.setText(f.getFunc().getEndereco());
        txtNumero.setText("" + f.getFunc().getNumero());
        txtCidade.setText(f.getFunc().getCidade());
        txtBairro.setText(f.getFunc().getBairro());
        
        cbAcesso.getSelectionModel().select(f.getFunc().getNivel() - 1);
        if(acesso == 1)
        {
            txtSalario.setText("" + f.getFunc().getSalario());
            txtSenha.setText(f.getFunc().getSenha());
        }
        else
            txtSalario.setText("Você não tem permissão para ver essa informação!");
            
    }

    @FXML
    private void evtMaskCPF(KeyEvent event) {
        MaskFieldUtil.cpfCnpjField(txtCPF);
    }

    @FXML
    private void evtMaskFone(KeyEvent event) {
        MaskFieldUtil.foneField(txtTelefone);
    }

    @FXML
    private void evtMaskNum(KeyEvent event) {
        MaskFieldUtil.numericField(txtNumero);
    }

    @FXML
    private void evtMaskSal(KeyEvent event) {
    }

    @FXML
    private void evtMaskData(MouseDragEvent event) {
    }
    
    public void aplicarEstilo()
    {
        btNovo.setStyle("-fx-background-color: " + Tema.getCor());
        btSalvar.setStyle("-fx-background-color: " + Tema.getCor());
        btAlterar.setStyle("-fx-background-color: " + Tema.getCor());
        btExcluir.setStyle("-fx-background-color: " + Tema.getCor());
        btCancelar.setStyle("-fx-background-color: " + Tema.getCor());
        btBuscar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
    }
}
