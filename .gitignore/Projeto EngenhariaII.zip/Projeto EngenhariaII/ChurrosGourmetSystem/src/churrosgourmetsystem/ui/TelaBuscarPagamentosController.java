/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlTiposDespesas;
import churrosgourmetsystem.db.entidades.TiposDespesas;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaBuscarPagamentosController implements Initializable {

    @FXML
    private BorderPane paneDados;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXButton btPesquisar;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXComboBox<String> cbCampos;
    @FXML
    private JFXDatePicker dtInicial;
    @FXML
    private JFXDatePicker dtFinal;
    @FXML
    private VBox vbTab;
    @FXML
    private TableView<Object[]> tableview;
    @FXML
    private TableColumn<Object, ?> colCod;
    @FXML
    private TableColumn<Object, ?> colDesc;
    @FXML
    private TableColumn<Object, ?> colValor;
    @FXML
    private TableColumn<Object, ?> colPagamento;
    @FXML
    private TableColumn<Object, ?> colObs;
    private ArrayList<Object[]> listDesp;
    private CtrlTiposDespesas crDesp;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        aplicarEstilo();
        cbCampos.getItems().add("Descrição");
        cbCampos.getItems().add("Valor");
        cbCampos.getItems().add("Período");
        
        colCod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        colDesc.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colValor.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colPagamento.setCellValueFactory(new PropertyValueFactory<>("dt_pagamento"));
        colObs.setCellValueFactory(new PropertyValueFactory<>("obs"));
        
        crDesp = new CtrlTiposDespesas();
        listDesp = crDesp.buscarTudo();
        tableview.setItems(FXCollections.observableArrayList(listDesp));
        System.out.println("OBS: " + listDesp.get(0)[0]);
    }    


    @FXML
    private void evtVoltar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPgmContas.fxml"));
            TelaPgmContasController.setFlagRX(0);
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);

        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtPesquisar(ActionEvent event) {
        
    }
    
     public void aplicarEstilo()
    {
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbTab.setStyle("-fx-background-color: " + Tema.getCor());
    }
}
