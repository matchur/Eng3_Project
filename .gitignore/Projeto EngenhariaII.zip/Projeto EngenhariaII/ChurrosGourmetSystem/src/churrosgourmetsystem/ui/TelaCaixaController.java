/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlCaixa;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaCaixaController implements Initializable {

    @FXML
    private AnchorPane paneDados;
    @FXML
    private JFXButton btAbrir;
    @FXML
    private JFXButton btFechar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXTextField txtAbertura;
    @FXML
    private JFXTextField txtFechamento;
    @FXML
    private JFXDatePicker txtData;
    @FXML
    private JFXButton btBuscar;
    private static int flag = 0;
    private CtrlCaixa crCaixa;
    private static double caixaAtual = 0;
    private static int codCaixaAtual = 0;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        limparcomponentes();
        txtData.setDisable(true);
        aplicarEstilo();
        if(flag == 0)
        {
            habilitarcomponentes(true, false);
            habilitarbotoes(true, false, true, true);
        }
        else
        {
            crCaixa = new CtrlCaixa(0, 0, 0, LocalDate.now());
            crCaixa.buscar();
            txtAbertura.setText(""+crCaixa.getValorAbertura());
            txtData.setValue(crCaixa.getData());
            
            txtFechamento.setText(""+caixaAtual);
            habilitarcomponentes(false, true);
            habilitarbotoes(false, true, true, true);
        }
    }    

    @FXML
    private void evtAbrir(ActionEvent event) {
        double valor;
        try{
            valor = Double.parseDouble(txtAbertura.getText());
        }catch(Exception er){
            valor = -1;}
        
        if(valor >= 0)
        {
            crCaixa = new CtrlCaixa(0, valor, 0, txtData.getValue());
            if(crCaixa.abrir()){
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Caixa aberto com sucesso!", ButtonType.OK);
                a.showAndWait();
                flag = 1;
                
                caixaAtual = valor;
                habilitarcomponentes(false, true);
                habilitarbotoes(false, true, true, true);
                crCaixa.buscar();
                codCaixaAtual = crCaixa.getCod();
                System.out.println("crCod: " + codCaixaAtual);
            }
            else{
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir caixa!", ButtonType.OK);
                a.showAndWait();
            }
        }
    }

    @FXML
    private void evtFechar(ActionEvent event) {
        double valor;
        try{
            valor = Double.parseDouble(txtFechamento.getText());
        }catch(Exception er){
            valor = -5000;}
        
        if(valor >= -5000)
        {
            crCaixa.setFechamento(valor);
            if(crCaixa.fechar()){
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Caixa fechado com sucesso!", ButtonType.OK);
                a.showAndWait();
                flag = 0;
                System.out.println("Valor: " + caixaAtual);
            }
            else{
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao fechar caixa!", ButtonType.OK);
                a.showAndWait();
            }
        }
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
    }

    @FXML
    private void evtBuscar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscarCaixa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de busca de caixa!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        TelaCaixaController.flag = flag;
    }
    
    private void habilitarbotoes(boolean v1, boolean v2, boolean v3, boolean v4)
    {
        btAbrir.setDisable(!v1);
        btFechar.setDisable(!v2);
        btBuscar.setDisable(!v3);
        btVoltar.setDisable(!v4);
    }
    
    private void habilitarcomponentes(boolean v1, boolean v2)
    {
        txtAbertura.setDisable(!v1);
        txtFechamento.setDisable(!v2);
    }
    
    private void limparcomponentes()
    {
        txtAbertura.setText("");
        txtFechamento.setText("");
        txtData.setValue(LocalDate.now());
    }
    
    private void aplicarEstilo()
    {
        btAbrir.setStyle("-fx-background-color: " + Tema.getCor());
        btBuscar.setStyle("-fx-background-color: " + Tema.getCor());
        btFechar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
    }

    public static double getCaixaAtual() {
        return caixaAtual;
    }

    public static void setCaixaAtual(double valor) {
        TelaCaixaController.caixaAtual += valor;
    }
    
    public static int getCodCaixaAtual() {
        return codCaixaAtual;
    }
}
