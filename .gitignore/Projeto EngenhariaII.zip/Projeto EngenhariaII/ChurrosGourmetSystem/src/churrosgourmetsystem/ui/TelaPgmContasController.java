package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlPgDespesas;
import churrosgourmetsystem.db.controladoras.CtrlTiposDespesas;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaPgmContasController implements Initializable {

    @FXML
    private JFXButton btPagar;
    @FXML
    private JFXButton btBuscar;
    @FXML
    private JFXButton btCancelar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXTextField txtDescricao;
    @FXML
    private JFXTextField txtObs;
    @FXML
    private Spinner<Integer> txtSpinner;
    @FXML
    private JFXTextField txtValorPago;
    @FXML
    private JFXDatePicker txtDataPgm;
    @FXML
    private JFXTextField txtCod;
    @FXML
    private JFXTextField txtVlrRestante;
    @FXML
    private JFXTextField txtObsPagamento;
    @FXML
    private JFXTextField txtParRestante;
    @FXML
    private AnchorPane paneDados;
    private static int flagRX = 0;
    private double vlrSug = 0;
    private int despRest = 0;
    @FXML
    private JFXButton btPagamentos;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btPagamentos.setVisible(false);
        flagRX = 0;
        aplicarEstilo();
        desabilitarcomps();
        if(TelaBuscarDespesasController.getFlag() == 1)
        {
            habilitarbotoes(true, true, true, true);
            exibirDespesa(TelaBuscarDespesasController.getDespRect());
            TelaBuscarDespesasController.setFlag(0);
            txtSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, TelaBuscarDespesasController.getDespRect().getDesp().getParcelas(), 1));
        }
        else
        {
            limparcomps();
            desabilitarcomps();
            habilitarcomponentes(false);
            habilitarbotoes(false, true, false, true);
        }
        
        
    }

    private void exibirDespesa(CtrlTiposDespesas desp)
    {
        txtCod.setText(desp.getDesp().getCod()+"");
        txtVlrRestante.setText(desp.getDesp().getValor()+"");
        txtParRestante.setText(desp.getDesp().getParcelas()+"");
        txtDescricao.setText(desp.getDesp().getDescricao());
        txtObs.setText(desp.getDesp().getObs());
        vlrSug = Double.parseDouble(txtVlrRestante.getText()) / Double.parseDouble(txtParRestante.getText());
        txtValorPago.setText("" + vlrSug);
        despRest = Integer.parseInt(txtParRestante.getText());
    }

    @FXML
    private void evtPagar(ActionEvent event) {
        if(TelaCaixaController.getCodCaixaAtual()!= 0)
        {
            double vlr = 0;
            try{
                vlr = Double.parseDouble(txtValorPago.getText()); 
            }catch(Exception er){
               vlr = -1; 
            }

            if(vlr > 0)
            {
                if(txtDataPgm.getValue() != null)
                {
                    CtrlPgDespesas crPg = new CtrlPgDespesas(1, TelaBuscarDespesasController.getDespRect().getDesp().getCod(), TelaCaixaController.getCodCaixaAtual(), txtSpinner.getValue(), txtObsPagamento.getText(), txtDataPgm.getValue(), null, vlr);
                    if(crPg.salvar())
                    {
                        //Atualizar mensalidades e valor restante.
                        if(vlr >= vlrSug)
                            despRest = despRest - 1;
                        
                        double vlrAtualizado = Double.parseDouble(txtVlrRestante.getText()) - vlr;
                        CtrlTiposDespesas crDesp = new CtrlTiposDespesas();
                        if (crDesp.alterarS(TelaBuscarDespesasController.getDespRect().getDesp().getCod(), vlrAtualizado, despRest))
                        {
                            Alert a = new Alert(Alert.AlertType.INFORMATION, "Despesa paga com sucesso!", ButtonType.OK);
                            a.showAndWait();
                            
                            limparcomps();
                            desabilitarcomps();
                            habilitarcomponentes(false);
                            habilitarbotoes(false, true, false, true);
                            
                            TelaCaixaController.setCaixaAtual(-vlr);
                        }
                        else
                        {
                            Alert a = new Alert(Alert.AlertType.ERROR, "Erro: A despesa não foi paga!", ButtonType.OK);
                            a.showAndWait();
                        }
                                
                        
                    }
                    else
                    {
                        Alert a = new Alert(Alert.AlertType.ERROR, "Erro: A despesa não foi paga!", ButtonType.OK);
                        a.showAndWait();
                    }
                }
                else
                {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Digite uma data válida!", ButtonType.OK);
                    a.showAndWait();
                }
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Digite um valor válido!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Abra o caixa!", ButtonType.OK);
            a.showAndWait();
        }
            
    }

    @FXML
    private void evtBuscar(ActionEvent event) {
        try{
            flagRX = 1;
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscarDespesas.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de busca de despesas!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCancelar(ActionEvent event) {
        limparcomps();
        desabilitarcomps();
        habilitarbotoes(false, true, false, true);
        habilitarcomponentes(false);
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao voltar para a tela principal!", ButtonType.OK);
                a.showAndWait();
            }
    }
    
    public void aplicarEstilo()
    {
        btPagar.setStyle("-fx-background-color: " + Tema.getCor());;
        btCancelar.setStyle("-fx-background-color: " + Tema.getCor());
        btBuscar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        btPagamentos.setStyle("-fx-background-color: " + Tema.getCor());
    }

    public static int getFlagRX() {
        return flagRX;
    }

    public static void setFlagRX(int flagRX) {
        TelaPgmContasController.flagRX = flagRX;
    }
    
    private void habilitarbotoes(boolean v1, boolean v2, boolean v3, boolean v4)
    {
        btPagar.setDisable(!v1);
        btBuscar.setDisable(!v2);
        btCancelar.setDisable(!v3);
        btVoltar.setDisable(!v4);
    }
    
    private void desabilitarcomps()
    {
        txtCod.setDisable(true);
        txtVlrRestante.setDisable(true);
        txtParRestante.setDisable(true);
        txtDescricao.setDisable(true);
        txtObs.setDisable(true);
    }
    
    private void habilitarcomponentes(boolean v1)
    {
        txtSpinner.setDisable(!v1);
        txtValorPago.setDisable(!v1);
        txtDataPgm.setDisable(!v1);
        txtObsPagamento.setDisable(!v1);
    }
    
    private void limparcomps()
    {
        txtCod.setText("");
        txtVlrRestante.setText("");
        txtParRestante.setText("");
        txtDescricao.setText("");
        txtObs.setText("");
        //txtSpinner.setValueFactory(1);
        txtValorPago.setText("");
        txtDataPgm.setValue(LocalDate.now());
        txtObsPagamento.setText("");
    }

    @FXML
    private void evtPagamentos(ActionEvent event) {
         /*try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscarPagamentos.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de busca de pagamentos!", ButtonType.OK);
            a.showAndWait();
        }*/
    }
    
}
