/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlFuncionario;
import churrosgourmetsystem.db.controladoras.CtrlTiposDespesas;
import churrosgourmetsystem.db.entidades.TiposDespesas;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaBuscarDespesasController implements Initializable {

    @FXML
    private JFXButton btConfirmar;
    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXButton btPesquisar;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXComboBox<String> cbCampos;
    @FXML
    private VBox vbTab;
    @FXML
    private TableView<TiposDespesas> tableview;
    @FXML
    private TableColumn<String, String> colCod;
    @FXML
    private TableColumn<String, String> colNome;
    @FXML
    private TableColumn<String, String> colNome1;
    @FXML
    private TableColumn<String, String> colRg;
    private ArrayList<TiposDespesas> listDesp;
    private CtrlTiposDespesas crDesp;
    private static int flag = 0;
    private static CtrlTiposDespesas despRect = null;
    @FXML
    private BorderPane paneDados;
    @FXML
    private TableColumn<String, String> colPar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        cbCampos.getItems().add("Descrição");
        cbCampos.getItems().add("Valor");
        cbCampos.getItems().add("Funcionário responsável");
        
        colCod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colNome1.setCellValueFactory(new PropertyValueFactory<>("valor"));
        colRg.setCellValueFactory(new PropertyValueFactory<>("codFunc"));
        colPar.setCellValueFactory(new PropertyValueFactory<>("parcelas"));
        
        crDesp = new CtrlTiposDespesas();
        if(TelaPgmContasController.getFlagRX() == 1)
            listDesp = crDesp.buscarVrau("");
        else
            listDesp = crDesp.buscar("");
        
        tableview.setItems(FXCollections.observableArrayList(listDesp));
    }    

    @FXML
    private void evtConfirmar(ActionEvent event) {
        if(TelaPgmContasController.getFlagRX() == 1)
        {
            try{
                flag = 1;
                int cod = tableview.getSelectionModel().getSelectedItem().getCod();
                TiposDespesas desp = crDesp.buscarC(cod);

                despRect = new CtrlTiposDespesas(desp);

                Parent root = FXMLLoader.load(getClass().getResource("TelaPgmContas.fxml"));
                TelaPgmContasController.setFlagRX(0);
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            try{
                flag = 1;
                int cod = tableview.getSelectionModel().getSelectedItem().getCod();
                TiposDespesas desp = crDesp.buscarC(cod);

                despRect = new CtrlTiposDespesas(desp);

                Parent root = FXMLLoader.load(getClass().getResource("TelaCadDespesas.fxml"));
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
        }
            
    }

    @FXML
    private void evtVoltar(ActionEvent event) {
        if(TelaPgmContasController.getFlagRX() == 1)
        {
            try{
                flag = 0;
                Parent root = FXMLLoader.load(getClass().getResource("TelaPgmContas.fxml"));
                TelaPgmContasController.setFlagRX(0);
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            try{
                flag = 0;
                Parent root = FXMLLoader.load(getClass().getResource("TelaCadDespesas.fxml"));
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
                a.showAndWait();
            }
        }
            
    }

    @FXML
    private void evtPesquisar(ActionEvent event) {
        if(TelaPgmContasController.getFlagRX() == 1)
        {
            System.out.println("Chegou aqui.");
            if(cbCampos.getSelectionModel().getSelectedIndex() == 0) //Nome
            {
                listDesp = crDesp.buscarP("descricao ilike ", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else if (cbCampos.getSelectionModel().getSelectedIndex() == 1) //RG
            {
                listDesp = crDesp.buscarP2("valor", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else if (cbCampos.getSelectionModel().getSelectedIndex() == 2) //CPF
            {
                listDesp = crDesp.buscarP2("codfunc", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Selecione algum campo de pesquisa!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            if(cbCampos.getSelectionModel().getSelectedIndex() == 0) //Nome
            {
                listDesp = crDesp.buscarN("descricao ilike ", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else if (cbCampos.getSelectionModel().getSelectedIndex() == 1) //RG
            {
                listDesp = crDesp.buscarZ("valor", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else if (cbCampos.getSelectionModel().getSelectedIndex() == 2) //CPF
            {
                listDesp = crDesp.buscarZ("codfunc", txtPesquisa.getText());
                tableview.setItems(FXCollections.observableArrayList(listDesp));
            }
            else
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Selecione algum campo de pesquisa!", ButtonType.OK);
                a.showAndWait();
            }
        }
        
            
    }
    
    public void aplicarEstilo()
    {
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btConfirmar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbTab.setStyle("-fx-background-color: " + Tema.getCor());
        
    }

    public static int getFlag() {
        return flag;
    }

    public static void setFlag(int flag) {
        TelaBuscarDespesasController.flag = flag;
    }

    public static CtrlTiposDespesas getDespRect() {
        return despRect;
    }

    public static void setDespRect(CtrlTiposDespesas despRect) {
        TelaBuscarDespesasController.despRect = despRect;
    }
    
    
}
