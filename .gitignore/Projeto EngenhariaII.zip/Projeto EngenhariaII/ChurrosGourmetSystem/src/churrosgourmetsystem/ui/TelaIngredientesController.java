
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.controladoras.CtrlIngredientes;
import churrosgourmetsystem.util.Tema;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class TelaIngredientesController implements Initializable {

    @FXML
    private JFXTextField tf_desc;
    @FXML
    private JFXTextField tf_qtdes;
    @FXML
    private JFXTextField tf_pesliq;
    @FXML
    private Label lb_cod;
    @FXML
    private Label lb_aten1;
    @FXML
    private Label lb_aten2;
    @FXML
    private JFXTextField tf_obs;
    @FXML
    private ComboBox<String> cb_ing;
    @FXML
    private Label lb_aten3;
    @FXML
    private JFXButton bt_novo;
    @FXML
    private JFXButton bt_salvar;
    @FXML
    private JFXButton bt_pesquisar;
    @FXML
    private JFXButton bt_cancelar;
    @FXML
    private Label lb_aten4;
    
    private Ingredientes classe;
    
    private CtrlIngredientes CTRL = new CtrlIngredientes();
    @FXML
    private JFXButton bt_excluir;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private BorderPane paneDados;
    @FXML
    private VBox vbCod;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        if(TelaPesquisaIngredienteController.getFlag() == 1)
        {
            setFieldsCadastro(TelaPesquisaIngredienteController.getClasse());
        }
        else
          setDisable(true);  
            cb_ing.getItems().addAll("Kg","L");
        
        
    }    

    @FXML
    private void clkCancelar(ActionEvent event)
    {
        clear();
        setDisable(true);
    }
    
    private void setFieldsCadastro(Ingredientes classe)
    {        
        int i = classe.getCod();
            lb_cod.setText(Integer.toString(classe.getCod()));
            tf_desc.setText(classe.getDesc());
            tf_obs.setText(classe.getObs());
            tf_pesliq.setText(Double.toString(classe.getQtdun()));
            tf_qtdes.setText(Integer.toString(classe.getQtdes()));
            cb_ing.setValue(classe.getTipo());
          
    }
    
    private void setDisable(boolean x)
    {
        tf_desc.setDisable(x);
        tf_obs.setDisable(x);
        tf_pesliq.setDisable(x);
        tf_qtdes.setDisable(x);
        
        bt_salvar.setDisable(x);
        bt_cancelar.setDisable(x);
        bt_excluir.setDisable(x);
        
        cb_ing.setDisable(x);
        
        lb_aten1.setText("");
        lb_aten2.setText("");
        lb_aten3.setText("");
        
        lb_cod.setText("Código");
    }
     
    
    

    @FXML
    private void clkNovo(ActionEvent event) 
    {
        setDisable(false);
    }

    @FXML
    private void clkSalvar(ActionEvent event) 
    {
        lb_aten1.setText("");
        lb_aten2.setText("");
        lb_aten3.setText("");
        lb_aten4.setText("");
        
        if(tf_desc.getText().length() > 0)
        {
            if(tf_qtdes.getText().length() > 0 && tryParseInt(tf_qtdes.getText()))
            {
                if(tf_pesliq.getText().length() > 0 && tryParseDouble(tf_pesliq.getText()))
                {
                    if(cb_ing.getValue().equals("Kg") || cb_ing.getValue().equals("L"))
                    {
                        if(lb_cod.getText().equals("Código"))
                        {
                            classe = new Ingredientes(0, tf_desc.getText(), Integer.parseInt(tf_qtdes.getText()), tf_obs.getText(), Integer.parseInt(tf_pesliq.getText()), retTipo(cb_ing.getValue()));
                            CTRL.salvar(classe);
                        }
                        else
                        {
                            classe = new Ingredientes(Integer.parseInt(lb_cod.getText()), tf_desc.getText(), Integer.parseInt(tf_qtdes.getText()), tf_obs.getText(), Integer.parseInt(tf_pesliq.getText()), retTipo(cb_ing.getValue()));
                            CTRL.update(classe);
                        }
                        
                    }
                    else
                        lb_aten4.setText("*");
                }
                else
                  lb_aten3.setText("*");  
            }
            else
                lb_aten2.setText("*");
        }
        else
          lb_aten1.setText("*");  
    }

    private char retTipo(String value)
    {
        if(value == "Kg")
            return 'k';
        else
            return 'l';
    }
    
    private boolean tryParseInt(String value) {  
     try {  
         Integer.parseInt(value);  
         return true;  
      } catch (NumberFormatException e) {  
         return false;  
      }  
    }
    
    private boolean tryParseDouble(String value) {  
     try {  
         Double.parseDouble(value);  
         return true;  
      } catch (NumberFormatException e) {  
         return false;  
      }  
    }

    @FXML
    private void clkExcluir(ActionEvent event) {
        if(CTRL.lookDB(Integer.parseInt(lb_cod.getText())) > 0)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Voce possui churros associados a esse ingrediente!!!\n"
                    + "para que possua a integridade dos dados por favor retire o ingrediente do churros", ButtonType.OK);
            a.showAndWait();
        }
        else
        {
            CTRL.excluir(Integer.parseInt(lb_cod.getText()));
            clear();
        }
    }
    
    private void clearFields()
    {
        tf_desc.setText("");
        tf_obs.setText("");
        tf_pesliq.setText("");
        tf_qtdes.setText("");
    }
    
    private void clear()
    {
        lb_cod.setText("Código");
        tf_desc.setText("");
        tf_obs.setText("");
        tf_pesliq.setText("");
        cb_ing.setValue("");
        tf_qtdes.setText("");
    }
    
    @FXML
    private void clkVoltar(ActionEvent event)
    {
     clearFields();
     try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalCadastro.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela principal!", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_pesquisar(ActionEvent event) 
    {
        clearFields();
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPesquisaIngrediente.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de pesquisa!", ButtonType.OK);
                a.showAndWait();
            }
    }
    
    public void aplicarEstilo()
    {
        bt_novo.setStyle("-fx-background-color: " + Tema.getCor());
        bt_salvar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_excluir.setStyle("-fx-background-color: " + Tema.getCor());
        bt_cancelar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_pesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbCod.setStyle("-fx-background-color: " + Tema.getCor());
    }
}
