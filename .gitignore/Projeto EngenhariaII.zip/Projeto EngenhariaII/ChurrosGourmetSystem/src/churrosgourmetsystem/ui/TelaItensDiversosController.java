/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlItensDiversos;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import static churrosgourmetsystem.ui.TelaBuscaItensDiversosController.item;
import churrosgourmetsystem.util.MaskFieldUtil;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Hiroshi
 */
public class TelaItensDiversosController implements Initializable {

    @FXML
    private JFXTextField tbNome;
    @FXML
    private JFXTextField tbValor;
    @FXML
    private JFXTextField tbFornecedor;

    private String nome, fornecedor, tipo;
    private double valor;
    private JFXTextField tbTipo;
    @FXML
    private BorderPane panedados;
    private int codigo;
    @FXML
    private Button btnNew;
    private Boolean busca;
    @FXML
    private JFXButton btnSave;
    @FXML
    private JFXButton btnSearch;
    @FXML
    private JFXButton btnAlt;
    @FXML
    private JFXButton btDelete;
    @FXML
    private JFXButton btnClean;
    private JFXComboBox<String> cbTipo;
    @FXML
    private JFXComboBox<String> cbTipos;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        EnableOrDisable(true);
        btnNew.setDisable(false);
        btnSearch.setDisable(false);
        AdicionandoCombobox();
        if(TelaBuscaItensDiversosController.item!=null)
        {
            ItensDiversos item = TelaBuscaItensDiversosController.item;
            TelaBuscaItensDiversosController.item=null;
            codigo = item.getCodigo();
            tbNome.setText(item.getNome());
            tbFornecedor.setText(item.getFornecedor());
            tbValor.setText(""+item.getValor());
            EnableOrDisable(false);
            btnNew.setDisable(true);
            btnSave.setDisable(true);
            btnSearch.setDisable(true);
        }

    }    

    @FXML
    private void btnNovo(ActionEvent event) {
        EnableOrDisable(false);
        btnNew.setDisable(true);
        btnSave.setDisable(false);
        btnAlt.setDisable(true);
        btnSearch.setDisable(true);
    }

    @FXML
    private void btnGravar(ActionEvent event) {
        CtrlItensDiversos ctrlitens;
        ItensDiversos itens;
  
        if(!ValidaCampos())
        {
            try
            {
                nome = tbNome.getText();
                valor = Double.parseDouble(tbValor.getText());
                fornecedor = tbFornecedor.getText();
                tipo = cbTipos.getItems().get(cbTipos.getSelectionModel().getSelectedIndex());
                itens = new ItensDiversos(0, nome, valor, tipo, fornecedor,0);
                ctrlitens = new CtrlItensDiversos();
                
                if(ctrlitens.salvar(itens))
                {
                    Alert a = new Alert(Alert.AlertType.INFORMATION, "Item Cadastrado com sucesso!", ButtonType.OK);
                    a.showAndWait();
                }
                else
                    JOptionPane.showMessageDialog(null, "Insira todos os campos necessario!");
                        EnableOrDisable(true);
                btnNew.setDisable(false);
                btnSearch.setDisable(false);
                Limpa();
            }
            catch(Exception e)
            {System.out.println("" + e);}
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Preencha todos os campos!", ButtonType.OK);
            a.showAndWait();    
        }
    }

    @FXML
    private void btnBuscar(ActionEvent event) {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaBuscaItensDiversos.fxml"));
            panedados.getChildren().clear();
            panedados.getChildren().add(root);
        }catch(Exception er){
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de cadastro!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void btnAlterar(ActionEvent event) {
        ItensDiversos item;
        CtrlItensDiversos ctrlI;
        ctrlI = new CtrlItensDiversos();
        Boolean certo;
        if(!ValidaCampos())
        {
            try
            {
                nome = tbNome.getText();
                valor = Double.parseDouble(tbValor.getText());
                fornecedor = tbFornecedor.getText();
                tipo = cbTipos.getItems().get(cbTipos.getSelectionModel().getSelectedIndex());
                item = new ItensDiversos(codigo,nome,valor,tipo,fornecedor,0);
                certo = ctrlI.Alterar(item);
                EnableOrDisable(true);
                btnNew.setDisable(false);
                btnSearch.setDisable(false);
                Limpa();
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Item alterado com sucesso!", ButtonType.OK);
                a.showAndWait();
            }catch(Exception e)
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Erro ao alterar o item", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Preencha todos os campos!", ButtonType.OK);
            a.showAndWait();   
        }
    }


    
    @FXML
    private void btnLimpar(ActionEvent event) {
        tbNome.setText("");
        tbValor.setText("");
        tbFornecedor.setText("");
    }
    public void Limpa()
    {
        tbNome.setText("");
        tbValor.setText("");
        tbFornecedor.setText(""); 
    }
    public void EnableOrDisable(Boolean flag)
    {
        tbNome.setDisable(flag);
        tbValor.setDisable(flag);
        tbFornecedor.setDisable(flag);
        btnClean.setDisable(flag);
        btnNew.setDisable(flag);
        btnSave.setDisable(flag);
        btnSearch.setDisable(flag);
        btnAlt.setDisable(flag);
    }
    
    public Boolean ValidaCampos()
    {
        if(tbNome.getText().equals("") || tbValor.getText().equals("") || tbFornecedor.getText().equals("") || cbTipos.getSelectionModel().getSelectedIndex() == -1)
            return true;
        return false;
    }

    @FXML
    private void mascaraValor(KeyEvent event) {
        MaskFieldUtil.numericField(tbValor);
        MaskFieldUtil.onlyDigitsValue(tbValor);
    }

    @FXML
    private void btnDeletar(ActionEvent event) {
        CtrlItensDiversos ctrlI = new CtrlItensDiversos();

        try 
        {
            ctrlI.excluir(tbNome.getText());
            EnableOrDisable(true);
            btnNew.setDisable(false);
            btnSearch.setDisable(false);
            Limpa();
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Item excluido com sucesso!", ButtonType.OK);
            a.showAndWait();
        } catch (Exception e) {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Erro ao exlcuir o item", ButtonType.OK);
            a.showAndWait();
        }
    }
    public void aplicarEstilo()
    {
        btnAlt.setStyle("-fx-background-color: " + Tema.getCor());
        btnClean.setStyle("-fx-background-color: " + Tema.getCor());
        btnNew.setStyle("-fx-background-color: " + Tema.getCor());
        btnSave.setStyle("-fx-background-color: " + Tema.getCor());
        btnSearch.setStyle("-fx-background-color: " + Tema.getCor());
        btDelete.setStyle("-fx-background-color: " + Tema.getCor());
    }

    public void AdicionandoCombobox()
    {
        cbTipos.getItems().add("Bebida");
        cbTipos.getItems().add("Doce");
        cbTipos.getItems().add("Outros");
    }
    
}
