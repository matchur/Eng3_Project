/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlItensDiversos;
import churrosgourmetsystem.db.controladoras.CtrlParametrizacao;
import churrosgourmetsystem.db.entidades.Parametrizacao;
import churrosgourmetsystem.util.Banco;
import churrosgourmetsystem.util.ConversorImagem;
import churrosgourmetsystem.util.MaskFieldUtil;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXColorPicker;
import com.jfoenix.controls.JFXTextField;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author hiroshi
 */
public class TelaParametrizacaoController implements Initializable {

    @FXML
    private JFXTextField tbRazao;
    @FXML
    private JFXTextField tbEnd;
    //private JFXTextField tbCor;
    @FXML
    private JFXTextField tbSite;
    @FXML
    private JFXTextField tbEmail;
    @FXML
    private JFXTextField tbTelefone;
    @FXML
    private JFXTextField tbCEP;
    @FXML
    private JFXTextField tbUF;
    @FXML
    private JFXTextField tbCid;
    @FXML
    private JFXTextField tbNum;
    @FXML
    private JFXTextField tbComp;
    @FXML
    private JFXTextField tbBairro;
    @FXML
    private Button inserir;
    @FXML
    private Button alterar;
    public Parametrizacao p;
    static String razao, endereco, cor, site, email, telefone, UF, cep, cidade, complemento, bairro, nomeFantasia;
    static int numero;
    @FXML
    private JFXButton btCancelar;
    @FXML
    private JFXButton btSair;
    @FXML
    private JFXColorPicker tbCor;
    @FXML
    private JFXButton btBuscar;
    @FXML
    private ImageView imageview;
    byte[] bArr = null;
    @FXML
    private JFXTextField tbNomeFantasia;
    @FXML
    private BorderPane ancPane;
    private boolean flag;
    @FXML
    private Label lblLogo;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        CtrlParametrizacao crP = new CtrlParametrizacao();
        flag = crP.buscaN();
        if(flag) //Se retornar true, ja tem inserido
        {
            habilitarTF(false);
            habilitarBotoes(true, false, false, false, true);
            btSair.setText("Voltar");
        }
        else //Nao tem ninguem inserido
            habilitarBotoes(true, true, false, true, true);
    }    

    @FXML
    private void btnInserir(ActionEvent event) {
        CtrlParametrizacao ctrlip;
        Parametrizacao p = null;
            try
            {
                razao = tbRazao.getText();
                endereco = tbEnd.getText();
                cor = toRGBCode(tbCor.getValue());
                site = tbSite.getText();
                email = tbEmail.getText();
                telefone = tbTelefone.getText();
                UF = tbUF.getText();
                cep = tbCEP.getText();
                cidade = tbCid.getText();
                complemento = tbComp.getText();
                bairro = tbBairro.getText();
                numero = Integer.parseInt(tbNum.getText());
                nomeFantasia = tbNomeFantasia.getText();
                
                p = new Parametrizacao
                        (0, razao, cor, site, email, telefone,endereco,cep,UF,cidade,numero,complemento,bairro,nomeFantasia,bArr);
                ctrlip = new CtrlParametrizacao();
                
                
                if(ctrlip.gravar(p))
                {
                    Alert a = new Alert(Alert.AlertType.INFORMATION, "Parametrização Cadastrado com sucesso!", ButtonType.OK);
                    a.showAndWait();
                    
                    try{
                        Tema.setCor(p.getCor());
                        Stage stage = (Stage)ancPane.getScene().getWindow();
                        Parent root;
                        
                        ResultSet rs = Banco.con.consultar("select * from funcionario");
                        System.out.println("Chegou aqui");
                        if(rs.next())
                        {
                            root = FXMLLoader.load(getClass().getResource("TelaLogin.fxml"));
                            stage.setResizable(false);
                            stage.setWidth(600);
                            stage.setHeight(263);
                            
                        }  
                        else  
                        {
                            root = FXMLLoader.load(getClass().getResource("TelaCadFuncionario.fxml"));
                            stage.setResizable(false);
                            stage.setWidth(650);
                            stage.setHeight(630);
                        }
                        ancPane.getChildren().clear();
                        ancPane.getChildren().add(root);

                    }catch(Exception er){
                        Alert ar = new Alert(Alert.AlertType.ERROR, "Erro ao voltar a tela de login!", ButtonType.OK);
                        ar.showAndWait();
                    }
                }
                else
                {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Insira todos os campos necessários!", ButtonType.OK);
                    a.showAndWait();
                }
                
            }
            catch(Exception e)
            {System.out.println("" + e);}
            //Platform.exit();
    }

    
    public String toRGBCode( Color color )
    {
        return String.format( "#%02X%02X%02X",
            (int)( color.getRed() * 255 ),
            (int)( color.getGreen() * 255 ),
            (int)( color.getBlue() * 255 ) );
    }

    @FXML
    private void evtAlterarImg1(MouseEvent event) {
        clkAbrir();
    }

    @FXML
    private void evtAlterarImg2(MouseEvent event) {
        clkAbrir();
    }
    
    public void aplicarEstilo()
    {
        inserir.setStyle("-fx-background-color: " + Tema.getCor());
        btCancelar.setStyle("-fx-background-color: " + Tema.getCor());
        btSair.setStyle("-fx-background-color: " + Tema.getCor());
        alterar.setStyle("-fx-background-color: " + Tema.getCor());
        btBuscar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
    private void clkAbrir()
    {
        Image img;
        FileChooser fc = new FileChooser();
        FileChooser.ExtensionFilter filterJPG = new FileChooser.ExtensionFilter("JPEG (*.jpg, *.jpeg)", "*.jpg", "*.jpeg");
        FileChooser.ExtensionFilter filterGIF = new FileChooser.ExtensionFilter("GIF (*.gif)", "*.gif");
        FileChooser.ExtensionFilter filterPNG = new FileChooser.ExtensionFilter("PNG (*.png)", "*.png");
        
        fc.getExtensionFilters().addAll(filterJPG, filterGIF, filterPNG);
        
        fc.setInitialDirectory(new File("C:\\"));
        File arq = fc.showOpenDialog(null);
        
        if(arq != null)
        {
            img = new Image(arq.toURI().toString());
            imageview.setImage(img);
            bArr = ConversorImagem.imageToByte(img);
        }
    }

    @FXML
    private void btnBuscar(ActionEvent event) {
        String color;
        Color cor;
        double r, g, b;
        alterar.setDisable(false);
        inserir.setDisable(true);
        CtrlParametrizacao ctrlp = new CtrlParametrizacao();
        p = null;
        
        p = ctrlp.busca();
        
        tbRazao.setText(p.getRazao());
        color = p.getCor();
        r = Integer.valueOf(color.substring( 1, 3 ), 16 );
        g = Integer.valueOf( color.substring( 3, 5 ), 16 );
        b = Integer.valueOf( color.substring( 5, 7 ), 16 );
        cor = new Color(r/255, g/255, b/255, 1);
        tbCor.setValue(cor);
        
        tbSite.setText(p.getSite());
        tbEmail.setText(p.getEmail());
        tbTelefone.setText(p.getTelefone());
        tbEnd.setText(p.getEndereco());
        tbCEP.setText(p.getCep());
        tbUF.setText(p.getUf());
        tbCid.setText(p.getCidade());
        tbNum.setText(""+p.getNumero());
        tbComp.setText(p.getComplemento());
        tbBairro.setText(p.getBairro());
        tbNomeFantasia.setText(p.getNomeFantasia());
        try
        {
            bArr = p.getFoto();
            imageview.setImage(ConversorImagem.byteToImage(bArr));
        }catch(Exception er){}
        
        if(TelaLoginController.getAcesso() == 1)
        {
            habilitarTF(true);
            habilitarBotoes(true, false, true, true, true);
        }
        else
        {
            habilitarTF(false);
            habilitarBotoes(true, false, false, true, true);
        }
    }

    @FXML
    private void btnAlterar(ActionEvent event) {
        CtrlParametrizacao ctrlip;
        razao = tbRazao.getText();
        endereco = tbEnd.getText();
        cor = toRGBCode(tbCor.getValue());
        site = tbSite.getText();
        email = tbEmail.getText();
        telefone = tbTelefone.getText();
        UF = tbUF.getText();
        cep = tbCEP.getText();
        cidade = tbCid.getText();
        complemento = tbComp.getText();
        bairro = tbBairro.getText();
        numero = Integer.parseInt(tbNum.getText());
        nomeFantasia = tbNomeFantasia.getText();

        p = new Parametrizacao
                (0,razao, cor, site, email, telefone,endereco,cep,UF,cidade,numero,complemento,bairro,nomeFantasia,bArr);
        ctrlip = new CtrlParametrizacao();
        if(ctrlip.altera(p))
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Parametrização Cadastrado com sucesso! Por favor reinicie o sistema para aplicar as configurações!", ButtonType.OK);
            a.showAndWait();
            Platform.exit();
            
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Insira todos os campos necessários!", ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    private void evtCancelar(ActionEvent event) {
        limparComponentes();
        if(flag) //Se retornar true, ja tem inserido
        {
            habilitarTF(false);
            habilitarBotoes(true, false, false, false, true);
            btSair.setText("Voltar");
        }
        else //Nao tem ninguem inserido
            habilitarBotoes(true, true, false, true, true);
    }
    

    @FXML
    private void evtSair(ActionEvent event) {
        limparComponentes();
        if(btSair.getText().equals("Voltar"))
        {
            try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPrincipalPnControle.fxml"));
            ancPane.getChildren().clear();
            ancPane.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de painel de controle!", ButtonType.OK);
                a.showAndWait();
            }
        }
        else
            Platform.exit();
    }

    @FXML
    private void evtmascara(KeyEvent event) {
        MaskFieldUtil.foneField(tbTelefone);
        
    }

    @FXML
    private void evtcep(KeyEvent event) {
        MaskFieldUtil.cepField(tbCEP);
    }

    @FXML
    private void evtmascaranum(KeyEvent event) {
        
        MaskFieldUtil.numericField(tbNum);
    }
    
    private void habilitarBotoes(boolean buscar, boolean inserir, boolean alterar, boolean cancelar, boolean sair)
    {
        btBuscar.setDisable(!buscar);
        this.inserir.setDisable(!inserir);
        this.alterar.setDisable(!alterar);
        btCancelar.setDisable(!cancelar);
        btSair.setDisable(!sair);
    }
    
    private void habilitarTF(boolean value)
    {
        tbRazao.setDisable(!value);
        tbNomeFantasia.setDisable(!value);
        tbSite.setDisable(!value);
        tbEmail.setDisable(!value);
        tbTelefone.setDisable(!value);
        tbEnd.setDisable(!value);
        tbCEP.setDisable(!value);
        tbComp.setDisable(!value);
        tbNum.setDisable(!value);
        tbBairro.setDisable(!value);
        tbCid.setDisable(!value);
        tbUF.setDisable(!value);
        tbCor.setDisable(!value);
        imageview.setDisable(!value);
        lblLogo.setDisable(!value);
        
    }
    
    private void limparComponentes()
    {
        
        tbRazao.setText("");
        tbNomeFantasia.setText("");
        tbSite.setText("");
        tbEmail.setText("");
        tbTelefone.setText("");
        tbEnd.setText("");
        tbCEP.setText("");
        tbComp.setText("");
        tbNum.setText("");
        tbBairro.setText("");
        tbCid.setText("");
        tbUF.setText("");
        imageview.setImage(new Image("churrosgourmetsystem/ui/icon/logo.png"));
        tbCor.setValue(new Color(1, 1, 1, 1));
    }
}
