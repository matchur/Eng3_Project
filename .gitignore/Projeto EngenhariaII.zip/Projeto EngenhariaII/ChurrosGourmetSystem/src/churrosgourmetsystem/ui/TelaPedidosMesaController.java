package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlMesa;
import churrosgourmetsystem.db.entidades.ProdutosMesa;
import churrosgourmetsystem.db.entidades.Tabela;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

public class TelaPedidosMesaController implements Initializable {

    @FXML
    private JFXButton bt_add;
    @FXML
    private JFXButton bt_remove;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private Label lb_total;
    @FXML
    private Label lb_preco;
    @FXML
    private ComboBox<String> cb_mesa;
    
    private CtrlMesa CTRL = new CtrlMesa();
    @FXML
    private Label lb_mesa;
    @FXML
    private TableColumn<ProdutosMesa, String> cl_prod;
    @FXML
    private TableColumn<ProdutosMesa, Integer> cl_qtd;
    @FXML
    private TableColumn<ProdutosMesa, Double> cl_val;
    @FXML
    private TableColumn<ProdutosMesa, String> cl_status;
    
    private static ObservableList<ProdutosMesa> obsDados = FXCollections.observableArrayList();
    @FXML
    private TableView<ProdutosMesa> tbv_produtos;
    @FXML
    private BorderPane paneDados;
    
    private static String mesa;
    @FXML
    private JFXButton bt_conf;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        ArrayList<String> e = new ArrayList<String>();
        
        CTRL.getMesa(e);
        cb_mesa.getItems().addAll(e);
        
        if(TelaCardapioController.flag)
        {
            boolean w = false;
            int  y = 0;
            String z;
            Tabela x = TelaCardapioController.selected_class;
            cb_mesa.setValue(mesa);
            
            setDisable(false);
            if(x.getQtd() == -1)
                 z = "C";
            else
                z = "I";
            
            if(!obsDados.isEmpty())
            {
               for(ProdutosMesa a: obsDados)
                {
                    if(a.getNome().equals(x.getDesc()))
                  {
                      obsDados.get(y).setQtd(obsDados.get(y).getQtd() + 1);
                      w = true;
                  } 
                    y++;
                } 
            }
            if(!w)
            {
                obsDados.add(new ProdutosMesa(x.getDesc(),1,x.getPreco(),"N",z)); 
            }
            
        }
        else
        {
            setDisable(true);
        }
        
            cl_prod.setCellValueFactory(new PropertyValueFactory<>("nome"));
            cl_qtd.setCellValueFactory(new PropertyValueFactory<>("qtd"));
            cl_val.setCellValueFactory(new PropertyValueFactory<>("valor"));
            cl_status.setCellValueFactory(new PropertyValueFactory<>("status"));
            
        tbv_produtos.setItems(obsDados);
     
        calculaTotal();
        aplicarEstilo();
    }    
    
    private void setDisable(boolean x)
    {
        bt_add.setDisable(x);
        bt_remove.setDisable(x);
        tbv_produtos.setDisable(x);
        bt_conf.setDisable(x);
        
    }        
    
    @FXML
    private void clkPesquisar(MouseEvent event)
    {
          obsDados.clear();
        if(cb_mesa.getValue()!= null)
        {
            mesa = cb_mesa.getValue();
            lb_mesa.setText(cb_mesa.getValue().toString());
            setDisable(false);
            CTRL.getProdutosMesa(mesa, obsDados);
            System.out.println("Erro aqui:");
            calculaTotal();
        }
        else
        {
                Alert a = new Alert(Alert.AlertType.ERROR, "Selecione uma mesa", ButtonType.OK);
            a.showAndWait();
        }
                
    }
    
    private void calculaTotal()
    {
        double total = 0.00;
        if(!obsDados.isEmpty())
        {
            for(ProdutosMesa a: obsDados)
            {
                total += (double) (a.getQtd()*a.getValor());
   
            }
            
        }
        
        lb_preco.setText(total+"");
    }
            

    @FXML
    private void clk_add(ActionEvent event)
    {
                try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaCardapio.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela cardapio: " + er.getMessage(), ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_remove(ActionEvent event) throws SQLException
    {
       if(tbv_produtos.getSelectionModel().getSelectedItem() != null) 
       {
            if(tbv_produtos.getSelectionModel().getSelectedItem().getQtd() - 1 == 0)
            {
                tbv_produtos.getItems().remove(tbv_produtos.getSelectionModel().getSelectedItem());
            }
            else
            {
                tbv_produtos.getSelectionModel().getSelectedItem().setQtd(tbv_produtos.getSelectionModel().getSelectedItem().getQtd() - 1);
            } 
            calculaTotal();
       }
       else
       {
           Alert a = new Alert(Alert.AlertType.ERROR, "Selecione um item", ButtonType.OK);
                a.showAndWait();
       }
       tbv_produtos.refresh();
    }

    @FXML
    private void clk_voltar(ActionEvent event)
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaVenda.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao Voltar", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_conf(ActionEvent event) throws SQLException 
    {
        CTRL.excluirProdutosMesa(mesa);
    CTRL.inserirProdutosMesa(mesa, obsDados, TelaLoginController.getCodFunc());
        
    }
    
     public void aplicarEstilo()
    {

        bt_remove.setStyle("-fx-background-color: " + Tema.getCor());
        bt_conf.setStyle("-fx-background-color: " + Tema.getCor());
        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
        
        bt_add.setStyle("-fx-background-color: " + Tema.getCor());

    }
}
