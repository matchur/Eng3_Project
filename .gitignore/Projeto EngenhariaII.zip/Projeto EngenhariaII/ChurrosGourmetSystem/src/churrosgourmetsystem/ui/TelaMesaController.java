package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlMesa;
import churrosgourmetsystem.db.entidades.Mesa;
import churrosgourmetsystem.db.entidades.ProdutosMesa;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;

public class TelaMesaController implements Initializable {

    @FXML
    private JFXButton bt_new;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private TableView<Mesa> tbv_mesa;
    @FXML
    private TableColumn<Mesa, Integer> cl_cod;
    @FXML
    private TableColumn<Mesa, String> cl_status;
    @FXML
    private JFXComboBox<String> cb_opcoes;
    @FXML
    private JFXButton bt_ok;
    
     private ObservableList<Mesa> obsDados = FXCollections.observableArrayList(); 
     
     private CtrlMesa CTRL = new CtrlMesa();
    @FXML
    private JFXButton bt_excluir;
    @FXML
    private BorderPane paneDados;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
    
        try 
        {
            CTRL.getMesas(obsDados);
        } catch (Exception ex) 
        {
            Logger.getLogger(TelaMesaController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            cl_cod.setCellValueFactory(new PropertyValueFactory<>("cod_mesa"));
            cl_status.setCellValueFactory(new PropertyValueFactory<>("status"));
            tbv_mesa.setItems(obsDados);
        
            
            cb_opcoes.getItems().addAll("Livre","Ocupar","Fechar");
            aplicarEstilo();
    }    

    @FXML
    private void clk_novaMesa(ActionEvent event) 
    {
        obsDados.clear();
        CTRL.abrirNovaMesa();
        try 
        {
            CTRL.getMesas(obsDados);
        } catch (Exception ex) 
        {
            Logger.getLogger(TelaMesaController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tbv_mesa.setItems(obsDados);
    }

    @FXML
    private void clk_voltar(ActionEvent event) 
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaVenda.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao Voltar", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_ok(ActionEvent event) throws SQLException 
    {
        Mesa M = tbv_mesa.getSelectionModel().getSelectedItem();
        if(M != null)
        {
            if(cb_opcoes.getValue().equals("Livre"))
            {
                if(M.getStatus().equals("O"))
                {
                    Alert a = new Alert(Alert.AlertType.ERROR, "Essa mesa esta sendo ocupada", ButtonType.OK);
                    a.showAndWait();
                }
                else
                {
                    CTRL.attMesa(M.getCod_mesa(), "L");
                      obsDados.clear();
                 CTRL.getMesas(obsDados); 
                  tbv_mesa.setItems(obsDados);
                }
            }
            else
            {
                if(cb_opcoes.getValue().equals("Ocupar"))
                {
                        if(M.getStatus().equals("F"))
                        {
                            Alert a = new Alert(Alert.AlertType.ERROR, "Essa mesa esta fechada", ButtonType.OK);
                            a.showAndWait();
                        }
                        else
                        {
                            CTRL.attMesa(M.getCod_mesa(), "O");
                              obsDados.clear();
                 CTRL.getMesas(obsDados); 
                  tbv_mesa.setItems(obsDados);
                        } 
                }
                else
                {
                        if(cb_opcoes.getValue().equals("Fechar"))
                         {
                            if(M.getStatus().equals("O"))
                            {
                                Alert a = new Alert(Alert.AlertType.ERROR, "Essa mesa esta Ocupada", ButtonType.OK);
                                a.showAndWait();
                            }
                            else
                            {
                                CTRL.attMesa(M.getCod_mesa(), "F");
                                  obsDados.clear();
                 CTRL.getMesas(obsDados); 
                  tbv_mesa.setItems(obsDados);
                            } 
                         }
                        else
                        {
                            Alert a = new Alert(Alert.AlertType.ERROR, "Tente selecionar antes uma opcao", ButtonType.OK);
                a.showAndWait();
                        }
                }
                
                
            }
        }
        else
        {
              Alert a = new Alert(Alert.AlertType.ERROR, "Tente selecionar antes um item", ButtonType.OK);
                a.showAndWait();
        }
                
                
    }
    
    @FXML
    private void clk_excluir(ActionEvent event) throws SQLException 
    {
        if(tbv_mesa.getSelectionModel().getSelectedItem() != null)
        {
            if(tbv_mesa.getSelectionModel().getSelectedItem().getStatus().equals("O"))
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Essa mesa esta Ocupada! tente deixar ela livre ou fechada antes", ButtonType.OK);
                a.showAndWait();
            }
            else
            {
               
                CTRL.excluirMesa(tbv_mesa.getSelectionModel().getSelectedItem().getCod_mesa());
                obsDados.clear();
                 CTRL.getMesas(obsDados); 
                  tbv_mesa.setItems(obsDados);
            }
        }
            
    }
    
    public void aplicarEstilo()
    {
        bt_new.setStyle("-fx-background-color: " + Tema.getCor());
        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_ok.setStyle("-fx-background-color: " + Tema.getCor());
        bt_excluir.setStyle("-fx-background-color: " + Tema.getCor());
    }
}
