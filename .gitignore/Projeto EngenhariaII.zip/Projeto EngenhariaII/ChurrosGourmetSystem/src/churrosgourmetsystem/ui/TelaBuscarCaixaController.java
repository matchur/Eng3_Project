/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlCaixa;
import churrosgourmetsystem.db.entidades.Caixa;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaBuscarCaixaController implements Initializable {

    @FXML
    private JFXButton btVoltar;
    @FXML
    private JFXButton btPesquisar;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXComboBox<String> cbCampos;
    @FXML
    private VBox vbTab;
    @FXML
    private TableView<Caixa> tableview;
    @FXML
    private TableColumn<String, String> colCod;
    @FXML
    private TableColumn<String, String> colAber;
    @FXML
    private TableColumn<String, String> colFecham;
    @FXML
    private TableColumn<String, String> colData;
    private ArrayList<Caixa>list;
    private CtrlCaixa crCaixa;
    private static int flag = 0;
    private static CtrlCaixa caixaRet = null;
    @FXML
    private AnchorPane paneDados;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aplicarEstilo();
        cbCampos.getItems().add("Código");
        //cbCampos.getItems().add("Data");
        
        colCod.setCellValueFactory(new PropertyValueFactory<>("cod_caixa"));
        colAber.setCellValueFactory(new PropertyValueFactory<>("valor_abertura"));
        colFecham.setCellValueFactory(new PropertyValueFactory<>("valor_fechamento"));
        colData.setCellValueFactory(new PropertyValueFactory<>("data"));
        
        
        crCaixa = new CtrlCaixa(0, 0, 0, LocalDate.now());
        list = crCaixa.buscarAll();
        
        tableview.setItems(FXCollections.observableArrayList(list));
    }    

    @FXML
    private void evtVoltar(ActionEvent event) {
        try{
                flag = 0;
                Parent root = FXMLLoader.load(getClass().getResource("TelaCaixa.fxml"));
                paneDados.getChildren().clear();
                paneDados.getChildren().add(root);

            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao abrir tela de caixa!", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void evtPesquisar(ActionEvent event) {
        if(cbCampos.getSelectionModel().getSelectedIndex() == 0) //Nome
        {
            list = crCaixa.buscarCod(Integer.parseInt(txtPesquisa.getText()));
            tableview.setItems(FXCollections.observableArrayList(list));
        }
        else
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Selecione algum campo de pesquisa!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void aplicarEstilo()
    {
        btPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
        btVoltar.setStyle("-fx-background-color: " + Tema.getCor());
        vbTab.setStyle("-fx-background-color: " + Tema.getCor());
        
    }
}
