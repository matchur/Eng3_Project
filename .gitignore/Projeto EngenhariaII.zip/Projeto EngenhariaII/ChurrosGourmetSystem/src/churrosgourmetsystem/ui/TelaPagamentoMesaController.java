package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlMesa;
import churrosgourmetsystem.db.entidades.ItemMesa;
import churrosgourmetsystem.db.entidades.ProdutosMesa;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javax.swing.JOptionPane;

public class TelaPagamentoMesaController implements Initializable {

    
    private CtrlMesa CTRL = new CtrlMesa();
    @FXML
    private JFXButton bt_fecharConta;

    @FXML
    private JFXButton bt_voltar;
    @FXML
    private Label lb_mesa;
    @FXML
    private Label lb_pedido;
    @FXML
    private JFXButton bt_analisar;
    @FXML
    private JFXButton bt_pagarItem;
    @FXML
    private ComboBox<String> cb_mesa;
    @FXML
    private TableColumn<ProdutosMesa, String> cl_prodM;
    @FXML
    private TableColumn<ProdutosMesa, Integer> cl_qtdM;
    @FXML
    private TableColumn<ProdutosMesa, Double> cl_precoM;
    @FXML
    private TableColumn<ProdutosMesa, String> cl_status;
    @FXML
    private TableColumn<ItemMesa, String> cl_prodI;
    @FXML
    private TableColumn<ItemMesa, Double> cl_precoI;
    @FXML
    private TableColumn<ItemMesa, Double> cl_totalPagoI;
    @FXML
    private TableView<ProdutosMesa> tbv_mesa;
    @FXML
    private TableView<ItemMesa> tbv_prod;
    
    private ObservableList<ProdutosMesa> obsDadosMesa = FXCollections.observableArrayList(); 
    private ObservableList<ItemMesa> obsDadosItem = FXCollections.observableArrayList();
    @FXML
    private TextField tf_pagar;
    @FXML
    private JFXButton bt_ok;
    @FXML
    private BorderPane paneDados;


    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {

        ArrayList<String> e = new ArrayList<>();
        
        tf_pagar.setVisible(false);
        bt_ok.setVisible(false);
       aplicarEstilo();
       try {
            CTRL.getMesa(e);
        } catch (Exception ex) {
            Logger.getLogger(TelaPedidosMesaController.class.getName()).log(Level.SEVERE, null, ex);
        }
        cb_mesa.getItems().addAll(e);
       setDisable(true);
       
       tbv_mesa.setItems(obsDadosMesa);
       tbv_prod.setItems(obsDadosItem);
       
            cl_prodM.setCellValueFactory(new PropertyValueFactory<>("nome"));
            cl_qtdM.setCellValueFactory(new PropertyValueFactory<>("qtd"));
            cl_precoM.setCellValueFactory(new PropertyValueFactory<>("valor"));
            cl_status.setCellValueFactory(new PropertyValueFactory<>("status"));
            
            cl_prodI.setCellValueFactory(new PropertyValueFactory<>("Nome"));
            cl_precoI.setCellValueFactory(new PropertyValueFactory<>("precoProd"));
            cl_totalPagoI.setCellValueFactory(new PropertyValueFactory<>("precoPago"));
      
       
    }    
    
    private void setDisable(boolean x)
    {
        bt_analisar.setDisable(x);
        bt_fecharConta.setDisable(x);
        bt_pagarItem.setDisable(x);
        
        tbv_mesa.setDisable(x);
        tbv_prod.setDisable(x);
        
    }
    private void lbND()
    {
        lb_mesa.setText("N/D");
        lb_pedido.setText("N/D");
    }
            

    @FXML
    private void clkPesquisar(MouseEvent event) throws SQLException 
    {
        obsDadosItem.clear();
        obsDadosMesa.clear();
        int CodPed = CTRL.getCodPed(cb_mesa.getValue());
        if(cb_mesa.getValue()!= null && CodPed!= -1)
        {
            setDisable(false);
            lb_pedido.setText(CodPed+"");
            lb_mesa.setText(cb_mesa.getValue()+"");
            CTRL.getProdutosMesa(cb_mesa.getValue(), obsDadosMesa);
            tbv_mesa.setItems(obsDadosMesa);
            //tbv_mesa.refresh();
        }
        else
        {
             Alert a = new Alert(Alert.AlertType.ERROR, "Selecione uma mesa que esteja com um pedido ja em aberto", ButtonType.OK);
            a.showAndWait();
            setDisable(true);
            lbND();
        }
    }

    @FXML
    private void clk_fecharConta(ActionEvent event) 
    {
        int n = JOptionPane.showConfirmDialog(null,"Todos os itens serao mudados para pagos deseja continuar?","Confirmacao",JOptionPane.YES_NO_OPTION);
                if(n == JOptionPane.YES_OPTION)//
                {
                    CTRL.acertarMesa(lb_mesa.getText(),lb_pedido.getText());
                    TelaCaixaController.setCaixaAtual(calculaTotal()+TelaCaixaController.getCaixaAtual());//TA ATUALIZANDO O CAIXA AQUI <--------------------------------------------------
                    Alert a = new Alert(Alert.AlertType.ERROR, "A mesa foi fechada e os produtos foram pagos\n"
                            + "Recebido:"+ calculaTotal(), ButtonType.OK);
                    a.showAndWait();
                    lbND();
                    cb_mesa.setItems(null);
                    obsDadosItem.clear();
                    obsDadosMesa.clear();
                    initialize(null, null);
                }
    }
    
    private double calculaTotal()
    {
        double total = 0.00;
        if(!obsDadosMesa.isEmpty())
        {
            for(ProdutosMesa a: obsDadosMesa)
            {
                total += (double) (a.getQtd()*a.getValor());
            }
        }
        return total;
    }
    
    
    @FXML
    private void clk_voltar(ActionEvent event) 
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaVenda.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao Voltar", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_analisar(ActionEvent event) throws SQLException 
    {
        ProdutosMesa e = tbv_mesa.getSelectionModel().getSelectedItem();
        if(tbv_mesa.getSelectionModel().getSelectedItem() != null || !e.getStatus().equals("P"))
        {
            obsDadosItem.clear();
            CTRL.getItensDetalhado(lb_pedido.getText(), obsDadosItem, tbv_mesa.getSelectionModel().getSelectedItem().getNome());
        }
        else
        {
             Alert a;
             if(e.getStatus().equals("P"))
                 a = new Alert(Alert.AlertType.ERROR, "O item ja foi pago", ButtonType.OK);
            else
                 a = new Alert(Alert.AlertType.ERROR, "Selecione um item", ButtonType.OK);

             a.showAndWait();
        }
    }

    @FXML
    private void clk_pagarItem(ActionEvent event) throws SQLException 
    {
        ProdutosMesa e = tbv_mesa.getSelectionModel().getSelectedItem();
        ItemMesa x;
        if(tbv_mesa.getSelectionModel().getSelectedItem() != null || !e.getStatus().equals("P"))
        {   
            clk_analisar(null);
            tf_pagar.setVisible(true);
            bt_ok.setVisible(true);
            x = obsDadosItem.get(0);
            
            if(x.getPrecoProd()-x.getPrecoPago() != 0)
            tf_pagar.setPromptText("-"+(x.getPrecoProd()-x.getPrecoPago()));
            else
            tf_pagar.setPromptText("Produto pago");
        }
        else
        {
             Alert a;
             if(e.getStatus().equals("P"))
                 a = new Alert(Alert.AlertType.ERROR, "O item ja foi pago", ButtonType.OK);
            else
                 a = new Alert(Alert.AlertType.ERROR, "Selecione um item", ButtonType.OK);

             a.showAndWait();
            
        }
        
    }
    @FXML
    private void clk_ok(ActionEvent event) throws SQLException
    {
        ItemMesa e = obsDadosItem.get(0);
        double precoPago = Double.parseDouble(tf_pagar.getText());
        
        
        if(precoPago+e.getPrecoPago() > e.getPrecoProd())
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Preco excede o preco total", ButtonType.OK);
            a.showAndWait();
        }
        else
        {
            if(precoPago+e.getPrecoPago() == e.getPrecoProd())
                CTRL.pagarProduto(lb_pedido.getText(),e.getCod()+"", precoPago, true);
            else
                 CTRL.pagarProduto(lb_pedido.getText(),e.getCod()+"", precoPago, true);
            tf_pagar.setVisible(false);
            bt_ok.setVisible(false);
            obsDadosItem.clear();
            obsDadosMesa.clear();
            CTRL.getProdutosMesa(cb_mesa.getValue(), obsDadosMesa);
            tf_pagar.clear();
        }
    }
    
    public void aplicarEstilo()
    {
        bt_analisar.setStyle("-fx-background-color: " + Tema.getCor());

        bt_voltar.setStyle("-fx-background-color: " + Tema.getCor());
        bt_pagarItem.setStyle("-fx-background-color: " + Tema.getCor());        
        bt_fecharConta.setStyle("-fx-background-color: " + Tema.getCor());
        bt_ok.setStyle("-fx-background-color: " + Tema.getCor());
    }

    
}
