/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlChurros;
import churrosgourmetsystem.db.controladoras.CtrlIngredientes;
import churrosgourmetsystem.db.controladoras.CtrlItensDiversos;
import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.db.entidades.Produtos;
import churrosgourmetsystem.util.Tema;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Henrique K.
 */
public class TelaEntradaEstoqueController implements Initializable {

    @FXML
    private AnchorPane ancPane;
    @FXML
    private JFXTextField txtPesquisa;
    @FXML
    private JFXComboBox<String> cbProdutos;
    @FXML
    private JFXButton btnPesquisar;
    @FXML
    private JFXTextField txtCodigo;
    @FXML
    private JFXTextField txtProduto;
    @FXML
    private JFXTextField txtQuantidade;
    @FXML
    private JFXButton btnAtualizar;
    @FXML
    private VBox vbox;
    @FXML
    private TableView<Produtos> tabela;
    @FXML
    private TableColumn<?, ?> colCodigo;
    @FXML
    private TableColumn<?, ?> colProduto;
    @FXML
    private TableColumn<?, ?> colValor;
    private Produtos produto;
    private Churros churros;
    private Ingredientes ingredientes;
    private ItensDiversos itensdiversos;
    ArrayList<Churros> list_churros = null;
    ArrayList<Ingredientes> list_ingredientes = null;
    ArrayList<ItensDiversos> list_itensdiversos = null;
    CtrlItensDiversos ctrl_itensdi = new CtrlItensDiversos();
    CtrlIngredientes ctrl_itens = new CtrlIngredientes();
    CtrlChurros ctrl_churros = new CtrlChurros();
    ArrayList<Produtos> list_produto = new ArrayList<>();
    Boolean chu;
    Boolean ingre;
    Boolean itens;
    Boolean inserido = false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        aplicarEstilo();
        Tabela();
        txtCodigo.setDisable(true);
        txtProduto.setDisable(true);
        
        InsereComboBox();
    }    

    @FXML
    private void MascaraProduto(KeyEvent event) {
        
    }

    @FXML
    private void clkPesquisar(ActionEvent event) {
        String nome;
        int cod;
        int val;
        
        chu = ingre = itens = false;

        try 
        {
            if(list_produto.size() != 0)
                list_produto.clear();
            
            if(cbProdutos.getSelectionModel().getSelectedIndex() == -1)
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Escolhe o tipo de produto!", ButtonType.OK);
                a.showAndWait();
            }
            else
            {
                if (inserido)
                    tabela.getItems().clear();
                if (cbProdutos.getSelectionModel().getSelectedIndex() == 0) //Buscar por itens diversos
                {
                    itens = true;
                    list_itensdiversos = ctrl_itensdi.buscarE(txtPesquisa.getText());
                    InserirList(1);
                }
                if (cbProdutos.getSelectionModel().getSelectedIndex() == 1) //Buscar por ingredientes
                {
                    ingre = true;
                    list_ingredientes = ctrl_itens.getIngredientesE(txtPesquisa.getText());
                    InserirList(2);

                }
                if(cbProdutos.getSelectionModel().getSelectedIndex() == 2) //Buscar churros
                {
                    chu = true;
                    list_churros = ctrl_churros.getChurrosE(txtPesquisa.getText());
                    InserirList(3);
                }
                tabela.setItems(FXCollections.observableArrayList(list_produto));
                inserido = true;
            }

        } catch (Exception e) {
            System.out.println("" + e);
        } 
    }
    
    public void Tabela()
    {
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colProduto.setCellValueFactory(new PropertyValueFactory<>("produtos"));
        colValor.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
    }
    
    
    public void InsereComboBox()
    {     
        cbProdutos.getItems().add("Itens Diversos");
        cbProdutos.getItems().add("Ingredientes");
        cbProdutos.getItems().add("Churros");
    }


    @FXML
    private void MascaraQtde(MouseEvent event) {
    }

    @FXML
    private void clkAtualizar(ActionEvent event) {
        try
        {
            if(itens)
            {
                ctrl_itensdi.Alterar_Estoque(txtQuantidade.getText(), txtCodigo.getText());
                list_produto.clear();
                list_itensdiversos = ctrl_itensdi.buscar(txtPesquisa.getText());
                InserirList(1);
            }
            else
            if(ingre)
            {
                ctrl_itens.Alterar_Estoque(txtQuantidade.getText(), txtCodigo.getText());
                list_produto.clear();
                list_ingredientes = ctrl_itens.getIngredientes(txtPesquisa.getText());
                InserirList(2);
            }
            else
            if(chu)
            {
                ctrl_churros.Alterar_Estoque(txtQuantidade.getText(), txtCodigo.getText());
                list_produto.clear();
                list_churros = ctrl_churros.getChurros(txtPesquisa.getText());
                InserirList(3);
            }
            tabela.setItems(FXCollections.observableArrayList(list_produto));
            LimparTela();
            Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Estoque Atualizado com sucesso!", ButtonType.OK);
            a.showAndWait();
            
        }catch(Exception e)
        {
            Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao Alterar!", ButtonType.OK);
            a.showAndWait();
        }
    }
    
    public void LimparTela()
    {
        txtCodigo.setText("");
        txtPesquisa.setText("");
        txtProduto.setText("");
        txtQuantidade.setText("");
    }
    
    public void LimparTabela()
    {
        for(int i = 0; i < tabela.getItems().size();i++)
            tabela.getItems().clear();
    }
    
    public void InserirList(int tipo)
    {
        String nome; int cod; int qtde;
        if(tipo == 1)
        {
            for (int i = 0; i < list_itensdiversos.size(); i++) {
                nome = list_itensdiversos.get(i).getNome();
                cod = list_itensdiversos.get(i).getCodigo();
                qtde = list_itensdiversos.get(i).getQuantidade();
                list_produto.add(new Produtos(cod, nome, qtde));
            }
        }
        else
        if(tipo == 2)
        {
            for (int i = 0; i < list_ingredientes.size(); i++) {
                nome = list_ingredientes.get(i).getDesc();
                cod = list_ingredientes.get(i).getCod();
                qtde = list_ingredientes.get(i).getQtdes();
                list_produto.add(new Produtos(cod, nome, qtde));
            }
        }
        else
        if(tipo == 3)
        {
            for (int i = 0; i < list_churros.size(); i++) {
                nome = list_churros.get(i).getDesc();
                cod = list_churros.get(i).getCod();
                qtde = list_churros.get(i).getQuantidade().intValue();
                list_produto.add(new Produtos(cod, nome, qtde));
            }
        }
    }

    @FXML
    private void cliquei(MouseEvent event) {
        txtCodigo.setText(tabela.getSelectionModel().getSelectedItem().getCodigo()+"");
        txtProduto.setText(tabela.getSelectionModel().getSelectedItem().getProdutos());
        txtQuantidade.setText(tabela.getSelectionModel().getSelectedItem().getQuantidade()+"");
    }
    
    public void aplicarEstilo()
    {
        vbox.setStyle("-fx-background-color: " + Tema.getCor());
        btnAtualizar.setStyle("-fx-background-color: " + Tema.getCor());
        btnPesquisar.setStyle("-fx-background-color: " + Tema.getCor());
    }
    
}
