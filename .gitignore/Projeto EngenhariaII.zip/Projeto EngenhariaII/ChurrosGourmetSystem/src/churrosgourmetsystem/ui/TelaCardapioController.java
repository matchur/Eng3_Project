/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.ui;

import churrosgourmetsystem.db.controladoras.CtrlProdutosGeral;
import churrosgourmetsystem.db.entidades.ProdutosMesa;
import churrosgourmetsystem.db.entidades.Tabela;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class TelaCardapioController implements Initializable {

    @FXML
    private JFXTextField tf_pesq;
    @FXML
    private JFXButton bt_add;
    @FXML
    private JFXButton bt_voltar;
    @FXML
    private TableColumn<Tabela, String> cl_prod;
    @FXML
    private TableColumn<Tabela, Double> cl_preco;
    @FXML
    private TableColumn<Tabela, String> cl_qtd;
    
    private ObservableList<Tabela> e = FXCollections.observableArrayList();
    
    private CtrlProdutosGeral  CTRL = new CtrlProdutosGeral();
    @FXML
    private TableView<Tabela> tbv_prod;
    
    public static Tabela selected_class;
    public static boolean flag = false;
    @FXML
    private BorderPane paneDados;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        flag = false;
        try {
            CTRL.getProdutos(e);
        } catch (Exception ex) {
            Logger.getLogger(TelaCardapioController.class.getName()).log(Level.SEVERE, null, ex);
        }
            cl_prod.setCellValueFactory(new PropertyValueFactory<Tabela, String>("desc"));
            cl_preco.setCellValueFactory(new PropertyValueFactory<Tabela, Double>("preco"));
            cl_qtd.setCellValueFactory(new PropertyValueFactory<Tabela, String>("qtd"));
            tbv_prod.setItems(e);
    }    

    @FXML
    private void clk_pesquisa(MouseEvent event) throws SQLException
    {
        CTRL.PesqtProdutos(e, tf_pesq.getText());
        tbv_prod.setItems(e);       
    }

    @FXML
    private void clk_add(ActionEvent event) 
    {
          try{
              selected_class = tbv_prod.getSelectionModel().getSelectedItem();
              flag = true;
            Parent root = FXMLLoader.load(getClass().getResource("TelaPedidosMesa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao voltar e adicionar item..", ButtonType.OK);
                a.showAndWait();
            }
    }

    @FXML
    private void clk_voltar(ActionEvent event) 
    {
          try{
            Parent root = FXMLLoader.load(getClass().getResource("TelaPedidosMesa.fxml"));
            paneDados.getChildren().clear();
            paneDados.getChildren().add(root);
            
            }catch(Exception er){
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro ao voltar", ButtonType.OK);
                a.showAndWait();
            }
    } 
}
