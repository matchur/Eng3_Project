package churrosgourmetsystem;

import churrosgourmetsystem.db.controladoras.CtrlParametrizacao;
import churrosgourmetsystem.db.entidades.Parametrizacao;
import churrosgourmetsystem.util.Banco;
import churrosgourmetsystem.util.Tema;
import java.sql.ResultSet;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

/**
 *
 * @author Henrique K.
 */
public class ChurrosGourmetSystem extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        ResultSet rs;
        Parent root;
        
        CtrlParametrizacao ctrlp = new CtrlParametrizacao();
        Parametrizacao p;
        p = ctrlp.busca();

        
        if(p == null)
        {
            root = FXMLLoader.load(getClass().getResource("ui/TelaParametrizacao.fxml"));
            stage.setResizable(false);
            stage.setWidth(650);
            stage.setHeight(630);
            stage.setTitle("Sistema");
        }
        else
        {
            int qt = 0;
            Tema.setCor(p.getCor());
            rs = Banco.con.consultar("select count(*) as qtde from funcionario");
            stage.getIcons().add(CtrlParametrizacao.getImg());
            if(rs.next()){
                qt = rs.getInt("qtde");
            }
            if(qt != 0)
            {
                System.out.println("Qtde: " + qt);
                double vl = 230;
                if(CtrlParametrizacao.getImg().getHeight() > CtrlParametrizacao.getImg().getWidth()){
                    vl = CtrlParametrizacao.getImg().getHeight() / 230;
                    vl = CtrlParametrizacao.getImg().getWidth() / vl;
                }
                
                root = FXMLLoader.load(getClass().getResource("ui/TelaLogin.fxml"));
                stage.setResizable(false);
                stage.setWidth(vl + 320);
                stage.setHeight(260);
            }  
            else  
            {
                root = FXMLLoader.load(getClass().getResource("ui/TelaCadFuncionario.fxml"));
                stage.setResizable(false);
                stage.setWidth(660);
                stage.setHeight(630);
            }
            stage.setTitle(p.getNomeFantasia());
        }
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        try
        {
            if(Banco.conectar())
                launch(args);
            else
            {
                Alert a = new Alert(Alert.AlertType.ERROR, "Erro: Impossível se conectar ao banco de dados!", ButtonType.OK);
                a.showAndWait();
                Platform.exit();
            }
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
            Platform.exit();
        }
    }
    
}
