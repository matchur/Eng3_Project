package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.entidades.PedidosChurros;
import churrosgourmetsystem.db.entidades.Tabela;

import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class CtrlChurros 
{
    String sql;
            
    public void update(Churros churros,ArrayList<Tabela> tabela)
    {
        try
        { 
         int cod = 0;
        ArrayList<Integer> array = new ArrayList<>();
    
        //atualiza churrps
        sql = "update churros set desc_churros = '$1', preco_churros = $2, obs_churros = '$3', quantidade = $5 where cod_churros = $4";
        
        sql = sql.replace("$1", churros.getDesc());
        sql = sql.replace("$2", "" + churros.getPreco());
        sql = sql.replace("$3", churros.getObservacao());
        sql = sql.replace("$4", ""+churros.getCod());
        sql = sql.replace("$5",""+churros.getQuantidade());
        
        System.out.println(sql);
        Banco.con.manipular(sql);
        
        //deleta churros ingredientes
        sql = "delete from churros_ingredientes where cod_churros = $1";
        sql = sql.replace("$1", ""+churros.getCod());
        System.out.println(sql);
        Banco.con.manipular(sql);
        
        //coloca tudo devolta
            for(Tabela list:tabela)
            {
                //procurar o individuo
                sql = "select cod_ing from ingredientes where desc_ing like '$1'";
                sql = sql.replace("$1",list.getDesc());


                ResultSet rs = Banco.con.consultar(sql);

                while(rs.next())
                {
                   array.add(rs.getInt("cod_ing"));
                } 


                sql = "insert into churros_ingredientes (cod_churros, cod_ing, qtd_chuing) values ($1,$2,$3)";
                sql = sql.replace("$1",""+ churros.getCod());
                sql = sql.replace("$2",""+array.get(cod));
                sql = sql.replace("$3",""+list.getQtd());
                sql = sql.replace("$5",""+churros.getQuantidade());
                Banco.con.manipular(sql);

                cod++;
            }
            
        }
        catch(SQLException e)
        {
            
        }
    }
    
    public void salvar(Churros churros,ArrayList<Tabela> tabela) throws SQLException
    {   
        try
        { 
         int cod = 0;
        ArrayList<Integer> array = new ArrayList<>();
        
        sql = "insert into churros (cod_churros, desc_churros, preco_churros, obs_churros, quantidade) values (nextval('seq_churros'), '$1', $2, '$3', 0)";
        
        sql = sql.replace("$1", churros.getDesc());
        sql = sql.replace("$2", "" + churros.getPreco());
        sql = sql.replace("$3", churros.getObservacao());
        
        System.out.println("Churros: " + sql);
        Banco.con.manipular(sql);
        
            for(Tabela list:tabela)
            {
                //procurar o individuo
                sql = "select cod_ing from ingredientes where desc_ing like '$1'";
                sql = sql.replace("$1",list.getDesc());


                ResultSet rs = Banco.con.consultar(sql);

                while(rs.next())
                {
                   array.add(rs.getInt("cod_ing"));
                } 


                sql = "insert into churros_ingredientes (cod_churros, cod_ing, qtd_chuing) values (currval('seq_churros'),$1,$2)";
                sql = sql.replace("$1",""+array.get(cod));
                sql = sql.replace("$2",""+list.getQtd());
                
                System.out.println("Ingredientes Churros: " + sql);
                Banco.con.manipular(sql);

                cod++;
            }

        }
        catch(SQLException e)
        {
            
        }
    }
    
    public void excluir(int cod) throws SQLException
    {   
        sql = "delete from churros where cod_churros = $1";
        sql = sql.replace("$1","" + cod);
        System.out.println(sql);
        Banco.con.manipular(sql);
        
        sql = "delete from churros_ingredientes where cod_churros = $1";
        sql = sql.replace("$1","" + cod);
        System.out.println(sql);
        Banco.con.manipular(sql);     
    }
    public ObservableList<Churros> buscar (String value)
    {   
        sql = "select * from churros where desc_churros like '%$1%'";
        
        sql =  sql.replace("$1",value);

        ResultSet rs;
        ObservableList<Churros> list = FXCollections.observableArrayList();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.addAll(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er)
        {
            
        } 
        return list;
    }
    
    
    public ArrayList  getChurros(String value)
    {   
        ArrayList<Churros> list = new ArrayList<>();
        if(!value.isEmpty())
        {
            sql = "select * from churros where desc_churros like '%$1%'";
            sql = sql.replace("$1", value); 
        }
        else
            sql = "select * from churros ";


        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er){System.out.println("Erro :"+er);} 
        
        return list;
    }
    
    public ArrayList  getChurrosE(String value)
    {   
        ArrayList<Churros> list = new ArrayList<>();
        if(!value.isEmpty())
        {
            sql = "select * from churros where desc_churros like '%$1%' where quantidade = 0";
            sql = sql.replace("$1", value); 
        }
        else
            sql = "select * from churros where quantidade = 0";


        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er){System.out.println("Erro :"+er);} 
        
        return list;
    }
    
    public Boolean Alterar_Estoque(String value, String cod)
    {
        String sql = "update churros set quantidade = $1 where cod_churros = "+cod;
        sql = sql.replace("$1", value);
        System.out.println(""+sql);
        return Banco.con.manipular(sql);
    }
    
    public Boolean InserirPedidos(PedidosChurros Pc)
    {
        String sql = "insert into pedidochurros(churros_cod_chu,pedido_cod_ped,qtde,valor_unit)"
                        + "values('$1','$2','$3','$4')";
        sql = sql.replace("$1", Pc.getCod_ped()+"");
        sql = sql.replace("$2", Pc.getCod_churros()+"");
        sql = sql.replace("$3", Pc.getQtde()+"");
        sql = sql.replace("$4", Pc.getValor()+"");
        System.out.println("SQL Pedido Churros: " + sql);
        
        return Banco.con.manipular(sql);
    }
}
