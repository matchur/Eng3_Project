package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class CtrlAcertarEstoque {
    public Boolean Alterar_EstoqueChurros(String value, String cod)
    {
        String sql;
        sql = "update churros set quantidade = $1 where cod_churros = "+cod;
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
    public Boolean Alterar_EstoqueIngredientes(String value, String cod)
    {
        String sql;
        sql = "update ingredientes set qtdes_ing = $1 where cod_ing = "+cod;
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
    public Boolean Alterar_EstoqueItensDiversos(String value, String cod)
    {
        String sql;
        sql = "update itensdiversos set quantidade = $1 where codigo = "+cod;
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
    public ArrayList<ItensDiversos> buscar(String value)
    {
        String sql = "";
        if(!value.isEmpty())
        {
            sql = "select * from itensdiversos where nome like '%$1%'";
            sql = sql.replace("$1", value);
        }
        else
            sql = "select * from itensdiversos";

        ResultSet rs;
        ArrayList<ItensDiversos> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                    ,rs.getString("tipo"),rs.getString("fornecedor"),rs.getInt("quantidade")));
                
            }
        }catch(Exception er)
        {System.out.println(""+er);} 
        
        return list;
    }
    
    public ArrayList<Ingredientes> getIngredientes(String val)
    {
        String sql;
        ArrayList<Ingredientes> list = new ArrayList<>();
        if(!val.isEmpty())
        {
            sql = "select * from ingredientes where desc_ing like '%$1%'";
            sql = sql.replace("$1", val);
        }
        else
            sql = "select * from ingredientes";
        ResultSet rs;

        try {
            rs = Banco.con.consultar(sql);
            while (rs.next()) {
                list.add(new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0)));
            }
        } catch (Exception er) {System.out.println("Erro :"+er);}
        
        return list;
    }
    
    public ArrayList getChurros(String value)
    {   
        String sql;
        ArrayList<Churros> list = new ArrayList<>();
        if(!value.isEmpty())
        {
            sql = "select * from churros where desc_churros like '%$1%'";
            sql = sql.replace("$1", value); 
        }
        else
            sql = "select * from churros";


        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er){System.out.println("Erro :"+er);} 
        
        return list;
    }
    
}
