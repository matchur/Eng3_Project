package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Henrique K.
 */
public class CtrlFuncionario {

    String sql;
    Funcionario func;
    
    public CtrlFuncionario() {
    }
    
    public CtrlFuncionario(int cod, String nome, String cpf, String rg, LocalDate dtNasc, String email, String telefone, String endereco, String bairro, String cidade, int numero, String senha, double salario, int nivel) {
        this.func = new Funcionario(cod, nome, cpf, rg, dtNasc, email, telefone, endereco, bairro, cidade, numero, senha, salario, nivel);
    }
    
    public CtrlFuncionario(Funcionario func){
       this.func = func;
    }
    
    public void setCodFunc(int cod)
    {
        this.func.setCod(cod);
    }
    
    public int salvar()
    {   
        if(buscarP(func.getEmail()) != 0)
        {
            return -1;
        }
        else{
            sql = "insert into funcionario (cod_func, nome_func, rg_func, cpf_func, dtnasc_func, sal_fun, email_func, celular_func, endereco_func, bairro_func, cidade_func, num_func, senha_func, nivel_func) values (nextval('seq_func'), '$1', '$2', '$3', '$4', $5, '$6', '$7', '$8', '$9', '$a', $b, '$c', $d)";
            //sql = "insert into funcionario (cod_func, nome_func, rg_func, cpf_func, dtnasc_func, sal_fun, email_func, celular_func, endereco_func, bairro_func, cidade_func, num_func, senha_func, nivel_func) values (nextval('seq_func'), 'Henrique Krupck', '55.858.022-1', '453.904.888-06', '1997-05-06', 5000.00, 'krupck@outlook.com', '(18)99675-5455', 'Rua Estevam peres', 'Jd. Paulista', 'Pres. Prudente', 480, 'vrau', 2)";
            sql = sql.replace("$1", func.getNome());
            sql = sql.replace("$2", func.getRg());
            sql = sql.replace("$3", func.getCpf());
            sql = sql.replace("$4", "" + func.getDtNasc());
            sql = sql.replace("$5", "" + func.getSalario());
            sql = sql.replace("$6", func.getEmail());
            sql = sql.replace("$7", func.getTelefone());
            sql = sql.replace("$8", func.getEndereco());
            sql = sql.replace("$9", func.getBairro());
            sql = sql.replace("$a", func.getCidade());
            sql = sql.replace("$b", "" + func.getNumero());
            sql = sql.replace("$c", func.getSenha());
            sql = sql.replace("$d", "" + func.getNivel());
            System.out.println(sql);
            if( Banco.con.manipular(sql))
                return 1;
        }
        return 0;
    }
    
    public char alterar(int lvl) //Arrumar bonitinho isso aqui.
    {
        if(buscarZ(func.getEmail(), func.getCod()) != 0)
        {
            return 3; //Email já está sendo utilizado
        }
        else
        {
            String flag = "select count(*) as qtde from funcionario where nivel_func = 1";
            ResultSet rs;
            int qt = 0;
            try
            {
                rs = Banco.con.consultar(flag);
                if(rs.next())
                    qt = rs.getInt("qtde");

                System.out.println("Qtde: " + qt);
                System.out.println("Nivel: " + lvl);
                if(qt > 1 || lvl == 2 || func.getNivel() == 1) //Posso alterar
                {
                    sql = "update funcionario set nome_func = '$1', rg_func = '$2', cpf_func = '$3', dtnasc_func = '$4',"
                    + " sal_fun = $5, email_func = '$6', celular_func = '$7', endereco_func = '$8', bairro_func = '$9',"
                    + " cidade_func = '$a', num_func = $b, senha_func = '$c', nivel_func = $d where cod_func = " + func.getCod();
                    sql = sql.replace("$1", func.getNome());
                    sql = sql.replace("$2", func.getRg());
                    sql = sql.replace("$3", func.getCpf());
                    sql = sql.replace("$4", "" + func.getDtNasc());
                    sql = sql.replace("$5", "" + func.getSalario());
                    sql = sql.replace("$6", func.getEmail());
                    sql = sql.replace("$7", func.getTelefone());
                    sql = sql.replace("$8", func.getEndereco());
                    sql = sql.replace("$9", func.getBairro());
                    sql = sql.replace("$a", func.getCidade());
                    sql = sql.replace("$b", "" + func.getNumero());
                    sql = sql.replace("$c", func.getSenha());
                    sql = sql.replace("$d", "" + func.getNivel());

                    if(Banco.con.manipular(sql)) //Alterado com sucesso
                        return 1;
                    else
                        return 0; //Erro ao alterar
                }
                else
                    return 2; //Tentando alterar o ultimo adm

            }catch(Exception er)
            {
            }
        }
        return 0;
    }
    
    public ArrayList<Funcionario>buscar(String value)
    {
        String sql = "select * from funcionario " + value;
        ResultSet rs;
        ArrayList<Funcionario> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Funcionario(rs.getInt("cod_func"), rs.getString("nome_func"), rs.getString("cpf_func"),
                            rs.getString("rg_func"), rs.getDate("dtnasc_func").toLocalDate(), rs.getString("email_func"),
                            rs.getString("celular_func"), rs.getString("endereco_func"), rs.getString("bairro_func"),
                            rs.getString("cidade_func"), rs.getInt("num_func"), rs.getString("senha_func"),
                            rs.getDouble("sal_fun"), rs.getInt("nivel_func")));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ArrayList<Funcionario>buscarN(String cmd, String value)
    {
        String sql = "select * from funcionario where " + cmd + "'%$1%'";
        sql = sql.replace("$1", value);
        ResultSet rs;
        ArrayList<Funcionario> list = new ArrayList<>();
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Funcionario(rs.getInt("cod_func"), rs.getString("nome_func"), rs.getString("cpf_func"),
                            rs.getString("rg_func"), rs.getDate("dtnasc_func").toLocalDate(), rs.getString("email_func"),
                            rs.getString("celular_func"), rs.getString("endereco_func"), rs.getString("bairro_func"),
                            rs.getString("cidade_func"), rs.getInt("num_func"), rs.getString("senha_func"),
                            rs.getDouble("sal_fun"), rs.getInt("nivel_func")));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public char excluir(Funcionario func)
    {
        int qt = 0;
        ResultSet rs;
        String flag = "select count(*) as qtde from funcionario where nivel_func = 1";
        String sql = "delete from funcionario where cod_func = " + func.getCod();
        
        try
        {
            rs = Banco.con.consultar(flag);
            if(rs.next())
                qt = rs.getInt("qtde");
            
            if(qt > 1 || func.getNivel() != 1) //Posso excluir
            {
                if(Banco.con.manipular(sql)) //Excluido com sucesso
                    return 1;
                else
                    return 0; //Erro ao excluir
            }
            else
                return 2; //Tentando deletar o ultimo adm
                
        }catch(Exception er){
            System.out.println("Erro: " + er.getMessage());
        }
        
        return 0;
    }
    
    
    public Object[] buscaLogin(String nome, int acesso, String senha)
    {
        String sql;
        ResultSet rs;
        Object obj[] = new Object[3];
        int cod = -1;
        try
        {
            sql = "select * from funcionario where email_func = '$1'";
            sql = sql.replace("$1", nome);
            rs = Banco.con.consultar(sql);
            
            if(rs.next())
            {
                senha = rs.getString("senha_func");
                acesso = rs.getInt("nivel_func");
                cod = rs.getInt("cod_func");
            }
            
            obj[0] = acesso;
            obj[1] = senha;
            obj[2] = cod;
            
        }catch(Exception er){}
        
        return obj;
    }
    
    public int buscarP(String login)
    {
        String cmd = "select count(*) as col from funcionario where email_func = '$1'";
        cmd = cmd.replace("$1", login);
        //System.out.println("cmd: " + cmd);
        ResultSet rs;
        int qt = 0;
        
        try
        {
            rs = Banco.con.consultar(cmd);
            if(rs.next())
                qt = rs.getInt("col");
        }catch(Exception er)
        {
            
        }
        return qt;
    }
    
    public int buscarZ(String login, int cod)
    {
        String cmd = "select count(*) as col from funcionario where email_func = '$1' and cod_func <> $2";
        cmd = cmd.replace("$1", login);
        cmd = cmd.replace("$2", ""+ cod);
        
        ResultSet rs;
        int qt = 0;
        
        try
        {
            rs = Banco.con.consultar(cmd);
            if(rs.next())
                qt = rs.getInt("col");
        }catch(Exception er)
        {
            
        }
        return qt;
    }
    
    public Funcionario getFunc() {
        return func;
    }

    public void setFunc(Funcionario func) {
        this.func = func;
    }
}
