package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Pedidos;
import churrosgourmetsystem.util.Banco;

public class CtrlPedidos 
{
    public Boolean Salvar(Pedidos p)
    {
        String sql = "insert into pedidos(cod_ped,desconto,funcionarios_cod_func,total,codigo_mesa,data)"
                         + "values('$1','$2','$3','$4','$5','$6')";
        sql = sql.replace("$1", p.getCodigo()+"");
        sql = sql.replace("$2", p.getDesconto()+"");
        sql = sql.replace("$3", p.getCod_funcionario()+"");
        sql = sql.replace("$4", p.getValor_total()+"");
        sql = sql.replace("$5", p.getCod_mesa()+"");
        sql = sql.replace("$6", p.getData_ped()+"");
        
        System.out.println("SQL Pedidos: " + sql);
        return Banco.con.manipular(sql);
    }
}
