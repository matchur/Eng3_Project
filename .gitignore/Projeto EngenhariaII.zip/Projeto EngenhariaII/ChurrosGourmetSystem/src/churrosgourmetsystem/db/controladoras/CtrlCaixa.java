package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Caixa;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Henrique K.
 */
public class CtrlCaixa {
    private String sql;
    private Caixa caixa;

    public CtrlCaixa() {
    }

    public CtrlCaixa(int cod, double abertura, double fechamento, LocalDate data) {
        this.caixa = new Caixa(cod, abertura, fechamento, data);
    }
    
    public boolean abrir()
    {
        sql = "insert into caixa(cod_caixa, data, valor_abertura, valor_fechamento) values (nextval('seq_caixa'), '$2', $3, $4)";
        sql = sql.replace("$2", ""+caixa.getData());
        sql = sql.replace("$3", ""+caixa.getAbertura());
        sql = sql.replace("$4", ""+caixa.getFechamento());
        System.out.println("SQL: " + sql);
        return Banco.con.manipular(sql);
    }
    
    public boolean fechar()
    {
        sql = "update caixa set valor_fechamento = $1 where cod_caixa = " + caixa.getCod();
        sql = sql.replace("$1", ""+caixa.getFechamento());
        System.out.println("SQL: " + sql);
        return Banco.con.manipular(sql);
    }
    
    public boolean buscar()
    {
        sql = "select * from caixa where cod_caixa = (select MAX(cod_caixa) as maxC from caixa)";
        ResultSet rs;
        
        try
        {
            rs = Banco.con.consultar(sql);
            if(rs.next())
            {
                caixa.setCod(rs.getInt("cod_caixa"));
                caixa.setAbertura(rs.getDouble("valor_abertura"));
                caixa.setFechamento(rs.getDouble("valor_fechamento"));
                caixa.setData(rs.getDate("data").toLocalDate());
            }
            return true;
        }catch(Exception er){}
        return false;
    }
    
    public ArrayList<Caixa>buscarAll(){
        ArrayList<Caixa>list = new ArrayList<>();
        sql = "select * from caixa";
        ResultSet rs;
        
        try {
            rs = Banco.con.consultar(sql);
            while(rs.next()){
                list.add(new Caixa(rs.getInt("cod_caixa"), rs.getDouble("valor_abertura"), rs.getDouble("valor_fechamento"), rs.getDate("data").toLocalDate()));
            }
            return list;
        }catch(Exception er){}
        return null;
    }
    
    public ArrayList<Caixa> buscarCod(int cod)
    {
        ArrayList<Caixa>list = new ArrayList<>();
        sql = "select * from caixa where cod = " + cod;
        ResultSet rs;
        
        try
        {
            rs = Banco.con.consultar(sql);
            if(rs.next())
                list.add(new Caixa(rs.getInt("cod_caixa"), rs.getDouble("valor_abertura"), rs.getDouble("valor_fechamento"), rs.getDate("data").toLocalDate()));
            
            return list;
        }catch(Exception er)
        {
            
        }
        return null;
    }
    
    public int getCod()
    {
        return caixa.getCod();
    }
    
    public double getValorAbertura()
    {
        return caixa.getAbertura();
    }
    
    public double getValorFechamento()
    {
        return caixa.getFechamento();
    }
    
    public LocalDate getData()
    {
        return caixa.getData();
    }
    
    public void setFechamento(double valor)
    {
        caixa.setFechamento(valor);
    }
}
