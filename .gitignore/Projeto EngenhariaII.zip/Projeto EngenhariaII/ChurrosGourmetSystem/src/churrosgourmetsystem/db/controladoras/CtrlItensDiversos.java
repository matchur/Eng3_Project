package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.db.entidades.PedidosItens;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Henrique K.
 */
public class CtrlItensDiversos {
    String sql;
    
    public Boolean salvar(ItensDiversos itensd) //Certo
    {
        sql = "insert into itensdiversos(codigo,nome,valor,tipo,fornecedor,quantidade) "
                + "values(nextval('seq_itensdiversos'),'$1','$2','$3','$4',0)";
        
        sql = sql.replace("$1", itensd.getNome());
        sql = sql.replace("$2",""+itensd.getValor());
        sql = sql.replace("$3", itensd.getTipo());
        sql = sql.replace("$4", itensd.getFornecedor());
        return Banco.con.manipular(sql);
    }
   
    public ArrayList<ItensDiversos> buscar(String value)
    {
        String sql = "";
        if(!value.isEmpty())
        {
            sql = "select * from itensdiversos where nome like '%$1%'";
            sql = sql.replace("$1", value);
        }
        else
            sql = "select * from itensdiversos";

        ResultSet rs;
        ArrayList<ItensDiversos> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                    ,rs.getString("tipo"),rs.getString("fornecedor"),rs.getInt("quantidade")));
                
            }
        }catch(Exception er)
        {System.out.println(""+er);} 
        
        return list;
    }
    
    public ArrayList<ItensDiversos> buscarE(String value)
    {
        String sql = "";
        if(!value.isEmpty())
        {
            sql = "select * from itensdiversos where nome like '%$1%' and quantidade = 0";
            sql = sql.replace("$1", value);
            System.out.println("SQL: " + sql);
        }
        else
            sql = "select * from itensdiversos where quantidade = 0";

        ResultSet rs;
        ArrayList<ItensDiversos> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                    ,rs.getString("tipo"),rs.getString("fornecedor"),rs.getInt("quantidade")));
                
            }
        }catch(Exception er)
        {System.out.println(""+er);} 
        
        return list;
    }
    
    /*
        public ArrayList<ItensDiversos> buscar(String value)
        {
            String sql = "select * from itensdiversos " + value;
            ResultSet rs;
            ArrayList<ItensDiversos> list = new ArrayList<>();

            try
            {
                rs = Banco.con.consultar(sql);
                while(rs.next())
                {
                    list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                        ,rs.getString("tipo"),rs.getString("fornecedor")));

                }
            }catch(Exception er){} 

            return list;
        }
    */
    
    public ArrayList<ItensDiversos> buscarItemNT(String cmd,String value)
    {
        String sql = "select * from itensdiversos where " + cmd + "'%$1%'";
        sql = sql.replace("$1", value);
        ItensDiversos itens = null;
        ArrayList<ItensDiversos> list = new ArrayList<>();
        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                    ,rs.getString("tipo"),rs.getString("fornecedor"),rs.getInt("quantidade")));
            }
        }catch(Exception er){} 
        
        return list;
    }
    
    
    public Boolean Alterar(ItensDiversos itens) //Certo
    {
        sql = "update itensdiversos set nome = '$1', valor = '$2', tipo = '$3', fornecedor = '$4', quantidade = $5"
                + "where codigo = "+itens.getCodigo();
        try
        {
            sql = sql.replace("$1", itens.getNome());
            sql = sql.replace("$2",""+itens.getValor());
            sql = sql.replace("$3", itens.getTipo());
            sql = sql.replace("$4", itens.getFornecedor());   
            sql = sql.replace("$5",itens.getQuantidade()+"");
            System.out.println(""+sql);
        }
        catch(Exception ex){}

        return Banco.con.manipular(sql);
    }
    
    public Boolean excluir(String value)
    {
        sql = "delete from itensdiversos where nome = '$1'";
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
    public Boolean Alterar_Estoque(String value, String cod)
    {
        sql = "update itensdiversos set quantidade = $1 where codigo = "+cod;
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
    public Boolean InserirPedidos(PedidosItens Pi)
    {
        String sql = "insert into pedidoitens(pedidos_cod,itensdiversos_cod,qtde,valor_unit)"
                        + "values('$1','$2','$3','$4')";
        sql = sql.replace("$1", Pi.getCod_ped()+"");
        sql = sql.replace("$2", Pi.getCod_itens()+"");
        sql = sql.replace("$3", Pi.getQtde()+"");
        sql = sql.replace("$4", Pi.getValor()+"");

        System.out.println("SQL Pedido Itens: " + sql);
        return Banco.con.manipular(sql);
    }
}
