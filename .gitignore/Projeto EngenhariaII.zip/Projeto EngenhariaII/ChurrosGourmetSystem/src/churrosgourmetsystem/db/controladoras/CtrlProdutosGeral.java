package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Tabela;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.ObservableList;

public class CtrlProdutosGeral 
{
    String sql;
    public void getProdutos(ObservableList<Tabela> e)
    {
        try
        {
            sql = "Select desc_churros,preco_churros from churros";
            ResultSet rs = Banco.con.consultar(sql); 

            while(rs.next())
            {
                Tabela a = new Tabela(rs.getString("desc_churros"),-1,rs.getDouble("preco_churros"));
                e.addAll(a);
            }
        
            sql = "Select nome,valor,quantidade from itensdiversos";
            rs = Banco.con.consultar(sql);       

            while(rs.next())
            {  
                Tabela a = new Tabela(rs.getString("nome"),rs.getDouble("quantidade"),rs.getDouble("valor"));
                e.addAll(a);
            }
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
    }
    
    public void PesqtProdutos(ObservableList<Tabela> e,String pesq)
    {
        try
        {
            e.clear();
            sql = "Select desc_churros,preco_churros from churros where desc_churros ilike '%$1%'";
            sql = sql.replace("$1", pesq);
            ResultSet rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                Tabela a = new Tabela(rs.getString("desc_churros"),0,rs.getDouble("preco_churros"));
                e.addAll(a);
            }

            sql = "Select nome,valor,quantidade from itensdiversos where nome ilike '%$1%'";   
            sql = sql.replace("$1", pesq);
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {  
                Tabela a = new Tabela(rs.getString("nome"),rs.getDouble("quantidade"),rs.getDouble("valor"));
                e.addAll(a);
            }
        }catch(Exception er)
            {
                System.out.println("Erro: " + er.getMessage());
            }
        
    }
    
    
}
