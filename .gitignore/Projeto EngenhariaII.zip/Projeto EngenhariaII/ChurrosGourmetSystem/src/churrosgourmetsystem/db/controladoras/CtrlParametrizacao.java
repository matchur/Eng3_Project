/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Parametrizacao;
import churrosgourmetsystem.util.Banco;
import churrosgourmetsystem.util.ConversorImagem;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.scene.image.Image;

/**
 *
 * @author hiroshi
 */
public class CtrlParametrizacao {
    private String sql;
    private static String str, nome = "Login";
    private static Image img = null;
    
    public CtrlParametrizacao() {
    }
    
    public Boolean gravar(Parametrizacao p)
    {
        sql = "insert into parametrizacao(codigo,razao,cor,site,email,telefone,endereco,cep,uf,cidade,numero,complemento,bairro, nome_fantasia)"
                + "values('$1','$2','$3','$5','$6','$7','$8','$9','$A','$B','$C','$D','$E','$F')";
        sql = sql.replace("$1",""+p.getCodigo());
        sql = sql.replace("$2",p.getRazao());
        sql = sql.replace("$3",p.getCor());
        sql = sql.replace("$5",p.getSite());
        sql = sql.replace("$6",p.getEmail());
        sql = sql.replace("$7",p.getTelefone());
        sql = sql.replace("$8",p.getEndereco());
        sql = sql.replace("$9",p.getCep());
        sql = sql.replace("$A",p.getUf());
        sql = sql.replace("$B",p.getCidade());
        sql = sql.replace("$C",""+p.getNumero());
        sql = sql.replace("$D",p.getComplemento());
        sql = sql.replace("$E",p.getBairro());
        sql = sql.replace("$F",p.getNomeFantasia());
        System.out.println("SQL: " + sql);
       
        if(Banco.con.manipular(sql)){
            str = p.toString();
            nome = p.getNomeFantasia();
            
            if(Banco.con.inserirImagem("update parametrizacao set foto = ? where codigo = 0", p.getFoto()))
            {
                img = ConversorImagem.byteToImage(p.getFoto());
                return true;
            }
        }
        return false;
    }
    
    public Parametrizacao busca()
    {
        sql = "select * from parametrizacao ";
        ResultSet rs;
        ArrayList<Parametrizacao> list = new ArrayList<>();
        Parametrizacao p = null;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                p = new Parametrizacao(rs.getInt("codigo"),rs.getString("razao"),rs.getString("cor")
                    ,rs.getString("site"),rs.getString("email"),rs.getString("telefone"),rs.getString("endereco"),
                        rs.getString("cep"),rs.getString("uf"),rs.getString("cidade"),rs.getInt("numero"),rs.getString("complemento"),rs.getString("bairro"), rs.getString("nome_fantasia"),rs.getBytes("foto"));
                
            }
            
            img = ConversorImagem.byteToImage(p.getFoto());
            str = p.toString();
            nome = p.getNomeFantasia();
        }catch(Exception er){} 
        
        return p;
    }
    
    public Boolean altera(Parametrizacao p)
    {
        sql = "update parametrizacao set razao = '$1', cor = '$2', site = '$4', email = '$5',"
                + "telefone = '$6', endereco = '$7', cep = '$8', uf = '$9', cidade = '$A', numero = '$B',complemento = '$C', bairro = '$D', nome_fantasia = '$E'"
                    + " where codigo = '$0'";
        try
        {
            sql = sql.replace("$0",""+ p.getCodigo());
            sql = sql.replace("$1",p.getRazao());
            sql = sql.replace("$2",p.getCor());
            sql = sql.replace("$4",p.getSite());
            sql = sql.replace("$5",p.getEmail());
            sql = sql.replace("$6",p.getTelefone());
            sql = sql.replace("$7",p.getEndereco());
            sql = sql.replace("$8",p.getCep());
            sql = sql.replace("$9",p.getUf());
            sql = sql.replace("$A",p.getCidade());
            sql = sql.replace("$B",""+p.getNumero());
            sql = sql.replace("$C",p.getComplemento());
            sql = sql.replace("$D",p.getBairro());
            sql = sql.replace("$E",p.getNomeFantasia());
        }
        catch(Exception e)
        {System.out.println(""+e);}
        System.out.println(""+sql);
        
        if(Banco.con.manipular(sql)){
            str = p.toString();
            nome = p.getNomeFantasia();
            
            if(Banco.con.inserirImagem("update parametrizacao set foto = ? where codigo = 0", p.getFoto()))
            {
                img = ConversorImagem.byteToImage(p.getFoto());
                return true;
            }
        }
        return false;
    }
    
    public static String getStr() {
        return str;
    }

    public static void setStr(String str) {
        CtrlParametrizacao.str = str;
    }

    public static String getNome() {
        return nome;
    }

    public static void setNome(String nome) {
        CtrlParametrizacao.nome = nome;
    }
    
    public boolean buscaN()
    {
        sql = "select * from parametrizacao where codigo = 0";
        ResultSet rs;
        int p = 1;
        try
        {
            rs = Banco.con.consultar(sql);
            if(rs.next())
                p = rs.getInt("codigo");
            
            if(p == 0)
                return true;
        }catch(Exception er){} 
        
        return false;
    }
    
    public static Image getImg() {
        return img;
    }

    public static void setImg(Image img) {
        CtrlParametrizacao.img = img;
    }

    
}
