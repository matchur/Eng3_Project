/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.util.Banco;
import java.time.LocalDate;

/**
 *
 * @author Henrique K.
 */
public class CtrlPgDespesas {
    private int codPg, codDesp, codCaixa, parcela;
    private String obs;
    private LocalDate dtPgm, dtVenc;
    private double valor;

    public CtrlPgDespesas(int codPg, int codDesp, int codCaixa, int parcela, String obs, LocalDate dtPgm, LocalDate dtVenc, double valor) {
        this.codPg = codPg;
        this.codDesp = codDesp;
        this.codCaixa = codCaixa;
        this.parcela = parcela;
        this.obs = obs;
        this.dtPgm = dtPgm;
        this.dtVenc = dtVenc;
        this.valor = valor;
    }

    public boolean salvar()
    {
        String sql = "insert into parceladesp(cod_pag, obs_pag, despesa_cod, parcela, dt_pagamento, caixa_cod, valor)"
                + "  values(nextval('seq_parcelades'), '$2', $3, $4, '$6', $7, $8)";
        
        //sql = sql.replace("$1", ""+codPg);
        sql = sql.replace("$2", obs);
        sql = sql.replace("$3", ""+codDesp);
        sql = sql.replace("$4", ""+parcela);
        //sql = sql.replace("$5", ""+dtVenc);
        sql = sql.replace("$6", ""+dtPgm);
        sql = sql.replace("$7", ""+codCaixa);
        sql = sql.replace("$8", ""+valor);
        
        System.out.println("SQL: " + sql);
        return Banco.con.manipular(sql);
        //return true;
    }
    
    public int getCodPg() {
        return codPg;
    }

    public void setCodPg(int codPg) {
        this.codPg = codPg;
    }

    public int getCodDesp() {
        return codDesp;
    }

    public void setCodDesp(int codDesp) {
        this.codDesp = codDesp;
    }

    public int getCodCaixa() {
        return codCaixa;
    }

    public void setCodCaixa(int codCaixa) {
        this.codCaixa = codCaixa;
    }

    public int getParcela() {
        return parcela;
    }

    public void setParcela(int parcela) {
        this.parcela = parcela;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public LocalDate getDtPgm() {
        return dtPgm;
    }

    public void setDtPgm(LocalDate dtPgm) {
        this.dtPgm = dtPgm;
    }

    public LocalDate getDtVenc() {
        return dtVenc;
    }

    public void setDtVenc(LocalDate dtVenc) {
        this.dtVenc = dtVenc;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    
}
