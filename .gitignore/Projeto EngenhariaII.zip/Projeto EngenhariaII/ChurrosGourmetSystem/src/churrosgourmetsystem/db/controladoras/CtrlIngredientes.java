package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.db.entidades.Ingredientes;
import churrosgourmetsystem.db.entidades.Tabela;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CtrlIngredientes 
{
    String sql;
    
    public boolean salvar(Ingredientes ing)
    {   
        sql = "insert into ingredientes (cod_ing, desc_ing, qtdes_ing, obs_ing, qtdun_ing, tpprod_ing) values (nextval('seq_ing'), '$1', $2, '$3', $4, '$5')";
        
        sql = sql.replace("$1", ing.getDesc());
        sql = sql.replace("$2", "" + ing.getQtdes());
        sql = sql.replace("$3", ing.getObs());
        sql = sql.replace("$4", "" + ing.getQtdun());
        sql = sql.replace("$5", "" + ing.getTipo());
        System.out.println(sql);
        return Banco.con.manipular(sql);
    }
    
    public ObservableList<Ingredientes> buscar (String value)
    {   
        sql = "select * from ingredientes where desc_ing like '%$1%'";
        
        sql =  sql.replace("$1",value);

        ResultSet rs;
        ObservableList<Ingredientes> list = FXCollections.observableArrayList();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.addAll(new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0)));
                
            }
        }catch(Exception er)
        {
            
        } 
        
        //cod
        sql = "select * from ingredientes where cod_ing = $1";
        sql =  sql.replace("$1",value);
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
               Ingredientes i =  new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0));
                
               if(!procuraIng(i,list))
               {
                  list.addAll(i); 
               }
                
                
            }
        }catch(Exception er)
        {
            
        } 
        
        sql = "select * from ingredientes where tpprod_ing = '$1'";
        if(value.toLowerCase().equals("kilo") || value.toLowerCase().equals("kg"))
        sql =  sql.replace("$1","k");
        else
        {
            if(value.toLowerCase().equals("litro"))
            sql =  sql.replace("$1","l");
            else
                sql =  sql.replace("$1",value);
        }
           
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
               Ingredientes i =  new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0));
                
               if(!procuraIng(i,list))
               {
                  list.addAll(i); 
               }
                
                
            }
        }catch(Exception er)
        {
            
        } 
        
        
        
        return list;
    }
    
    
    public boolean update(Ingredientes i)
    {
     sql = "update Ingredientes set desc_ing = '$1',qtdes_ing = $2,obs_ing = '$3',qtdun_ing = $4,tpprod_ing = $5 where cod_ing = $6";
        
        sql =  sql.replace("$1",i.getDesc());
        sql =  sql.replace("$2",""+i.getQtdes());
        sql = sql.replace("$3", i.getObs());
        sql = sql.replace("$4",""+ i.getQtdun());
        sql = sql.replace("$5", i.getTipo());
        sql = sql.replace("$6",""+ i.getCod());
        
        System.out.println(sql);
        return Banco.con.manipular(sql);  
        
    }
    
    public boolean excluir(int cod)
    {
        sql = "delete from ingredientes where cod_ing = $1";
        sql = sql.replace("$1",""+cod);
        System.out.println(sql);
        return Banco.con.manipular(sql); 
    }
    
    public int lookDB(int cod)
    {
        int i = 0;
        sql = "select count(*) as cont from churros_ingredientes where cod_ing = $1"; 
        sql =  sql.replace("$1",""+cod);

        ResultSet rs;
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                i = rs.getInt("cont");
                
            }
        }catch(Exception er)
        {
            
        } 
        return i;
    }
        
    
    public ObservableList<Tabela> buscarI (String value)
    {   
        sql = "select desc_ing as desc_ing ,qtd_chuing as qtd_chuing from ((churros_ingredientes as ci inner join churros as c on c.desc_churros like '$1' and  ci.cod_churros = c.cod_churros) inner join ingredientes as i on i.cod_ing = ci.cod_ing) ";
        
        sql =  sql.replace("$1",value);

        ResultSet rs;
        ObservableList<Tabela> list = FXCollections.observableArrayList();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.addAll(new Tabela(rs.getString("desc_ing"),rs.getDouble("qtd_chuing")));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    
    public ArrayList<String> getIngredientesDesc()
    {
        ArrayList<String> list = new ArrayList<>();
        sql = "select desc_ing from ingredientes";
        
        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(rs.getString("desc_ing"));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    
    private boolean procuraIng(Ingredientes Ing, ObservableList<Ingredientes> lista)
    {
        for(Ingredientes i: lista)
        {
            if(i.getCod() == Ing.getCod())
                return true;
        }
        return false;
    }
    
    public ArrayList<Ingredientes> getIngredientes(String val)
    {
        ArrayList<Ingredientes> list = new ArrayList<>();
        if(!val.isEmpty())
        {
            sql = "select * from ingredientes where desc_ing like '%$1%'";
            sql = sql.replace("$1", val);
        }
        else
            sql = "select * from ingredientes";
        ResultSet rs;

        try {
            rs = Banco.con.consultar(sql);
            while (rs.next()) {
                list.add(new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0)));
            }
        } catch (Exception er) {System.out.println("Erro :"+er);}
        
        return list;
    }
    
    public ArrayList<Ingredientes> getIngredientesE(String val)
    {
        ArrayList<Ingredientes> list = new ArrayList<>();
        if(!val.isEmpty())
        {
            sql = "select * from ingredientes where desc_ing like '%$1%' where qtdes_ing = 0";
            sql = sql.replace("$1", val);
        }
        else
            sql = "select * from ingredientes where qtdes_ing = 0";
        ResultSet rs;

        try {
            rs = Banco.con.consultar(sql);
            while (rs.next()) {
                list.add(new Ingredientes(
                        rs.getInt("cod_ing"),
                        rs.getString("desc_ing"),
                        rs.getInt("qtdes_ing"),
                        rs.getString("obs_ing"),
                        rs.getDouble("qtdun_ing"),
                        rs.getString("tpprod_ing").charAt(0)));
            }
        } catch (Exception er) {System.out.println("Erro :"+er);}
        
        return list;
    }
    
    public Boolean Alterar_Estoque(String value, String cod)
    {
        String sql = "update ingredientes set qtdes_ing = $1 where cod_ing = "+cod;
        sql = sql.replace("$1", value);
        return Banco.con.manipular(sql);
    }
    
}
