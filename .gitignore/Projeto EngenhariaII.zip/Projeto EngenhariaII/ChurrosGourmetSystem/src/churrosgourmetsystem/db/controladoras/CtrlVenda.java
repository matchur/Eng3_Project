package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Churros;
import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.db.entidades.ItensDiversos;
import churrosgourmetsystem.db.entidades.Pedidos;
import churrosgourmetsystem.db.entidades.PedidosChurros;
import churrosgourmetsystem.db.entidades.PedidosItens;
import churrosgourmetsystem.db.entidades.Venda;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class CtrlVenda 
{
    public Boolean SalvarV(Venda v)
    {
        String sql = "insert into vendas(cod_venda,data_venda,pedidos_cod_ped,pagamento) values('$1','$2','$3','$4')";
        
        sql = sql.replace("$1", v.getCodigo()+"");
        sql = sql.replace("$2",v.getData()+"");
        sql = sql.replace("$3", v.getCodigo_pedido()+"");
        sql = sql.replace("$4", v.getPagamento());
        System.out.println("SQL Venda: " + sql);
        
        return Banco.con.manipular(sql);
    }
    
    public ArrayList<ItensDiversos> buscar(String value)
    {
        String sql = "";
        if(!value.isEmpty())
        {
            sql = "select * from itensdiversos where nome like '%$1%'";
            sql = sql.replace("$1", value);
        }
        else
            sql = "select * from itensdiversos";

        ResultSet rs;
        ArrayList<ItensDiversos> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new ItensDiversos(rs.getInt("codigo"),rs.getString("nome"),rs.getDouble("valor")
                    ,rs.getString("tipo"),rs.getString("fornecedor"),rs.getInt("quantidade")));
                
            }
        }catch(Exception er)
        {System.out.println(""+er);} 
        
        return list;
    }
    
    public ArrayList<Funcionario> buscarFun(String value)
    {
        String sql = "select * from funcionario " + value;
        ResultSet rs;
        ArrayList<Funcionario> list = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Funcionario(rs.getInt("cod_func"), rs.getString("nome_func"), rs.getString("cpf_func"),
                            rs.getString("rg_func"), rs.getDate("dtnasc_func").toLocalDate(), rs.getString("email_func"),
                            rs.getString("celular_func"), rs.getString("endereco_func"), rs.getString("bairro_func"),
                            rs.getString("cidade_func"), rs.getInt("num_func"), rs.getString("senha_func"),
                            rs.getDouble("sal_fun"), rs.getInt("nivel_func")));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ObservableList<Churros> buscarChu(String value)
    {   
        String sql;
        sql = "select * from churros where desc_churros like '%$1%'";
        
        sql =  sql.replace("$1",value);

        ResultSet rs;
        ObservableList<Churros> list = FXCollections.observableArrayList();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.addAll(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er)
        {
            
        } 
        return list;
    }
    
    public Boolean SalvarP(Pedidos p)
    {
        String sql = "insert into pedidos(cod_ped,desconto,funcionarios_cod_func,total,codigo_mesa,data)"
                         + "values('$1','$2','$3','$4','$5','$6')";
        sql = sql.replace("$1", p.getCodigo()+"");
        sql = sql.replace("$2", p.getDesconto()+"");
        sql = sql.replace("$3", p.getCod_funcionario()+"");
        sql = sql.replace("$4", p.getValor_total()+"");
        sql = sql.replace("$5", p.getCod_mesa()+"");
        sql = sql.replace("$6", p.getData_ped()+"");
        System.out.println(""+sql);
        return Banco.con.manipular(sql);
    }
    
    public ArrayList  getChurros(String value)
    {   
        String sql;
        ArrayList<Churros> list = new ArrayList<>();
        if(!value.isEmpty())
        {
            sql = "select * from churros where desc_churros like '%$1%'";
            sql = sql.replace("$1", value); 
        }
        else
            sql = "select * from churros ";


        ResultSet rs;
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new Churros(
                        rs.getInt("cod_churros"),
                        rs.getString("desc_churros"),
                        rs.getDouble("preco_churros"),
                        rs.getString("obs_churros"),
                        rs.getInt("quantidade"))
                        );
                
            }
        }catch(SQLException er){System.out.println("Erro :"+er);} 
        
        return list;
    }
    
    public Boolean InserirPedidos(PedidosItens Pi)
    {
        String sql = "insert into pedidoitens(pedidos_cod,itensdiversos_cod,qtde,valor_unit)"
                        + "values('$1','$2','$3','$4')";
        sql = sql.replace("$1", Pi.getCod_ped()+"");
        sql = sql.replace("$2", Pi.getCod_itens()+"");
        sql = sql.replace("$3", Pi.getQtde()+"");
        sql = sql.replace("$4", Pi.getValor()+"");

        return Banco.con.manipular(sql);
    }
    
    public Boolean InserirPedidos(PedidosChurros Pc)
    {
        String sql = "insert into pedidochurros(churros_cod_chu,pedido_cod_ped,qtde,valor_unit)"
                        + "values('$1','$2','$3','$4')";
        sql = sql.replace("$1", Pc.getCod_ped()+"");
        sql = sql.replace("$2", Pc.getCod_churros()+"");
        sql = sql.replace("$3", Pc.getQtde()+"");
        sql = sql.replace("$4", Pc.getValor()+"");
        System.out.println("SQL Pedido Churros: " + sql);
        
        return Banco.con.manipular(sql);
    }
}
