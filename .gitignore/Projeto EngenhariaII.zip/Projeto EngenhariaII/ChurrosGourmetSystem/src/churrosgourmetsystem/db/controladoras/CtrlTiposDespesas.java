package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.Funcionario;
import churrosgourmetsystem.db.entidades.TiposDespesas;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Henrique K.
 */
public class CtrlTiposDespesas {

    private TiposDespesas desp;
    private String sql;
    
    public CtrlTiposDespesas() {
    }
    
    public CtrlTiposDespesas(TiposDespesas desp) {
        this.desp = desp;
    }

    public CtrlTiposDespesas(int cod, double valor, String descricao, String obs, int codFunc, int parcelas, int flag) {
        this.desp = new TiposDespesas(cod, valor, descricao, obs, codFunc, parcelas, flag);
    }
    
    
    
    public boolean salvar()
    {
        sql = "insert into Despesas(cod, valor, descricao, obs, parcelas, codFunc, sinal) values(nextval('seq_despesas'), $2, '$3', '$4', '$6', $5, 0)";
        sql = sql.replace("$2", ""+desp.getValor());
        sql = sql.replace("$3", desp.getDescricao());
        sql = sql.replace("$4", desp.getObs());
        sql = sql.replace("$5", ""+desp.getCodFunc());
        sql = sql.replace("$6", ""+desp.getParcelas());
        System.out.println("sql: " + sql);
        
        return Banco.con.manipular(sql);
    }
    
    public boolean alterar(int cod, TiposDespesas desp)
    {
        sql = "update despesas set valor = $2, descricao = '$3', obs = '$4', parcelas = $6, codFunc = $5 where cod = " + cod;
        sql = sql.replace("$2", ""+desp.getValor());
        sql = sql.replace("$3", desp.getDescricao());
        sql = sql.replace("$4", desp.getObs());
        sql = sql.replace("$5", ""+desp.getCodFunc());
        sql = sql.replace("$6", ""+desp.getParcelas());
        System.out.println("SQL:" + sql);
        return Banco.con.manipular(sql);
    }
    
    public boolean alterarS(int cod, double valor, int parcelas)
    {
        sql = "update despesas set valor = $2, parcelas = $6 where cod = " + cod;
        sql = sql.replace("$2", ""+valor);
        sql = sql.replace("$6", ""+parcelas);
        System.out.println("SQL ALTER:" + sql);
        return Banco.con.manipular(sql);
    }
    
    public boolean alterarFlag(int cod)
    {
        sql = "update despesas set sinal = 1 where cod = " + cod;
        
        System.out.println("SQL ALTER:" + sql);
        return Banco.con.manipular(sql);
    }
    
    public boolean excluir()
    {
        sql = "delete from despesas where cod = " + desp.getCod();
        return Banco.con.manipular(sql);
    }
    
    public ArrayList<TiposDespesas> buscar(String value)
    {
        ArrayList<Object[]> obj = new ArrayList<>();
        String sql = "select * from despesas " + value;
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        ArrayList<String> listFunc = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
            
            /*for (int i = 0; i < list.size(); i++) {
                sql = "select * from funcionario where cod_func = " + list.get(i).getCodFunc();
                rs = Banco.con.consultar(sql);
                if(rs.next())
                    listFunc.add(new String(rs.getString("nome_func")));
            }
            
            
            Object ob[];
            for (int i = 0; i < list.size(); i++) {
                ob = new Object[4];                
                ob[0] = list.get(i).getCod();
                ob[1] = list.get(i).getDescricao();
                ob[2] = list.get(i).getValor();
                ob[3] = listFunc.get(i);
                obj.add(ob);
            }*/
            
            //return obj;
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ArrayList<TiposDespesas> buscarN(String cmd, String value)
    {
        String sql = "select * from despesas where " + cmd + "'%$1%'";
        sql = sql.replace("$1", value);
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        
        System.out.println("SQL: " + sql);
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
            
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ArrayList<TiposDespesas> buscarZ(String cmd, String value)
    {
        String sql = "select * from despesas where " + cmd + " = " + value;
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        
        System.out.println("SQL: " + sql);
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
            
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ArrayList<TiposDespesas> buscarP(String cmd, String value)
    {
        String sql = "select * from despesas where " + cmd + "'%$1%' and sinal = 1";
        sql = sql.replace("$1", value);
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        
        System.out.println("SQL: " + sql);
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
            
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public ArrayList<TiposDespesas> buscarP2(String cmd, String value)
    {
        String sql = "select * from despesas where " + cmd + " = " + value + "and sinal = 1";
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        
        System.out.println("SQL: " + sql);
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
            
        }catch(Exception er)
        {
            
        } 
        return list;
    }
    
    public TiposDespesas buscarC(int cod)
    {
        String sql = "select * from despesas where cod = " + cod;
        ResultSet rs;
        TiposDespesas desp = null;
        
        System.out.println("SQL: " + sql);
        
        try
        {
            rs = Banco.con.consultar(sql);
            if(rs.next())
            {
                desp = new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"), rs.getString("descricao"), rs.getString("obs"), rs.getInt("codfunc"), rs.getInt("parcelas"), rs.getInt("sinal"));
            }
            
        }catch(Exception er)
        {
            
        } 
        return desp;
    }

    public TiposDespesas getDesp() {
        return desp;
    }

    public void setDesp(TiposDespesas desp) {
        this.desp = desp;
    }
    
    public char excluir(TiposDespesas desp)
    {
        int qt = 0;
        ResultSet rs;
        String sql = "delete from despesas where cod = " + desp.getCod();
        System.out.println("SQL: " + sql);
        if(Banco.con.manipular(sql))
            return 1;
        return 0;
    }
    
    public ArrayList<TiposDespesas> buscarVrau(String value)
    {
        ArrayList<Object[]> obj = new ArrayList<>();
        String sql = "select * from despesas " + value + "where sinal = 1";
        ResultSet rs;
        ArrayList<TiposDespesas> list = new ArrayList<>();
        ArrayList<String> listFunc = new ArrayList<>();
        
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
                list.add(new TiposDespesas(rs.getInt("cod"), rs.getDouble("valor"),
                        rs.getString("descricao"), rs.getString("obs"), rs.getInt("codFunc"), rs.getInt("parcelas"), rs.getInt("sinal")));
                
            }
        }catch(Exception er)
        {
            
        } 
        return list;
        
    }
    
    public ArrayList<Object[]> buscarTudo()
    {
        ArrayList<Object[]> obj = new ArrayList<>();
        String sql = "select cod, descricao , obs ,  dt_pagamento, p.valor from parceladesp as p inner join despesas as d on p.despesa_cod = d.cod ";
        ResultSet rs;
        Object ob[];
        try
        {
            rs = Banco.con.consultar(sql);
            while(rs.next())
            {
              ob = new Object[5];
              ob[0] = rs.getInt("cod");
              ob[1] = rs.getString("descricao");
              ob[2] = rs.getDouble("valor");
              ob[3] = rs.getDate("dt_pagamento");
              ob[4] = rs.getString("obs");
              
              obj.add(ob);
            }
        }catch(Exception er)
        {
            
        } 
        return obj;
    }
}
