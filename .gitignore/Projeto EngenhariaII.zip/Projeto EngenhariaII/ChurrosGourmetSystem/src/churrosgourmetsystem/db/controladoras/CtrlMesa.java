package churrosgourmetsystem.db.controladoras;

import churrosgourmetsystem.db.entidades.ItemMesa;
import churrosgourmetsystem.db.entidades.Mesa;
import churrosgourmetsystem.db.entidades.ProdutosMesa;
import churrosgourmetsystem.util.Banco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class CtrlMesa 
{
    /*
        cod_ped, desconto, funcionarios_cod_func, total,  codigo_mesa, data date,
        cod_ped, desconto, func_cod, data_pedido, status, mesa_cod,
    */
    
    String sql;
    public void getMesa(ArrayList<String> e)
    {
        try
        {
            Mesa classe;
            sql = "select cod_mesa from mesa where statuc = 'O'";
            ResultSet rs = Banco.con.consultar(sql);

            while(rs.next())
            {
               e.add((rs.getString("cod_mesa")));
            }
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
    }
    
    public void createMesa()
    {
        //insert into mesa(cod_mesa,status) values (nextval('seq_mesa'),'F');
    }
    
    public int getCodPed(String cod) throws SQLException
    {
        int codPED = -1;
        ResultSet rs; 
        
        
         
        sql = "select count(cod_ped) from pedidos where codigo_mesa = $1 and status = 'A'";
        sql = sql.replace("$1",cod+"");
        rs = Banco.con.consultar(sql);
        rs.next();
        
        if(rs.getInt("count") > 0)
        {
            sql = "select cod_ped from pedidos where codigo_mesa = $1 and status = 'A'";
            sql = sql.replace("$1",cod+"");
            rs = Banco.con.consultar(sql);
            rs.next();
            codPED = rs.getInt("cod_ped");//pegou o codigo dos pedido
        }
        return codPED;
    }
    
    
    public boolean getProdutosMesa(String cod,ObservableList<ProdutosMesa> e)//codigo da mesa
    {
        try
        {
            int codPED;
            ResultSet rs; 
            sql = "select count(cod_ped) from pedidos where codigo_mesa = $1 and status = 'A'";
            sql = sql.replace("$1",cod+"");
            rs = Banco.con.consultar(sql);
            rs.next();

            if(rs.getInt("count") > 0)
            {
                sql = "select cod_ped from pedidos where codigo_mesa = $1 and status = 'A'";
                sql = sql.replace("$1",cod+"");
                rs = Banco.con.consultar(sql);
                rs.next();
                codPED = rs.getInt("cod_ped");//pegou o codigo dos pedido

                //parte do churros
                sql = "select desc_churros,qtd_prod,preco_churros,status from churros as c inner join produtos_mesa as p on c.cod_churros = p.cod_churros where cod_pedido = $1";
                sql = sql.replace("$1",codPED+"");
                rs = Banco.con.consultar(sql);
                while(rs.next())
                {
                    e.addAll(new ProdutosMesa(rs.getString("desc_churros"),rs.getInt("qtd_prod"),rs.getDouble("preco_churros"),rs.getString("status"),"C"));
                }


                //itensdiversos - codigo, nome, valor, tipo, fornecedor, quantidade
                //itens_diversos- cod_item, desc_item, estoque, custo_item, obs_item, preco_item
          
                //parte dos itens
                sql = "select nome,quantidade,valor,status from itensdiversos as c inner join produtos_mesa as p on c.codigo = p.cod_itensdiv where cod_pedido = $1";
                sql = sql.replace("$1",codPED+"");
                rs = Banco.con.consultar(sql);
                while(rs.next())
                {
                    e.addAll(new ProdutosMesa(rs.getString("nome"),rs.getInt("quantidade"),rs.getDouble("valor"),rs.getString("status"),"C"));
                }

                return true;
            }
            else
                return false;
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
        
        return false;
        
    }
    
    public void getItensDetalhado(String codPed,ObservableList<ItemMesa> e,String nomeProd) throws SQLException
    {
        ResultSet rs;
        sql = "select count(c.cod_churros) from churros as c inner join produtos_mesa as pm on c.cod_churros = pm.cod_churros where pm.cod_pedido = $1";
        sql = sql.replace("$1", codPed);
        rs = Banco.con.consultar(sql);
        rs.next();
        
        if(rs.getInt("count") > 0)
        {
            sql = "select c.cod_churros,desc_churros,preco_pago,preco_churros*qtd_prod preco_total from churros as c inner join produtos_mesa as pm on c.cod_churros = pm.cod_churros where pm.cod_pedido = $1 and desc_churros = '$2'";
            sql = sql.replace("$1",codPed);
            sql = sql.replace("$2",nomeProd);
            rs = Banco.con.consultar(sql);
            
            while(rs.next())
            {
                e.addAll(new ItemMesa(rs.getInt("cod_churros"),rs.getDouble("preco_pago"),rs.getDouble("preco_total"),rs.getString("desc_churros")));
            }
        }

        sql = "select count(codigo) from itensdiversos as i inner join produtos_mesa as pm on i.codigo = pm.cod_itensdiv where pm.cod_pedido = $1";
        sql = sql.replace("$1", codPed);
        rs = Banco.con.consultar(sql);
        rs.next();
        
        if(rs.getInt("count") > 0)
        {
            sql = "select codigo,nome,valor,valor*qtd_prod preco_total from itensdiversos as i inner join produtos_mesa as pm on i.codigo = pm.cod_itensdiv where pm.cod_pedido = $1 and nome = '$2'";
            sql = sql.replace("$1",codPed);
            sql = sql.replace("$2",nomeProd);
            rs = Banco.con.consultar(sql);
            
            while(rs.next())
            {
                e.addAll(new ItemMesa(rs.getInt("codigo"),rs.getDouble("valor"),rs.getDouble("preco_total"),rs.getString("nome")));
            }
        }
    
    }
    public boolean checaChurros(String codPED,String codPROD) throws SQLException//codigo pedido -- codigo produto
    {
        ResultSet rs;
        sql = "select count(c.cod_churros) from churros as c inner join produtos_mesa as pm on c.cod_churros = pm.cod_churros where pm.cod_pedido = $1 and c.cod_churros = $2";
        sql = sql.replace("$1",codPED);
        sql = sql.replace("$2",codPROD);    
        rs = Banco.con.consultar(sql);
        rs.next();
                if(rs.getInt("count")>0)
                    return true;
                else
                    return false;
    }
    
    public boolean checaItensDiv(String codPED,String codPROD) throws SQLException//codigo pedido -- codigo produto
    {
        ResultSet rs;
        sql = "select count(codigo) from itensdiversos as i inner join produtos_mesa as pm on i.codigo = pm.cod_itensdiv where pm.cod_pedido = $1 and i.codigo = $2";
        sql = sql.replace("$1",codPED);
        sql = sql.replace("$2",codPROD);    
        rs = Banco.con.consultar(sql);
        rs.next();
                if(rs.getInt("count")>0)
                    return true;
                else
                    return false;
    }
    
    
    
    public void pagarProduto(String CodPed,String CodProd,double pago,boolean a) throws SQLException
    {
        if(checaChurros(CodPed, CodProd))
        {
            sql = "update produtos_mesa set preco_pago = preco_pago + $1 where cod_pedido = $2 and cod_churros = $3";
            sql = sql.replace("$1",pago+"");
            sql = sql.replace("$2",CodPed);
            sql = sql.replace("$3",CodProd);
            Banco.con.manipular(sql); 
            
            sql = "update produtos_mesa set status = '$1' where cod_pedido = $2 and cod_churros = $3";
            sql = sql.replace("$3",CodProd);
            
        }
        
        if(checaItensDiv(CodPed, CodProd))
        {
            sql = "update produtos_mesa set preco_pago = preco_pago + $1 where cod_pedido = $2 and cod_itensdiv = $3;";
            sql = sql.replace("$1",pago+"");
            sql = sql.replace("$2",CodPed);
            sql = sql.replace("$3",CodProd);
            Banco.con.manipular(sql); 
            sql = "update produtos_mesa set status = '$1' where cod_pedido = $2 and cod_itensdiv = $3";
            
            sql = sql.replace("$3",CodProd);

        }
        sql = sql.replace("$2", CodPed);
        
            if(a)
               sql = sql.replace("$1","P");
            else
               sql = sql.replace("$1","D");
            
        Banco.con.manipular(sql); 
        
    }
        
    
    public void acertarMesa(String codMesa,String CodPed)//PAGA NOISSSSSSSSSSSSSSSSSSSSSSSSSSSS
    {
        sql = "update produtos_mesa set statuc = 'P' where cod_pedido = " + CodPed;
        Banco.con.manipular(sql);
         sql = "update pedidos set status = 'C' where cod_ped = " + CodPed;
         Banco.con.manipular(sql);
          sql = "update mesa set status = 'L' where cod_mesa = " + codMesa;
        Banco.con.manipular(sql);
    }
    
    public void getMesas(ObservableList<Mesa> e)
    {
        /*
            cod_mesa, descricao, statuc character(1)
            cod_mesa, status
        */
        
        try
        {
            ResultSet rs;
            sql = "select count(cod_mesa) from mesa";
            rs = Banco.con.consultar(sql);
            rs.next();
            if(rs.getInt("count")>0)
            {
                sql = "select * from mesa";
                rs = Banco.con.consultar(sql);
                while(rs.next())
                {
                    e.addAll(new Mesa(rs.getInt("cod_mesa"),rs.getString("statuc")));
                }

            }
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
        
    }
    
    public void excluirMesa(int cod)
    {
        sql = "delete from mesa where cod_mesa =" + cod;
        Banco.con.manipular(sql);
    }
    
    public void attMesa(int cod,String status)
    {
        sql = "update mesa set statuc = '$1' where cod_mesa = $2";
        sql = sql.replace("$1",status);
        sql = sql.replace("$2",cod+"");
         Banco.con.manipular(sql);
        
    }
            
    
    public void abrirNovaMesa()
    {
        sql = "INSERT INTO public.mesa(cod_mesa, statuc) VALUES (nextval('seq_mesa'), 'F')";
        Banco.con.manipular(sql); 
    }
    
    public void excluirProdutosMesa(String cod) throws SQLException
    {
        try
        {
            ResultSet rs;
            int codOP;
            boolean erro = false;

            sql = "select count(cod_ped) from pedidos where codigo_mesa = $1 and status = 'A'";
            sql = sql.replace("$1",cod);
            rs = Banco.con.consultar(sql);
            rs.next();

            if(rs.getInt("count") > 0)//existe um pedido em aberto
            {
                sql = "select cod_ped from pedidos where codigo_mesa = $1 and status = 'A'";
                sql = sql.replace("$1",cod);
                rs = Banco.con.consultar(sql);
                rs.next();


              codOP = rs.getInt("cod_ped");
              sql = "delete from produtos_mesa where cod_pedido = $1";
              sql = sql.replace("$1", codOP+"");
              Banco.con.consultar(sql);
            } 
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
                   
    }
            
    public void inserirProdutosMesa(String cod,ObservableList<ProdutosMesa> e, int codFunc) throws SQLException//codigo da mesa
    {
        try
        {
            String aux;
            int codOP,codPR;
            ResultSet rs; 
            boolean erro = false;

            sql = "select count(cod_ped) from pedidos where codigo_mesa = $1 and status = 'A'";
            sql = sql.replace("$1",cod);
            rs = Banco.con.consultar(sql);
            rs.next();

            if(rs.getInt("count") > 0)//existe um pedido em aberto
            {
                sql = "select cod_ped from pedidos where codigo_mesa = $1 and status = 'A'";
                sql = sql.replace("$1",cod);
                rs = Banco.con.consultar(sql);
                rs.next();

              codOP = rs.getInt("cod_ped"); 
            }
            else //precisa abrir um pedido
            {
            /*
                cod_ped, desconto, funcionarios_cod_func, total,  codigo_mesa, data date,
                cod_ped, desconto, func_cod, data_pedido, status, mesa_cod,
            */
                sql = "insert into pedidos(cod_ped,desconto,funcionarios_cod_func,data,status,codigo_mesa) "
                        + "values (nextval('seq_pedido'),0,$2,current_date,'A',$1)";//funcionario nao muda aqui... mudar isso
                sql = sql.replace("$1",cod+"");
                sql =sql.replace("$2", ""+codFunc);
                Banco.con.manipular(sql);
                
                
                     sql = "SELECT last_value as cod_ped2 FROM seq_pedido";
                rs = Banco.con.consultar(sql);
                
                rs.next();
                codOP = rs.getInt("cod_ped2");//CODOP PEGA O CODIGO DO PEDIDO 
            }

            for(ProdutosMesa a: e)
            {
                if(a.getTipo().equals("C"))
                {
                    aux = "Select cod_churros from churros where desc_churros = '$1'";
                    aux = aux.replace("$1",a.getNome());
                    System.out.println("SQL: " + aux);
                    System.out.println("CHEGOU AQUI C");
                    rs = Banco.con.consultar(aux);                
                    rs.next();
                    codPR = rs.getInt("cod_churros");//pegou o codigo do churros

                    


                    aux = "select count(cod_churros) from produtos_mesa where cod_churros = $1 and cod_pedido = $2";//fazendo isso pra ver se precisa adicionar mais
                    aux = aux.replace("$1", codPR+"");
                    aux = aux.replace("$2", codOP+"");
                    rs = Banco.con.consultar(aux);
                    rs.next();
                    if(rs.getInt("count") > 0)
                    {
                        //essa parte nao foi checada
                        sql = "update produtos_mesa set qtd_prod = qtd_prod + $1 where cod_pedido = $2 and cod_churros = $3";
                        sql = sql.replace("$1",a.getQtd()+"");
                        sql = sql.replace("$2",codOP+"");
                        sql = sql.replace("$3",codPR+"");
                    }
                    else  
                    {
                        sql = "INSERT INTO public.produtos_mesa(cod_churros, cod_mesa, preco_pago, desconto, qtd_prod, cod_pedido, status) VALUES ($1, $2, $3, $4, $5, $6,'$7')";

                        sql = sql.replace("$1", codPR+"");
                        sql = sql.replace("$2", cod);
                        sql = sql.replace("$3", 0+"");
                        sql = sql.replace("$4", 0+"");
                        sql = sql.replace("$5", a.getQtd()+"");
                        sql = sql.replace("$6", codOP + "");
                        sql = sql.replace("$7","N");
                    }

                } 
                else
                {
                    aux = "Select codigo from itensdiversos where nome = '$1'";
                    aux = aux.replace("$1",a.getNome());
                    
                    System.out.println("SQL: " + aux);
                    System.out.println("CHEGOU AQUI Else");
                    rs = Banco.con.consultar(aux);                
                    rs.next();
                    codPR = rs.getInt("codigo");//pegou o codigo do item

                    aux = "select count(cod_itensdiv) from produtos_mesa where cod_itensdiv = $1 and cod_pedido = $2";//fazendo isso pra ver se precisa adicionar mais
                    aux = aux.replace("$1", codPR+"");
                    aux = aux.replace("$2", codOP+"");
                    rs = Banco.con.consultar(aux);


                    rs.next();
                    if(rs.getInt("count") > 0)
                    {
                         //essa parte nao foi checada
                        sql = "update produtos_mesa set qtd_prod = qtd_prod + $1 where cod_pedido = $2 and cod_itensdiv = $3";
                        sql = sql.replace("$1",a.getQtd()+"");
                        sql = sql.replace("$2",codOP+"");
                        sql = sql.replace("$3",codPR+"");
                    }
                    else  
                    {
                        sql = "INSERT INTO public.produtos_mesa(cod_itensdiv,cod_mesa, preco_pago, desconto, qtd_prod, cod_pedido, status) VALUES ($1, $2, $3, $4, $5, $6, '$7')";
                        sql = sql.replace("$1", codPR+"");
                        sql = sql.replace("$2", cod);
                        sql = sql.replace("$3", 0+"");
                        sql = sql.replace("$4", 0+"");
                        sql = sql.replace("$5",a.getQtd()+"");
                        sql = sql.replace("$6", codOP + "");
                        sql = sql.replace("$7","N");
                    }

                }
                Banco.con.manipular(sql); 
            } 
        }catch(Exception er)
        {
            System.out.println("Erro: " + er.getMessage());
        }
        
    }
}
