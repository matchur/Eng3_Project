package churrosgourmetsystem.db.entidades;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Churros 
{

    private SimpleIntegerProperty cod;
    private SimpleStringProperty desc;
    private SimpleDoubleProperty preco;
    private SimpleStringProperty observacao;
    private SimpleIntegerProperty quantidade;

    public Churros(int cod, String desc, double preco, String observacao, int quantidade)
    {
        this.cod = new SimpleIntegerProperty(cod);
        this.desc = new SimpleStringProperty(desc);
        this.preco = new SimpleDoubleProperty(preco);
        this.observacao = new SimpleStringProperty(observacao);
        this.quantidade = new SimpleIntegerProperty(quantidade);
    }

    public Integer getCod() {
        return cod.get();
    }

    public void setCod(SimpleIntegerProperty cod) {
        this.cod = cod;
    }

    public String getDesc() {
        return desc.get();
    }

    public void setDesc(SimpleStringProperty desc) {
        this.desc = desc;
    }

 
    public String getObservacao() {
        return observacao.get();
    }

    public void setObservacao(SimpleStringProperty observacao) {
        this.observacao = observacao;
    }

    public Double getPreco() {
        return preco.get();
    }

    public void setPreco(SimpleDoubleProperty preco) {
        this.preco = preco;
    }

    public SimpleIntegerProperty getQuantidade() {
        return quantidade;
    }
    

    public void setQuantidade(SimpleIntegerProperty quantidade) {
        this.quantidade = quantidade;
    }
    
    @Override
    public String toString()
    {
        
        return desc.getValue()+"";
    }
}
