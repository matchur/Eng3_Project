package churrosgourmetsystem.db.entidades;

/**
 *
 * @author Henrique K.
 */
public class TiposDespesas {
    private int cod;
    private double valor;
    private String descricao;
    private String obs;
    private int codFunc;
    private int parcelas;
    private int flag;

    public TiposDespesas(int cod, double valor, String descricao, String obs, int codFunc, int parcelas, int flag) {
        this.cod = cod;
        this.valor = valor;
        this.descricao = descricao;
        this.obs = obs;
        this.codFunc = codFunc;
        this.parcelas = parcelas;
        this.flag = flag;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }
    
    
    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public int getCodFunc() {
        return codFunc;
    }

    public void setCodFunc(int codFunc) {
        this.codFunc = codFunc;
    }

    public int getParcelas() {
        return parcelas;
    }

    public void setParcelas(int parcelas) {
        this.parcelas = parcelas;
    }
    
    
}
