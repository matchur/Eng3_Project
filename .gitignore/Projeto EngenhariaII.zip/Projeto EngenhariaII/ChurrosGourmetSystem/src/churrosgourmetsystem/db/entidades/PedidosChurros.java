package churrosgourmetsystem.db.entidades;


public class PedidosChurros {
    int cod_ped;
    int cod_churros;
    int qtde;
    double valor;

    public PedidosChurros(int cod_ped, int cod_churros, int qtde, double valor) {
        this.cod_ped = cod_ped;
        this.cod_churros = cod_churros;
        this.qtde = qtde;
        this.valor = valor;
    }

    public int getCod_ped() {
        return cod_ped;
    }

    public void setCod_ped(int cod_ped) {
        this.cod_ped = cod_ped;
    }

    public int getCod_churros() {
        return cod_churros;
    }

    public void setCod_churros(int cod_churros) {
        this.cod_churros = cod_churros;
    }


    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
}
