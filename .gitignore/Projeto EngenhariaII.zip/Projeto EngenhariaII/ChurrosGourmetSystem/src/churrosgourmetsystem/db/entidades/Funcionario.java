package churrosgourmetsystem.db.entidades;

import java.time.LocalDate;

/**
 *
 * @author Henrique K.
 */
public class Funcionario {
    private int cod; /**/
    private String nome; /**/
    private String cpf; /**/
    private String rg; /**/
    private LocalDate dtNasc; /**/
    
    private String email; /**/
    private String telefone;
    
    private String endereco; 
    private String bairro;
    private String cidade;
    private int numero;

    private String senha; /**/
    private int nivel; /**/

    private double salario;

    
    
    //Construtor vazio
    public Funcionario() {}

    //Campos obrigatórios
    public Funcionario(int cod, String nome, String cpf, String rg, String email, LocalDate dtNasc, String senha, double salario, int nivel) {
        this.cod = cod;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.dtNasc = dtNasc;
        this.email = email;
        this.senha = senha;
        this.nivel = nivel;
        this.salario = salario;
    }

    //Todos os campos
    public Funcionario(int cod, String nome, String cpf, String rg, LocalDate dtNasc, String email, String telefone, String endereco, String bairro, String cidade, int numero, String senha, double salario, int nivel) {
        this.cod = cod;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.dtNasc = dtNasc;
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
        this.bairro = bairro;
        this.cidade = cidade;
        this.numero = numero;
        this.senha = senha;
        this.nivel = nivel;
        this.salario = salario;
    }
    

    //Getters e Setters
    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public LocalDate getDtNasc() {
        return dtNasc;
    }

    public void setDtNasc(LocalDate dtNasc) {
        this.dtNasc = dtNasc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    @Override
    public String toString()
    {
        return nome;
    }
}
