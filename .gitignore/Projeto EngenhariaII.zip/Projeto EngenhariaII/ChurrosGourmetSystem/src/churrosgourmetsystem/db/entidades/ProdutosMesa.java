package churrosgourmetsystem.db.entidades;

public class ProdutosMesa 
{
    private String nome;
    private int qtd;
    private double valor;
    private String status;//(P)ago - (N)ao pago - (D)ividido
    private String tipo;

    public ProdutosMesa(String nome, int qtd, double valor, String status, String tipo) {
        this.nome = nome;
        this.qtd = qtd;
        this.valor = valor;
        this.status = status;
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
    
}
