
package churrosgourmetsystem.db.entidades;

//se voce esta vendo essa classe, nao fale nada, somente feche e deixe ela como esta
//que sua vida seja longa

public class Tabela 
{
    private String desc;
    private double qtd;
    private double preco;

    public Tabela(String desc, double qtd) 
    {
        this.desc = desc;
        this.qtd = qtd;
    }
    
    public Tabela(String desc, double qtd, double preco) {
        this.desc = desc;
        this.qtd = qtd;
        this.preco = preco;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    
    
    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public double getQtd() {
        return qtd;
    }

    public void setQtd(double qtd) {
        this.qtd = qtd;
    }
    
    
    
}
