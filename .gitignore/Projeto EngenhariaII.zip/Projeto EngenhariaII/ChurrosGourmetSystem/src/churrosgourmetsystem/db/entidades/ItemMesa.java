
package churrosgourmetsystem.db.entidades;

public class ItemMesa
{
    private int cod;
    private double precoPago;
    private double precoProd;
    private String Nome;

    public ItemMesa(int cod, double precoPago, double precoProd, String Nome) {
        this.cod = cod;
        this.precoPago = precoPago;
        this.precoProd = precoProd;
        this.Nome = Nome;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public double getPrecoPago() {
        return precoPago;
    }

    public void setPrecoPago(double precoPago) {
        this.precoPago = precoPago;
    }

    public double getPrecoProd() {
        return precoProd;
    }

    public void setPrecoProd(double precoProd) {
        this.precoProd = precoProd;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
            
            
            
            
}
