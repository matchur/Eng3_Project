package churrosgourmetsystem.db.entidades;

import java.time.LocalDate;


public class Pedidos 
{
    private int codigo;
    private double desconto;
    private double valor_total;
    private int cod_funcionario;
    private int cod_mesa;
    private LocalDate data_ped;

    public Pedidos(int codigo, double desconto, double valor_total, int funcionario,int cod_mesa, LocalDate data_ped) {
        this.codigo = codigo;
        this.desconto = desconto;
        this.valor_total = valor_total;
        this.cod_mesa = cod_mesa;
        this.data_ped = data_ped;
        this.cod_funcionario = funcionario;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getDesconto() {
        return desconto;
    }

    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }

    public int getCod_funcionario() {
        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario) {
        this.cod_funcionario = cod_funcionario;
    }

    public int getCod_mesa() {
        return cod_mesa;
    }

    public void setCod_mesa(int cod_mesa) {
        this.cod_mesa = cod_mesa;
    }

    public LocalDate getData_ped() {
        return data_ped;
    }

    public void setData_ped(LocalDate data_ped) {
        this.data_ped = data_ped;
    }
}
