package churrosgourmetsystem.db.entidades;

import java.time.LocalDate;

public class Venda
{
    int codigo;
    LocalDate data;
    int codigo_pedido;
    String pagamento;

    public Venda(int codigo, LocalDate data,int codigo_pedido,String pagamento) {
        this.codigo = codigo;
        this.data = data;
        this.codigo_pedido = codigo_pedido;
        this.pagamento = pagamento;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public int getCodigo_pedido() {
        return codigo_pedido;
    }

    public void setCodigo_pedido(int codigo_pedido) {
        this.codigo_pedido = codigo_pedido;
    }

    public String getPagamento() {
        return pagamento;
    }

    public void setPagamento(String pagamento) {
        this.pagamento = pagamento;
    }
    
}
