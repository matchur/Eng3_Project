/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.db.entidades;

import java.time.LocalDate;

/**
 *
 * @author Henrique K.
 */
public class Caixa {
    private int cod;
    private double abertura;
    private double fechamento;
    private LocalDate data;

    public Caixa() {
    }

    public Caixa(int cod, double abertura, double fechamento, LocalDate data) {
        this.cod = cod;
        this.abertura = abertura;
        this.fechamento = fechamento;
        this.data = data;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public double getAbertura() {
        return abertura;
    }

    public void setAbertura(double abertura) {
        this.abertura = abertura;
    }

    public double getFechamento() {
        return fechamento;
    }

    public void setFechamento(double fechamento) {
        this.fechamento = fechamento;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }
    
    
}
