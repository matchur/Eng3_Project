package churrosgourmetsystem.db.entidades;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Ingredientes 
{
    private SimpleIntegerProperty cod;
    private SimpleStringProperty desc;
    private SimpleIntegerProperty qtdes;
    private SimpleStringProperty obs;
    private SimpleDoubleProperty qtdun;
    private char tipo;
    
    //variavel somente para o tipo churrosingredientes
    private SimpleDoubleProperty qtdChurros;
    
    public Ingredientes(int cod, String desc, int qtdes, String obs, double qtdun, char tipo) {
        this.cod = new SimpleIntegerProperty(cod);
        this.desc = new SimpleStringProperty(desc);
        this.qtdes = new SimpleIntegerProperty(qtdes);
        this.obs = new SimpleStringProperty(obs);
        this.qtdun = new SimpleDoubleProperty(qtdun);
        this.tipo = tipo;
    }

    public Ingredientes(String desc,double qtdChurros) {
        this.desc =new SimpleStringProperty(desc);
        this.qtdChurros =new SimpleDoubleProperty(qtdChurros);
    }
    
    public int getCod() {
        return cod.get();
    }

    public void setCod(SimpleIntegerProperty cod) {
        this.cod = cod;
    }

    public String getDesc() {
        return desc.get();
    }

    public void setDesc(SimpleStringProperty desc) {
        this.desc = desc;
    }

    public int getQtdes() {
        return qtdes.get();
    }

    public void setQtdes(SimpleIntegerProperty qtdes) {
        this.qtdes = qtdes;
    }

    public String getObs() {
        return obs.get();
    }

    public void setObs(SimpleStringProperty obs) {
        this.obs = obs;
    }

    public double getQtdun() {
        return qtdun.get();
    }

    public void setQtdun(SimpleDoubleProperty qtdun) {
        this.qtdun = qtdun;
    }

    public String getTipo() {
        if(tipo == 'k')
        return "Kg";
        else
            return "L";
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public double getQtdChurros() {
        return qtdChurros.get();
    }

    public void setQtdChurros(SimpleDoubleProperty qtdChurros) {
        this.qtdChurros = qtdChurros;
    }
}
