package churrosgourmetsystem.db.entidades;


public class PedidosItens 
{
    int cod_ped;
    int cod_itens;
    int qtde;
    double valor;

    public PedidosItens(int cod_ped, int cod_itens, int qtde, double valor) {
        this.cod_ped = cod_ped;
        this.cod_itens = cod_itens;
        this.qtde = qtde;
        this.valor = valor;
    }

    public int getCod_ped() {
        return cod_ped;
    }

    public void setCod_ped(int cod_ped) {
        this.cod_ped = cod_ped;
    }

    public int getCod_itens() {
        return cod_itens;
    }

    public void setCod_itens(int cod_itens) {
        this.cod_itens = cod_itens;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    
         
}
