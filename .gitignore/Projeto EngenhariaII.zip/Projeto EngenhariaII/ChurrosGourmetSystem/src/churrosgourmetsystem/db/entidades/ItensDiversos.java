package churrosgourmetsystem.db.entidades;

/**
 *
 * @author Henrique K.
 */
public class ItensDiversos {
    private int codigo;
    private String nome;
    private double valor;
    private String tipo;
    private String fornecedor;
    private int quantidade;
            
    public ItensDiversos(int codigo, String nome, double valor, String tipo, String fornecedor, int quantidade)
    {
        this.codigo = codigo;
        this.nome = nome;
        this.valor = valor;
        this.tipo = tipo;
        this.fornecedor = fornecedor;
        this.quantidade = quantidade;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }
    @Override
    public String toString()
    {
        return nome;
    }
}
