package churrosgourmetsystem.db.entidades;

public class Mesa 
{
    private int cod_mesa;
    private String status;//'L'ivre  - 'F'echada - 'O'cupada

    public Mesa(int cod_mesa, String status) {
        this.cod_mesa = cod_mesa;
        this.status = status;
    }

    public int getCod_mesa() {
        return cod_mesa;
    }

    public void setCod_mesa(int cod_mesa) {
        this.cod_mesa = cod_mesa;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
    
}
