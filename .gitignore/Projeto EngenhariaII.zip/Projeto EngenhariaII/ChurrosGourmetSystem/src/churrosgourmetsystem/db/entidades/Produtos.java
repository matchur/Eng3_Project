package churrosgourmetsystem.db.entidades;

public class Produtos
{
    private int codigo;
    private String produtos;
    private int quantidade;
    
    public Produtos(int codigo, String produtos, int quantidade)
    {
        this.codigo = codigo;
        this.produtos = produtos;
        this.quantidade = quantidade;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getProdutos() {
        return produtos;
    }

    public void setProdutos(String produtos) {
        this.produtos = produtos;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }


}
