/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package churrosgourmetsystem.util;


import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;

/**
 *
 * @author Henrique K.
 */
public class ConversorImagem {
    public static byte[] imageToByte(Image img)
    {
        byte[] bArray = null;
        BufferedImage bimg;
        try
            {
            bimg = SwingFXUtils.fromFXImage(img, null);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bimg, "png", baos);
            baos.flush();
            bArray = baos.toByteArray();
            baos.close();
        }catch(Exception er){
            System.out.println("Erro: " + er.getMessage());
        }
        return bArray;
    }
    
    public static Image byteToImage(byte[] bArr)
    {
        BufferedImage bimg;
        InputStream in;
        Image img = null;
        try
        {  
            in = new ByteArrayInputStream(bArr);
            bimg = ImageIO.read(in);
            ImageIO.write(bimg, "png", new File("src/churrosgourmetsystem/ui/icon/logoOficial.png"));
            img = SwingFXUtils.toFXImage(bimg, null); 
        }catch(Exception er){
            System.out.println("Erro: " + er.getMessage());
        }
        return img;
    }
}
