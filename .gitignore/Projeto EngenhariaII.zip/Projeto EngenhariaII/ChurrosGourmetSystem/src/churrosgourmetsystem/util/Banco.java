package churrosgourmetsystem.util;
//Padrão Singleton
public class Banco {
    static public Conexao con;

    private Banco(){}
    
    public static boolean conectar()
    {   
        con = new Conexao();
        //return con.conectar("jdbc:postgresql://localhost/","CGSDataBase","postgres","1234");//conexão Matheus
        return con.conectar("jdbc:postgresql://localhost/","CGSDataBase","postgres","postgres123");//conexão Henrique
    }
    
    public static Conexao getCon() {
        return con;
    }

    public static void setCon(Conexao con) {
        Banco.con = con;
    }
}
