package churrosgourmetsystem.util;

import javafx.scene.image.Image;

/**
 *
 * @author Henrique K.
 */
public class Tema {
    private static Image imgPrincipal;
    private static Image imgLogo;
    private static String cor = "#708090";

    public static Image getImgPrincipal() {
        return imgPrincipal;
    }

    public static void setImgPrincipal(Image imgPrincipal) {
        Tema.imgPrincipal = imgPrincipal;
    }

    public static Image getImgLogo() {
        return imgLogo;
    }

    public static void setImgLogo(Image imgLogo) {
        Tema.imgLogo = imgLogo;
    }

    public static String getCor() {
        return cor;
    }

    public static void setCor(String cor) {
        Tema.cor = cor;
    }
    
}
